'use client';

import React, { useState, useEffect, useRef, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  User, Briefcase, Check, ChevronRight, ChevronLeft, Loader2, BadgeCheck,
  ShieldCheck, Heart, Sparkles, ArrowRight, Star, Copy, Eye, EyeOff, KeyRound,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '@/services/api';
import { useAlert } from '@/components/providers/AlertProvider';
import { useImageUpload } from '@/hooks/useImageUpload';
import { Step1Identity } from '@/components/employees/create/Step1Identity';
import { Step2Family } from '@/components/employees/create/Step2Family';
import { Step3Contract } from '@/components/employees/create/Step3Contract';
import { Step4Validation } from '@/components/employees/create/Step4Validation';

const STEPS = [
  { id: 1, label: 'Identité',   icon: User },
  { id: 2, label: 'Famille',    icon: Heart },
  { id: 3, label: 'Contrat',    icon: Briefcase },
  { id: 4, label: 'Validation', icon: Check },
];

const STEP_CELEBRATIONS = [
  { step: 1, headline: 'Identité enregistrée',     sub: 'Les bases sont posées.',               accent: 'from-cyan-400 to-sky-500',     particle: '✦' },
  { step: 2, headline: 'Situation familiale OK',    sub: 'Fiscalité configurée avec soin.',      accent: 'from-violet-400 to-purple-500', particle: '◆' },
  { step: 3, headline: 'Contrat défini',            sub: "Les conditions d'emploi sont claires.", accent: 'from-emerald-400 to-teal-500',  particle: '▲' },
];

// ─── Génération mot de passe aléatoire sécurisé ───────────────────────────────
function generatePassword(length = 10): string {
  const upper   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lower   = 'abcdefghijklmnopqrstuvwxyz';
  const digits  = '0123456789';
  const special = '@#$!';
  const all = upper + lower + digits + special;
  const pwd = [
    upper[Math.floor(Math.random() * upper.length)],
    lower[Math.floor(Math.random() * lower.length)],
    digits[Math.floor(Math.random() * digits.length)],
    special[Math.floor(Math.random() * special.length)],
    ...Array.from({ length: length - 4 }, () => all[Math.floor(Math.random() * all.length)]),
  ];
  return pwd.sort(() => Math.random() - 0.5).join('');
}

// ─── Copier texte — fallback si clipboard API indisponible (HTTP) ──────────────
function copyToClipboard(text: string): boolean {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text);
      return true;
    }
    // Fallback pour HTTP / navigateurs anciens
    const el = document.createElement('textarea');
    el.value = text;
    el.setAttribute('readonly', '');
    el.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0';
    document.body.appendChild(el);
    el.focus();
    el.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(el);
    return ok;
  } catch {
    return false;
  }
}

// ─── Particle flottant ────────────────────────────────────────────────────────
function FloatingParticle({ char, delay, x, accent }: { char: string; delay: number; x: number; accent: string }) {
  return (
    <motion.span
      initial={{ opacity: 0, y: 0, x, scale: 0.5 }}
      animate={{ opacity: [0, 1, 0], y: -120, scale: [0.5, 1.2, 0.3] }}
      transition={{ duration: 1.6, delay, ease: 'easeOut' }}
      className={`absolute bottom-0 text-lg font-bold bg-gradient-to-r ${accent} bg-clip-text text-transparent pointer-events-none select-none`}
      style={{ left: `${x}%` }}
    >
      {char}
    </motion.span>
  );
}

// ─── Motivation overlay ───────────────────────────────────────────────────────
function MotivationOverlay({ show, step }: { show: boolean; step: number }) {
  const data = STEP_CELEBRATIONS.find((s) => s.step === step);
  if (!data) return null;
  const particles = Array.from({ length: 12 }, (_, i) => ({ x: 5 + i * 8, delay: i * 0.07 }));
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none"
        >
          <div className="absolute inset-0 bg-black/10 backdrop-blur-[2px]" />
          <motion.div
            initial={{ scale: 0.85, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: -10, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
            className="relative bg-white dark:bg-slate-900 rounded-3xl px-14 py-10 shadow-2xl border border-slate-100 dark:border-slate-700 overflow-hidden"
            style={{ boxShadow: '0 32px 80px -12px rgba(0,0,0,0.18)' }}
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${data.accent} opacity-[0.06] rounded-3xl`} />
            <motion.div initial={{ scaleY: 0 }} animate={{ scaleY: 1 }} transition={{ duration: 0.4, delay: 0.1 }}
              className={`absolute left-0 top-6 bottom-6 w-1 rounded-r-full bg-gradient-to-b ${data.accent}`}
              style={{ transformOrigin: 'top' }} />
            <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 }}
              className={`text-xs font-black uppercase tracking-[0.2em] bg-gradient-to-r ${data.accent} bg-clip-text text-transparent mb-3`}>
              Étape {step} / {STEPS.length - 1} complétée
            </motion.div>
            <motion.h2 initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
              className="text-3xl font-black text-slate-900 dark:text-white tracking-tight mb-1">
              {data.headline}
            </motion.h2>
            <motion.p initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.28 }}
              className="text-slate-500 dark:text-slate-400 text-base font-medium">
              {data.sub}
            </motion.p>
            <div className="mt-6 flex items-center gap-3">
              <div className="flex-1 h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                <motion.div initial={{ width: 0 }} animate={{ width: `${(step / 3) * 100}%` }}
                  transition={{ duration: 0.6, delay: 0.3, ease: 'easeOut' }}
                  className={`h-full rounded-full bg-gradient-to-r ${data.accent}`} />
              </div>
              <span className={`text-xs font-black bg-gradient-to-r ${data.accent} bg-clip-text text-transparent`}>
                {Math.round((step / 3) * 100)}%
              </span>
            </div>
            <div className="absolute inset-0 overflow-hidden rounded-3xl">
              {particles.map((p, i) => (
                <FloatingParticle key={i} char={data.particle} delay={p.delay} x={p.x} accent={data.accent} />
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── SUCCESS MODAL ─────────────────────────────────────────────────────────────
function SuccessModal({
  show, firstName, lastName, email, generatedPassword, fromCandidate, onGoToEmployee, onAddAnother,
}: {
  show: boolean; firstName: string; lastName: string; email: string;
  generatedPassword: string; fromCandidate: boolean;
  onGoToEmployee: () => void; onAddAnother: () => void;
}) {
  const [showPwd, setShowPwd] = useState(false);
  const [copied, setCopied]   = useState(false);

  const handleCopy = () => {
    const text = `Email : ${email}\nMot de passe : ${generatedPassword}`;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text);
      } else {
        const el = document.createElement('textarea');
        el.value = text;
        el.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0';
        document.body.appendChild(el);
        el.focus();
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch { setCopied(false); }
  };

  const initials = `${firstName?.[0] ?? ''}${lastName?.[0] ?? ''}`.toUpperCase();

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-md p-4"
        >
          <motion.div
            initial={{ scale: 0.75, y: 40, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 320, damping: 26, delay: 0.05 }}
            className="bg-white dark:bg-slate-900 rounded-[2rem] p-10 max-w-md w-full relative overflow-hidden"
            style={{ boxShadow: '0 40px 100px -20px rgba(0,0,0,0.3)', zIndex: 60 }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-sky-500/5 pointer-events-none" />
            <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-gradient-to-br from-cyan-400/10 to-sky-500/10 pointer-events-none" />
            <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-gradient-to-br from-cyan-400/15 to-sky-500/15 pointer-events-none" />

            {/* Confetti */}
            {Array.from({ length: 20 }).map((_, i) => (
              <motion.div key={i}
                initial={{ x: '50%', y: '40%', scale: 0, opacity: 1 }}
                animate={{ x: `${10 + Math.random() * 80}%`, y: `${10 + Math.random() * 80}%`, scale: [0, 1, 0], opacity: [1, 1, 0] }}
                transition={{ duration: 1.2 + Math.random() * 0.6, delay: i * 0.04, ease: 'easeOut' }}
                className="absolute pointer-events-none">
                <div className="rounded-full" style={{ width: 4 + Math.random() * 6, height: 4 + Math.random() * 6, background: ['#06b6d4','#0ea5e9','#8b5cf6','#10b981','#f59e0b'][i % 5] }} />
              </motion.div>
            ))}

            {/* Avatar */}
            <div className="flex justify-center mb-7 relative">
              <motion.div initial={{ scale: 0, rotate: -20 }} animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.2 }} className="relative">
                <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-cyan-400 to-sky-500 flex items-center justify-center text-white text-3xl font-black shadow-2xl shadow-cyan-500/30">
                  {initials || <User size={40} />}
                </div>
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}
                  transition={{ type: 'spring', delay: 0.45, stiffness: 400, damping: 20 }}
                  className="absolute -bottom-2 -right-2 w-9 h-9 bg-gradient-to-br from-emerald-400 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg border-2 border-white dark:border-slate-900">
                  <Check size={18} strokeWidth={3} className="text-white" />
                </motion.div>
              </motion.div>
            </div>

            {/* Texte */}
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
              className="text-center mb-6">
              <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-1 tracking-tight">
                {firstName} {lastName}
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mb-3">
                Dossier RH créé — accès système activé
              </p>
              {fromCandidate && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-cyan-50 dark:bg-cyan-500/10 border border-cyan-200 dark:border-cyan-500/20 rounded-xl text-xs font-bold text-cyan-700 dark:text-cyan-400">
                  <Star size={12} /> Candidat converti en employé
                </div>
              )}
            </motion.div>

            {/* Credentials */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.42 }}
              className="mb-6 p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <KeyRound size={14} className="text-cyan-500" />
                <span className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider">Accès généré automatiquement</span>
              </div>
              <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-600">
                <p className="text-[10px] text-slate-400 font-bold uppercase mb-0.5">Email</p>
                <p className="text-sm font-mono text-slate-800 dark:text-slate-200 select-all break-all">{email}</p>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-600">
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-slate-400 font-bold uppercase mb-0.5">Mot de passe provisoire</p>
                  <p className="text-sm font-mono text-slate-800 dark:text-slate-200 tracking-wider select-all">
                    {showPwd ? generatedPassword : '••••••••••'}
                  </p>
                </div>
                <button type="button" onClick={() => setShowPwd(v => !v)}
                  className="flex-shrink-0 p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer">
                  {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              <button type="button" onClick={handleCopy}
                className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border text-sm font-bold transition-all cursor-pointer ${
                  copied
                    ? 'border-emerald-300 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}>
                {copied ? <><Check size={14} /> Copié !</> : <><Copy size={14} /> Copier les identifiants</>}
              </button>
              <p className="text-[10px] text-slate-400 text-center">
                Transmettez ces identifiants à l'employé. Il pourra changer son mot de passe à la première connexion.
              </p>
            </motion.div>

            {/* Boutons */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
              className="space-y-3">
              <button type="button" onClick={onGoToEmployee}
                className="w-full py-4 bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-600 hover:to-sky-600 text-white font-bold rounded-2xl transition-all shadow-xl shadow-cyan-500/25 flex items-center justify-center gap-2 group cursor-pointer">
                Voir le dossier employé
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button type="button" onClick={onAddAnother}
                className="w-full py-3.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-2xl transition-colors border border-slate-200 dark:border-slate-700 cursor-pointer">
                Créer un autre employé
              </button>
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── FORMULAIRE PRINCIPAL ─────────────────────────────────────────────────────
function CreateEmployeeFormInner() {
  const router       = useRouter();
  const searchParams = useSearchParams();
  const alert        = useAlert();
  const imageUpload  = useImageUpload();

  const [currentStep, setCurrentStep]         = useState(1);
  const [direction, setDirection]             = useState(0);
  const [showSuccess, setShowSuccess]         = useState(false);
  const [showMotivation, setShowMotivation]   = useState(false);
  const [celebrationStep, setCelebrationStep] = useState(0);
  const [isLoading, setIsLoading]             = useState(false);
  const [departments, setDepartments]         = useState<any[]>([]);
  const [generatedPassword, setGeneratedPassword] = useState('');
  const [createdEmployeeId, setCreatedEmployeeId] = useState('');

  const fromCandidate = searchParams.get('fromCandidate') || '';
  const prefill = {
    firstName: searchParams.get('firstName') || '',
    lastName:  searchParams.get('lastName')  || '',
    email:     searchParams.get('email')     || '',
    phone:     searchParams.get('phone')     || '',
    position:  searchParams.get('jobTitle')  || '',
  };

  const [formData, setFormData] = useState({
    firstName:        prefill.firstName,
    lastName:         prefill.lastName,
    dateOfBirth:      '',
    placeOfBirth:     '',
    gender:           'MALE',
    phone:            prefill.phone,
    email:            prefill.email,
    address:          '',
    city:             'Brazzaville',
    nationalIdNumber: '',
    cnssNumber:       '',
    maritalStatus:      'SINGLE',
    numberOfChildren:   0,
    isSubjectToIrpp:    true,
    isSubjectToCnss:    true,
    taxExemptionReason: '',
    hireDate:            new Date().toISOString().split('T')[0],
    contractType:        'CDI',
    contractEndDate:     '',
    position:            prefill.position,
    departmentId:        '',
    baseSalary:          '',
    paymentMethod:       'CASH',
    bankName:            '',
    bankAccountNumber:   '',
    mobileMoneyOperator: 'MTN',
    mobileMoneyNumber:   '',
  });

  useEffect(() => {
    const fetchDepts = async () => {
      try {
        const data = await api.get<any[]>('/departments');
        setDepartments(data);
        if (data.length > 0) setFormData((prev) => ({ ...prev, departmentId: data[0].id }));
      } catch {
        alert.error('Erreur', 'Impossible de charger les départements');
      }
    };
    fetchDepts();
  }, []);

  const handleDepartmentCreated = (newDept: any) => {
    setDepartments((prev) => [...prev, newDept]);
    setFormData((prev) => ({ ...prev, departmentId: newDept.id }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: any) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateStep1 = () => {
    const missing: string[] = [];
    if (!formData.firstName.trim())    missing.push('Prénom');
    if (!formData.lastName.trim())     missing.push('Nom');
    if (!formData.dateOfBirth)         missing.push('Date de naissance');
    if (!formData.placeOfBirth.trim()) missing.push('Lieu de naissance');
    if (!formData.phone.trim())        missing.push('Téléphone');
    if (!formData.email.trim())        missing.push('Email');
    if (!formData.address.trim())      missing.push('Adresse');
    if (missing.length > 0) { alert.error('Champs manquants', `Veuillez remplir : ${missing.join(', ')}`); return false; }
    return true;
  };

  const validateStep2 = () => {
    if (!formData.isSubjectToIrpp && !formData.isSubjectToCnss && !formData.taxExemptionReason.trim()) {
      alert.error('Raison requise', "Précisez la raison de l'exemption fiscale"); return false;
    }
    return true;
  };

  const validateStep3 = () => {
    const missing: string[] = [];
    if (!formData.position.trim())  missing.push('Poste');
    if (!formData.departmentId)     missing.push('Département');
    if (!formData.baseSalary || parseFloat(formData.baseSalary) <= 0) missing.push('Salaire valide');
    const needsEnd = ['CDD', 'STAGE', 'INTERIM', 'CONSULTANT'].includes(formData.contractType);
    if (needsEnd && !formData.contractEndDate) missing.push('Date de fin de contrat');
    if (missing.length > 0) { alert.error('Champs manquants', `Veuillez remplir : ${missing.join(', ')}`); return false; }
    return true;
  };

  const triggerCelebration = (step: number) => {
    setCelebrationStep(step);
    setShowMotivation(true);
    return new Promise<void>((resolve) => {
      setTimeout(() => { setShowMotivation(false); resolve(); }, 1800);
    });
  };

  const nextStep = async () => {
    if (currentStep === 1 && !validateStep1()) return;
    if (currentStep === 2 && !validateStep2()) return;
    if (currentStep === 3 && !validateStep3()) return;
    if (currentStep < 4) {
      setDirection(1);
      await triggerCelebration(currentStep);
      setCurrentStep((curr) => curr + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) { setDirection(-1); setCurrentStep((curr) => curr - 1); }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      const payload = {
        firstName:           formData.firstName,
        lastName:            formData.lastName,
        dateOfBirth:         formData.dateOfBirth,
        placeOfBirth:        formData.placeOfBirth,
        gender:              formData.gender,
        maritalStatus:       formData.maritalStatus,
        numberOfChildren:    parseInt(formData.numberOfChildren as any) || 0,
        phone:               formData.phone,
        email:               formData.email,
        address:             formData.address,
        city:                formData.city,
        nationalIdNumber:    formData.nationalIdNumber.trim() || null,
        cnssNumber:          formData.cnssNumber.trim() || null,
        hireDate:            formData.hireDate,
        contractType:        formData.contractType,
        contractEndDate:     formData.contractEndDate || null,
        position:            formData.position,
        departmentId:        formData.departmentId,
        baseSalary:          parseFloat(formData.baseSalary),
        paymentMethod:       formData.paymentMethod,
        bankName:            formData.bankName,
        bankAccountNumber:   formData.bankAccountNumber,
        mobileMoneyOperator: formData.mobileMoneyOperator,
        mobileMoneyNumber:   formData.mobileMoneyNumber,
        photoUrl:            imageUpload.uploadedUrl,
        isSubjectToIrpp:     formData.isSubjectToIrpp,
        isSubjectToCnss:     formData.isSubjectToCnss,
        taxExemptionReason:  formData.taxExemptionReason || null,
      };

      // 1️⃣ Créer l'employé
      const createdEmployee = await api.post<any>('/employees', payload);
      setCreatedEmployeeId(createdEmployee?.id || '');

      // 2️⃣ Générer le mot de passe (random, unique par employé)
      const pwd = generatePassword(10);
      setGeneratedPassword(pwd);

      // 3️⃣ Créer le compte utilisateur (toujours, automatiquement)
      try {
        const invitePromise = api.post('/users/invite', {
          email:        formData.email,
          firstName:    formData.firstName,
          lastName:     formData.lastName,
          role:         'EMPLOYEE',
          password:     pwd,
          departmentId: formData.departmentId,
        });
        const timeout = new Promise((_, rej) =>
          setTimeout(() => rej(new Error('timeout')), 15000)
        );
        await Promise.race([invitePromise, timeout]);
      } catch (e: any) {
        // Timeout → compte probablement créé, juste l'email qui a mis du temps
        if (e.message === 'timeout') {
          alert.warning('Email différé', "L'employé est créé. L'email d'invitation sera envoyé ultérieurement.");
        }
        // Conflit → compte déjà existant, pas bloquant
        else if (e?.response?.status === 409) {
          // silencieux : l'utilisateur a déjà un compte
        }
        // Autre erreur → on log mais on n'empêche pas le succès
        else {
          console.error('[invite] Erreur création compte utilisateur:', e?.response?.data || e.message);
          alert.warning('Compte non créé', e?.response?.data?.message || "Le compte utilisateur n'a pas pu être créé. Vous pouvez le recréer depuis Paramètres > Utilisateurs.");
        }
      }

      setIsLoading(false);
      setShowSuccess(true);
    } catch (error: any) {
      setIsLoading(false);
      if (error.response?.data?.fields) {
        alert.error('Champs manquants', `Vérifiez : ${error.response.data.fields.join(', ')}`);
      } else {
        alert.error('Erreur', error.response?.data?.message || 'Erreur lors de la création');
      }
    }
  };

  const variants = {
    enter:  (dir: number) => ({ x: dir > 0 ? 40 : -40, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit:   (dir: number) => ({ x: dir > 0 ? -40 : 40, opacity: 0 }),
  };

  return (
    <div className="w-full flex justify-center items-start min-h-[calc(100vh-100px)] py-4 relative overflow-hidden">

      <MotivationOverlay show={showMotivation} step={celebrationStep} />

      <SuccessModal
        show={showSuccess}
        firstName={formData.firstName}
        lastName={formData.lastName}
        email={formData.email}
        generatedPassword={generatedPassword}
        fromCandidate={!!fromCandidate}
        onGoToEmployee={() => router.push(createdEmployeeId ? `/employes/${createdEmployeeId}` : '/employes')}
        onAddAnother={() => window.location.reload()}
      />

      {fromCandidate && (
        <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}
          className="fixed top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-3 px-5 py-2.5 bg-cyan-600 text-white rounded-2xl shadow-xl shadow-cyan-500/30 text-sm font-bold">
          <Sparkles size={15} className="shrink-0" />
          Formulaire pré-rempli depuis le dossier candidat
        </motion.div>
      )}

      <div className="w-full max-w-5xl glass-panel rounded-3xl shadow-xl overflow-hidden flex flex-col min-h-[600px]">

        {/* STEPPER */}
        <div className="sticky top-0 z-20 glass-panel border-b border-white/10">
          <div className="flex items-center justify-between px-6 sm:px-12 py-6 relative max-w-4xl mx-auto">
            <div className="absolute top-1/2 left-8 right-8 h-px bg-slate-200 dark:bg-white/10 -z-10 -translate-y-1/2" />
            {STEPS.map((step) => {
              const isActive    = step.id === currentStep;
              const isCompleted = step.id < currentStep;
              return (
                <div key={step.id} className="flex flex-col items-center bg-slate-50 dark:bg-slate-900 px-3 rounded-full py-1 transition-all">
                  <motion.div
                    animate={{ scale: isActive ? 1.1 : 1 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                    className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                      isActive
                        ? 'bg-gradient-to-br from-cyan-500 to-sky-500 border-cyan-400 text-white shadow-lg shadow-cyan-500/30'
                        : isCompleted
                        ? 'bg-gradient-to-br from-cyan-400 to-sky-500 border-cyan-400 text-white'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-600 text-slate-400'
                    }`}
                  >
                    {isCompleted ? <Check size={22} strokeWidth={3} /> : <step.icon size={22} />}
                  </motion.div>
                  <span className={`mt-2 text-xs font-bold uppercase tracking-wider hidden sm:block transition-colors ${
                    isActive ? 'text-cyan-600 dark:text-cyan-400' : isCompleted ? 'text-slate-400' : 'text-slate-300 dark:text-slate-600'
                  }`}>
                    {step.label}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="h-0.5 bg-slate-100 dark:bg-slate-800">
            <motion.div
              className="h-full bg-gradient-to-r from-cyan-400 to-sky-500"
              initial={{ width: 0 }}
              animate={{ width: `${((currentStep - 1) / 3) * 100}%` }}
              transition={{ duration: 0.5, ease: 'easeInOut' }}
            />
          </div>
        </div>

        {/* CONTENU */}
        <div className="flex-1 p-6 sm:p-10 overflow-x-hidden">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={currentStep}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ type: 'spring', stiffness: 300, damping: 30, duration: 0.3 }}
              className="max-w-4xl mx-auto"
            >
              {currentStep === 1 && (
                <Step1Identity formData={formData} onInputChange={handleInputChange} onSelectChange={handleSelectChange} imageUpload={imageUpload} />
              )}
              {currentStep === 2 && (
                <Step2Family formData={formData} onInputChange={handleInputChange} onSelectChange={handleSelectChange} />
              )}
              {currentStep === 3 && (
                <Step3Contract formData={formData} onInputChange={handleInputChange} onSelectChange={handleSelectChange} departments={departments} onDepartmentCreated={handleDepartmentCreated} />
              )}
              {currentStep === 4 && (
                <Step4Validation formData={formData} departments={departments} imagePreview={imageUpload.preview} />
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* FOOTER */}
        <div className="p-6 glass-panel border-t border-white/10 flex justify-between items-center">
          <button
            onClick={currentStep === 1 ? () => router.back() : prevStep}
            className="px-6 py-3 rounded-xl text-slate-500 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-white/5 transition-colors flex items-center gap-2 text-sm"
          >
            {currentStep === 1 ? 'Annuler' : <><ChevronLeft size={17} />Précédent</>}
          </button>

          <div className="flex gap-1.5 items-center">
            {[1, 2, 3, 4].map((s) => (
              <motion.div key={s}
                animate={{ width: s === currentStep ? 28 : 8, opacity: s < currentStep ? 1 : s === currentStep ? 1 : 0.3 }}
                transition={{ duration: 0.3 }}
                className={`h-2 rounded-full ${s <= currentStep ? 'bg-gradient-to-r from-cyan-400 to-sky-500' : 'bg-slate-200 dark:bg-slate-700'}`}
              />
            ))}
          </div>

          <button
            onClick={currentStep === 4 ? handleSubmit : nextStep}
            disabled={isLoading || (currentStep === 1 && imageUpload.uploading)}
            className={`px-8 py-3 rounded-xl text-white font-bold shadow-lg transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed text-sm ${
              currentStep === 4
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 shadow-emerald-500/25'
                : 'bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-600 hover:to-sky-600 shadow-cyan-500/25'
            }`}
          >
            {isLoading ? (
              <><Loader2 className="animate-spin" size={17} />Création…</>
            ) : currentStep === 4 ? (
              <><BadgeCheck size={17} />Créer l'employé</>
            ) : (
              <>Suivant<ChevronRight size={17} /></>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function CreateEmployeePage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-cyan-500" size={36} />
      </div>
    }>
      <CreateEmployeeFormInner />
    </Suspense>
  );
}