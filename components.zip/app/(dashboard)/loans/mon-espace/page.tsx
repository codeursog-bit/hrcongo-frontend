'use client';

// ============================================================================
// 📁 app/(dashboard)/loans/mon-espace/page.tsx
// ✅ Historique complet (prêts + avances) de l'employé connecté — maître-détail
//    avec pagination, cohérent avec les autres modules (absences, permissions).
// ============================================================================

import React, { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  Plus, Loader2, Clock, CheckCircle2, XCircle, Ban, ArrowRight,
  Printer, Download, X, Banknote, Package, HelpCircle, Wallet, Lock, Eye,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { api } from '@/services/api';
import { useBasePath } from '@/hooks/useBasePath';
import FinanceSubNav from '@/components/FinanceSubNav';
import LoanRequestPrintable from '@/components/LoanRequestPrintable';
import { printLoanDocument, downloadLoanDocumentPDF } from '@/lib/loan-print';
import DocumentPreviewModal from '@/components/loans/DocumentPreviewModal';

const LOAN_STATUS_CFG: Record<string, { label: string; cls: string; icon: any }> = {
  PENDING:    { label: 'En attente',  cls: 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-900/20 dark:text-amber-300', icon: Clock },
  PENDING_DG: { label: 'En attente',  cls: 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-900/20 dark:text-amber-300', icon: Clock }, // legacy, plus produit
  ACTIVE:     { label: 'Actif',       cls: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-300', icon: CheckCircle2 },
  PAID:       { label: 'Soldé',       cls: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-300', icon: CheckCircle2 },
  REJECTED:   { label: 'Refusé',      cls: 'bg-red-50 text-red-700 border-red-100 dark:bg-red-900/20 dark:text-red-300', icon: XCircle },
  CANCELLED:  { label: 'Annulé',      cls: 'bg-[var(--surface-2)] text-[var(--text-muted)]', icon: Ban },
};

const ADVANCE_STATUS_CFG: Record<string, { label: string; cls: string; icon: any }> = {
  PENDING:   { label: 'En attente', cls: 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-900/20 dark:text-amber-300', icon: Clock },
  APPROVED:  { label: 'Approuvée',  cls: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-300', icon: CheckCircle2 },
  PAID:      { label: 'Remboursée (espèces)', cls: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-300', icon: CheckCircle2 },
  DEDUCTED:  { label: 'Déduite',    cls: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-300', icon: CheckCircle2 },
  REJECTED:  { label: 'Refusée',    cls: 'bg-red-50 text-red-700 border-red-100 dark:bg-red-900/20 dark:text-red-300', icon: XCircle },
  CANCELLED: { label: 'Annulée',    cls: 'bg-[var(--surface-2)] text-[var(--text-muted)]', icon: Ban },
};

const TYPE_ICON: Record<string, any> = { ARGENT: Banknote, MARCHANDISE: Package, AUTRE: HelpCircle };
const PAGE_SIZE = 10;

type Item = { kind: 'loan' | 'advance'; id: string; data: any };

export default function MonEspacePretsAvancesPage() {
  const { bp } = useBasePath();
  const [userRole, setUserRole] = useState('');
  const [employee, setEmployee] = useState<any>(null);
  const [company, setCompany] = useState<any>(null);
  const [loans, setLoans] = useState<any[]>([]);
  const [advances, setAdvances] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState<string | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [mySpaceTab, setMySpaceTab] = useState<'validations' | 'suivi'>('validations');
  const [historyByLoan, setHistoryByLoan] = useState<Record<string, any[]>>({});

  useEffect(() => {
    try {
      const stored = localStorage.getItem('user');
      if (stored) setUserRole(JSON.parse(stored).role || '');
    } catch {}
    (async () => {
      try {
        const [l, a, emp, me]: any = await Promise.all([
          api.get('/loans/me'),
          api.get('/loans/advances/me'),
          api.get('/employees/me').catch(() => null),
          api.get('/auth/me').catch(() => null),
        ]);
        setLoans(l || []);
        setAdvances(a || []);
        setEmployee(emp);
        setCompany(me?.company ?? null);

        const relevant = (l || []).filter((x: any) => ['ACTIVE', 'PAID'].includes(x.status));
        const histories = await Promise.all(relevant.map((x: any) => api.get(`/loans/${x.id}/history`).catch(() => [])));
        const map: Record<string, any[]> = {};
        relevant.forEach((x: any, i: number) => { map[x.id] = histories[i] || []; });
        setHistoryByLoan(map);
      } catch (e) { console.error('Erreur chargement de mes prêts/avances', e); }
      finally { setIsLoading(false); }
    })();
  }, []);

  const items: Item[] = useMemo(() => {
    const l = loans.map(x => ({ kind: 'loan' as const, id: x.id, data: x }));
    const a = advances.map(x => ({ kind: 'advance' as const, id: x.id, data: x }));
    return [...l, ...a].sort((x, y) => new Date(y.data.createdAt).getTime() - new Date(x.data.createdAt).getTime());
  }, [loans, advances]);

  const totalPages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));
  const paginated = items.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const selected = items.find(i => i.id === selectedId) || null;
  const [docData, setDocData] = useState<any>(null);
  const [orcaHtml, setOrcaHtml] = useState<string | null>(null);

  useEffect(() => {
    if (!selected) { setDocData(null); setOrcaHtml(null); return; }
    (async () => {
      try {
        const path = selected.kind === 'loan'
          ? `/loans/${selected.id}/document-data`
          : `/loans/advances/${selected.id}/document-data`;
        const data = await api.get(path);
        setDocData(data);
        if ((data as any)?.company?.documentTemplate === 'ORCA') {
          const htmlPath = selected.kind === 'loan' ? `/loans/${selected.id}/document/orca-html` : `/loans/advances/${selected.id}/document/orca-html`;
          const res: any = await api.get(htmlPath);
          setOrcaHtml(res?.html ?? null);
        } else {
          setOrcaHtml(null);
        }
      } catch (e) {
        console.error('Erreur chargement document-data', e);
        setDocData(null); setOrcaHtml(null);
      }
    })();
  }, [selectedId]);

  const handleCancel = async (item: Item) => {
    if (!confirm('Annuler cette demande ?')) return;
    setBusy(item.id);
    try {
      if (item.kind === 'loan') await api.patch(`/loans/${item.id}/cancel`, {});
      else await api.patch(`/loans/advances/${item.id}/cancel`, {});
      const refresh = item.kind === 'loan' ? await api.get('/loans/me') : await api.get('/loans/advances/me');
      if (item.kind === 'loan') setLoans(refresh as any); else setAdvances(refresh as any);
    } catch (e: any) { alert(e?.message || "Erreur lors de l'annulation"); }
    finally { setBusy(null); }
  };

  const PRINT_ID = 'my-loan-print';
  const reference = selected ? `${selected.kind === 'loan' ? 'PR' : 'AV'}-${selected.id.slice(0, 8).toUpperCase()}` : '';

  const printData = selected ? {
    reference,
    company: { legalName: company?.legalName, tradeName: company?.tradeName, logo: company?.logo, rccmNumber: company?.rccmNumber, taxNumber: company?.taxNumber, address: company?.address, phone: company?.phone, cachetUrl: company?.cachetUrl, documentFooterText: company?.documentFooterText },
    employee: { firstName: employee?.firstName || '', lastName: employee?.lastName || '', position: employee?.position, phone: employee?.phone, departmentName: employee?.department?.name },
    docType: selected.kind === 'loan' ? selected.data.type : 'AVANCE',
    reason: selected.data.reason,
    amount: selected.data.amount,
    requestedAt: selected.data.createdAt,
    monthlyRepayment: selected.kind === 'loan' ? selected.data.monthlyRepayment : undefined,
    durationMonths: selected.kind === 'loan' ? Math.ceil(Number(selected.data.amount) / Number(selected.data.monthlyRepayment)) : undefined,
    status: selected.data.status,
    drhDecision: selected.kind === 'loan' ? selected.data.drhDecision : undefined,
    dgDecision: selected.kind === 'loan' ? selected.data.dgDecision : undefined,
    chefDecision: selected.kind === 'advance' ? (['APPROVED', 'DEDUCTED', 'PAID'].includes(selected.data.status) ? 'OUI' : selected.data.status === 'REJECTED' ? 'NON' : null) : undefined,
  } : null;

  const handleDownloadPdf = async () => {
    setIsExportingPdf(true);
    try { await downloadLoanDocumentPDF(PRINT_ID, `${selected?.kind === 'loan' ? 'pret' : 'avance'}-${reference}.pdf`); }
    finally { setIsExportingPdf(false); }
  };

  const [isExportingXlsx, setIsExportingXlsx] = useState(false);
  const handleDownloadOrcaXlsx = async () => {
    if (!selected) return;
    setIsExportingXlsx(true);
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
      const path = selected.kind === 'loan' ? `/loans/${selected.id}/document/orca-xlsx` : `/loans/advances/${selected.id}/document/orca-xlsx`;
      const res = await fetch(`${API_URL}${path}`, { credentials: 'include' });
      if (!res.ok) throw new Error('Échec du téléchargement de la fiche');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `${selected.kind === 'loan' ? 'pret' : 'avance'}-${reference}.xlsx`;
      document.body.appendChild(a); a.click(); a.remove();
      window.URL.revokeObjectURL(url);
    } catch (e: any) { alert(e?.message || 'Erreur lors du téléchargement'); }
    finally { setIsExportingXlsx(false); }
  };

  const [isPreparingPrint, setIsPreparingPrint] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const handlePrintOrcaPdf = async () => {
    if (!selected) return;
    setIsPreparingPrint(true);
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
      const path = selected.kind === 'loan' ? `/loans/${selected.id}/document/orca-pdf` : `/loans/advances/${selected.id}/document/orca-pdf`;
      const res = await fetch(`${API_URL}${path}`, { credentials: 'include' });
      if (!res.ok) { const body = await res.json().catch(() => null); throw new Error(body?.message || 'Impression indisponible pour le moment'); }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      window.open(url, '_blank');
    } catch (e: any) { alert(e?.message || "Erreur lors de la préparation de l'impression"); }
    finally { setIsPreparingPrint(false); }
  };

  // ── KPI de ma fiche dette (même logique que la fiche vue par le RH) ────────
  const myKpis = useMemo(() => {
    const dueLoans = loans.filter(l => ['ACTIVE', 'PAID'].includes(l.status));
    const dueAdvances = advances.filter(a => ['APPROVED', 'DEDUCTED', 'PAID'].includes(a.status));
    const totalDue = dueLoans.reduce((s, l) => s + Number(l.amount), 0) + dueAdvances.reduce((s, a) => s + Number(a.amount), 0);
    const paidLoans = dueLoans.reduce((s, l) => s + (Number(l.amount) - Number(l.remainingBalance)), 0);
    const paidAdvances = advances.filter(a => ['DEDUCTED', 'PAID'].includes(a.status)).reduce((s, a) => s + Number(a.amount), 0);
    const totalRemaining = loans.filter(l => l.status === 'ACTIVE').reduce((s, l) => s + Number(l.remainingBalance), 0)
      + advances.filter(a => a.status === 'APPROVED').reduce((s, a) => s + Number(a.amount), 0);
    const monthlyLoad = loans.filter(l => l.status === 'ACTIVE').reduce((s, l) => s + Number(l.monthlyRepayment), 0);
    return { totalDue, totalPaid: paidLoans + paidAdvances, totalRemaining, monthlyLoad };
  }, [loans, advances]);

  // ── KPI "Validations" : nombre de demandes, validées, en attente, montant total demandé ──
  const myRequestKpis = useMemo(() => {
    const notCounted = ['REJECTED', 'CANCELLED'];
    const total = items.length;
    const validated = items.filter(i => ['ACTIVE', 'PAID', 'APPROVED', 'DEDUCTED'].includes(i.data.status)).length;
    const pending = items.filter(i => ['PENDING', 'PENDING_DG'].includes(i.data.status)).length;
    const totalAmount = items.filter(i => !notCounted.includes(i.data.status)).reduce((s, i) => s + Number(i.data.amount), 0);
    return { total, validated, pending, totalAmount };
  }, [items]);

  // ── Courbe "Suivi" : emprunté vs remboursé, 12 derniers mois ─────────────
  const MONTHS_FR = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
  const trendData = useMemo(() => {
    const months: { key: string; label: string; year: number; month: number }[] = [];
    const ref = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(ref.getFullYear(), ref.getMonth() - i, 1);
      months.push({ key: `${d.getFullYear()}-${d.getMonth() + 1}`, label: `${MONTHS_FR[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`, year: d.getFullYear(), month: d.getMonth() + 1 });
    }
    const allLogs = Object.values(historyByLoan).flat();
    return months.map(m => {
      const emprunte = items.filter(i => { const d = new Date(i.data.createdAt); return d.getFullYear() === m.year && d.getMonth() + 1 === m.month; }).reduce((s, i) => s + Number(i.data.amount), 0);
      const rembourse = allLogs.filter((log: any) => log.year === m.year && log.month === m.month).reduce((s: number, log: any) => s + Number(log.amount), 0);
      return { mois: m.label, Emprunté: Math.round(emprunte), Remboursé: Math.round(rembourse) };
    });
  }, [items, historyByLoan]);

  if (isLoading) return <div className="flex justify-center py-24"><Loader2 className="animate-spin text-emerald-500" size={40} /></div>;

  return (
    <div className="max-w-[1500px] mx-auto pb-24 space-y-6">
      <FinanceSubNav userRole={userRole} />

      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-bold tracking-[0.2em] text-[var(--text-muted)] uppercase mb-1">Mon espace</p>
          <h1 className="text-2xl font-bold text-[var(--text)]">Mes prêts & avances</h1>
        </div>
        <Link href={bp('/loans/nouveau')} className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/30">
          <Plus size={18} /> Nouvelle demande
        </Link>
      </div>

      <div className="flex gap-1 bg-[var(--surface-2)] p-1 rounded-xl w-fit">
        <button onClick={() => setMySpaceTab('validations')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${mySpaceTab === 'validations' ? 'bg-[var(--surface)] text-[var(--text)] shadow-sm' : 'text-[var(--text-muted)]'}`}>Mes validations</button>
        <button onClick={() => setMySpaceTab('suivi')} className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${mySpaceTab === 'suivi' ? 'bg-[var(--surface)] text-[var(--text)] shadow-sm' : 'text-[var(--text-muted)]'}`}>Suivi de mes dettes</button>
      </div>

      {mySpaceTab === 'validations' && (
      <>
      {items.length > 0 && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <MyKpiCard label="Total de mes demandes" value={myRequestKpis.total} tone="slate" isCount />
          <MyKpiCard label="Validées" value={myRequestKpis.validated} tone="emerald" isCount />
          <MyKpiCard label="En attente" value={myRequestKpis.pending} tone="amber" isCount />
          <MyKpiCard label="Montant total demandé" value={myRequestKpis.totalAmount} tone="sky" />
        </div>
      )}

      {items.length === 0 ? (
        <div className="text-center py-24 bg-[var(--surface)] rounded-2xl border border-[var(--border)]">
          <Wallet size={32} className="text-[var(--text-muted)] mx-auto mb-3" />
          <h3 className="text-lg font-bold text-[var(--text)] mb-1">Aucune demande pour l&apos;instant</h3>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 space-y-3">
            {paginated.map(item => {
              const isLoan = item.kind === 'loan';
              const cfg = isLoan ? (LOAN_STATUS_CFG[item.data.status] ?? LOAN_STATUS_CFG.PENDING) : (ADVANCE_STATUS_CFG[item.data.status] ?? ADVANCE_STATUS_CFG.PENDING);
              const Icon = isLoan ? (TYPE_ICON[item.data.type] || Banknote) : Wallet;
              const StatusIcon = cfg.icon;
              const active = item.id === selectedId;
              return (
                <button key={item.id} onClick={() => setSelectedId(item.id)} className={`w-full text-left p-4 rounded-2xl border transition-all ${active ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 shadow-sm' : 'border-[var(--border)] bg-[var(--surface)] hover:border-[var(--border)]'}`}>
                  <div className="flex items-center gap-2">
                    <Icon size={14} className="text-[var(--text-muted)]" />
                    <p className="font-semibold text-sm text-[var(--text)]">{isLoan ? `Prêt ${item.data.type.toLowerCase()}` : 'Avance sur salaire'}</p>
                  </div>
                  <p className="text-xs text-[var(--text-muted)] mt-1">{Number(item.data.amount).toLocaleString('fr-FR')} FCFA · {new Date(item.data.createdAt).toLocaleDateString('fr-FR')}</p>
                  <span className={`inline-flex items-center gap-1 mt-2 text-[10px] font-semibold px-2 py-0.5 rounded-md border ${cfg.cls}`}><StatusIcon size={10} /> {cfg.label}</span>
                </button>
              );
            })}

            {items.length > PAGE_SIZE && (
              <div className="flex items-center justify-between pt-1">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-2 rounded-lg text-xs font-semibold border border-[var(--border)] text-[var(--text-muted)] disabled:opacity-30">Précédent</button>
                <span className="text-xs text-[var(--text-muted)]">Page {page} / {totalPages}</span>
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-3 py-2 rounded-lg text-xs font-semibold border border-[var(--border)] text-[var(--text-muted)] disabled:opacity-30">Suivant</button>
              </div>
            )}
          </div>

          <div className="lg:col-span-8">
            {!selected ? (
              <div className="h-full min-h-[300px] flex items-center justify-center bg-[var(--surface)] rounded-2xl border border-[var(--border)] text-[var(--text-muted)] text-sm">Sélectionnez une demande</div>
            ) : (
              <motion.div key={selected.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
                <div className="p-6 border-b border-[var(--border)] flex items-start justify-between gap-4">
                  <div>
                    <h2 className="text-lg font-bold text-[var(--text)]">{selected.kind === 'loan' ? `Prêt ${selected.data.type.toLowerCase()}` : 'Avance sur salaire'}</h2>
                    <p className="text-sm text-[var(--text-muted)]">Demandé le {new Date(selected.data.createdAt).toLocaleDateString('fr-FR')}</p>
                  </div>
                  <span className={`text-xs font-semibold px-3 py-1.5 rounded-lg border shrink-0 ${(selected.kind === 'loan' ? (LOAN_STATUS_CFG[selected.data.status] ?? LOAN_STATUS_CFG.PENDING) : (ADVANCE_STATUS_CFG[selected.data.status] ?? ADVANCE_STATUS_CFG.PENDING)).cls}`}>
                    {(selected.kind === 'loan' ? (LOAN_STATUS_CFG[selected.data.status] ?? LOAN_STATUS_CFG.PENDING) : (ADVANCE_STATUS_CFG[selected.data.status] ?? ADVANCE_STATUS_CFG.PENDING)).label}
                  </span>
                </div>

                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="p-3 rounded-xl bg-[var(--surface-2)]"><p className="text-[11px] text-[var(--text-muted)]">Montant</p><p className="font-bold text-[var(--text)]">{Number(selected.data.amount).toLocaleString('fr-FR')} FCFA</p></div>
                    {selected.kind === 'loan' && (
                      <div className="p-3 rounded-xl bg-[var(--surface-2)]"><p className="text-[11px] text-[var(--text-muted)]">Solde restant</p><p className="font-bold text-[var(--text)]">{Number(selected.data.remainingBalance).toLocaleString('fr-FR')} FCFA</p></div>
                    )}
                    {selected.data.reason && <div className="text-sm"><p className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5">Motif</p><p className="text-[var(--text-muted)] bg-[var(--surface-2)] p-3 rounded-xl">{selected.data.reason}</p></div>}
                    {selected.data.status === 'REJECTED' && selected.data.rejectionReason && (
                      <div className="text-sm text-red-600 bg-red-50 dark:bg-red-900/20 p-3 rounded-xl">Motif du refus : {selected.data.rejectionReason}</div>
                    )}

                    <div className="flex gap-2 pt-1 flex-wrap">
                      {['PENDING', 'PENDING_DG'].includes(selected.data.status) && (
                        <button onClick={() => handleCancel(selected)} disabled={busy === selected.id} className="flex-1 py-2.5 border border-[var(--border)] hover:bg-red-50 hover:text-red-600 text-[var(--text-muted)] text-sm font-semibold rounded-xl flex items-center justify-center gap-2 disabled:opacity-40">
                          {busy === selected.id ? <Loader2 size={16} className="animate-spin" /> : <X size={16} />} Annuler
                        </button>
                      )}
                    </div>
                    <div className="flex gap-2">
                      {selected.data.printAuthorized ? (
                        <>
                          {/* Impression 100% côté navigateur, aucune dépendance serveur — marche pour Orca comme pour les autres */}
                          <button onClick={() => setTimeout(() => printLoanDocument(PRINT_ID), 50)} className="flex-1 py-2.5 border border-[var(--border)] text-sm font-semibold rounded-xl text-[var(--text-muted)] flex items-center justify-center gap-2 hover:bg-[var(--surface-2)]"><Printer size={16} /> Imprimer</button>
                          {docData?.company?.documentTemplate === 'ORCA' ? (
                            <button onClick={handleDownloadOrcaXlsx} disabled={isExportingXlsx} className="flex-1 py-2.5 border border-[var(--border)] text-sm font-semibold rounded-xl text-[var(--text-muted)] flex items-center justify-center gap-2 hover:bg-[var(--surface-2)] disabled:opacity-40">{isExportingXlsx ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} Fiche Excel</button>
                          ) : (
                            <button onClick={handleDownloadPdf} disabled={isExportingPdf} className="flex-1 py-2.5 border border-[var(--border)] text-sm font-semibold rounded-xl text-[var(--text-muted)] flex items-center justify-center gap-2 hover:bg-[var(--surface-2)] disabled:opacity-40">{isExportingPdf ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} PDF</button>
                          )}
                        </>
                      ) : (
                        <div className="flex-1 py-2.5 border border-dashed border-[var(--border)] text-xs font-semibold rounded-xl text-[var(--text-muted)] flex items-center justify-center gap-2">
                          <Lock size={14} /> Impression non autorisée par le RH
                        </div>
                      )}
                    </div>

                    {selected.data.printAuthorized && (
                      <button onClick={() => setShowPreviewModal(true)} className="w-full py-2.5 border border-dashed border-[var(--border)] text-sm font-semibold rounded-xl text-[var(--text-muted)] flex items-center justify-center gap-2 hover:bg-[var(--surface-2)]">
                        <Eye size={16} /> Aperçu de la fiche
                      </button>
                    )}
                  </div>

                  {/* Rendu réel hors-écran : nécessaire pour la capture d'impression navigateur */}
                  <div className="fixed -left-[9999px] top-0 pointer-events-none" aria-hidden="true">
                    {docData?.company?.documentTemplate === 'ORCA' ? (
                      orcaHtml && <div id={PRINT_ID} dangerouslySetInnerHTML={{ __html: orcaHtml }} />
                    ) : (
                      printData && <LoanRequestPrintable id={PRINT_ID} data={printData as any} />
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      )}
      </>
      )}

      {mySpaceTab === 'suivi' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <MyKpiCard label="Montant dû (total)" value={myKpis.totalDue} tone="slate" />
            <MyKpiCard label="Déjà remboursé" value={myKpis.totalPaid} tone="emerald" />
            <MyKpiCard label="Reste à rembourser" value={myKpis.totalRemaining} tone="amber" />
            <MyKpiCard label="Mensualité en cours" value={myKpis.monthlyLoad} tone="sky" />
          </div>

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <p className="text-sm font-bold text-[var(--text)] mb-4">Évolution de mes dettes (12 derniers mois)</p>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="mois" fontSize={12} />
                <YAxis fontSize={12} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
                <Tooltip formatter={(v: number) => `${Math.round(v).toLocaleString('fr-FR')} FCFA`} />
                <Legend />
                <Line type="monotone" dataKey="Emprunté" stroke="#0ea5e9" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="Remboursé" stroke="#10b981" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
            <div className="p-4 border-b border-[var(--border)]">
              <p className="text-sm font-bold text-[var(--text)]">Historique complet</p>
            </div>
            <div className="divide-y divide-[var(--border)]">
              {items.length === 0 ? (
                <p className="text-center py-12 text-[var(--text-muted)] text-sm">Aucune dette pour l&apos;instant.</p>
              ) : items.map(item => {
                const isLoan = item.kind === 'loan';
                const cfg = isLoan ? (LOAN_STATUS_CFG[item.data.status] ?? LOAN_STATUS_CFG.PENDING) : (ADVANCE_STATUS_CFG[item.data.status] ?? ADVANCE_STATUS_CFG.PENDING);
                const StatusIcon = cfg.icon;
                return (
                  <div key={item.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold text-[var(--text)]">
                        {new Date(item.data.createdAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })} · {isLoan ? `Prêt ${item.data.type?.toLowerCase()}` : 'Avance sur salaire'} · {Number(item.data.amount).toLocaleString('fr-FR')} FCFA
                      </p>
                      {item.data.reason && <p className="text-xs text-[var(--text-muted)] mt-0.5">{item.data.reason}</p>}
                    </div>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border flex items-center gap-1 shrink-0 ${cfg.cls}`}><StatusIcon size={10} /> {cfg.label}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      <DocumentPreviewModal open={showPreviewModal} onClose={() => setShowPreviewModal(false)}>
        {selected && docData && (
          docData.company?.documentTemplate === 'ORCA' ? (
            orcaHtml && <div dangerouslySetInnerHTML={{ __html: orcaHtml }} />
          ) : (
            printData && <LoanRequestPrintable id="my-doc-preview" data={printData as any} />
          )
        )}
      </DocumentPreviewModal>
    </div>
  );
}

function MyKpiCard({ label, value, tone, isCount }: { label: string; value: number; tone: 'slate' | 'emerald' | 'amber' | 'sky'; isCount?: boolean }) {
  const cls: Record<string, string> = {
    slate: 'bg-[var(--surface)] text-[var(--text)] border-[var(--border)]',
    emerald: 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 border-emerald-100 dark:border-emerald-900',
    amber: 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300 border-amber-100 dark:border-amber-900',
    sky: 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 border-emerald-100 dark:border-emerald-900',
  };
  return (
    <div className={`rounded-2xl border p-4 ${cls[tone]}`}>
      <p className="text-[11px] font-semibold uppercase tracking-wide opacity-70 mb-1">{label}</p>
      <p className="text-lg font-bold">{isCount ? value : `${Math.round(value).toLocaleString('fr-FR')} FCFA`}</p>
    </div>
  );
}