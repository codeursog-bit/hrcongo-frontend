'use client';

// ============================================================================
// 📁 app/(dashboard)/loans/validations/page.tsx
// ✅ Page "Validations" — toutes les demandes (prêts + avances) de tout le
//    monde, KPI en tête, grille avec boutons Valider/Refuser visibles
//    directement sur chaque carte, et un clic ouvre une modal avec le détail
//    complet + décision + aperçu de fiche masqué par défaut (comme /loans).
// ============================================================================

import React, { useEffect, useMemo, useState } from 'react';
import {
  Loader2, Check, X, Clock, CheckCircle2, XCircle, Ban, Filter, Users2,
  Eye, Printer, Download, ShieldCheck, Landmark, LayoutGrid, List,
} from 'lucide-react';
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
} from 'recharts';
import { api } from '@/services/api';
import FinanceSubNav from '@/components/FinanceSubNav';
import LoanRequestPrintable from '@/components/LoanRequestPrintable';
import DocumentPreviewModal from '@/components/loans/DocumentPreviewModal';
import { printLoanDocument } from '@/lib/loan-print';

const DRH_ROLES = ['ADMIN', 'SUPER_ADMIN', 'HR_MANAGER'];
const TYPE_LABEL: Record<string, string> = { ARGENT: 'Prêt argent', MARCHANDISE: 'Marchandise', AUTRE: 'Autre prêt', AVANCE: 'Avance sur salaire' };
const fmt = (n: number) => Math.round(n).toLocaleString('fr-FR') + ' FCFA';

const STATUS_CFG: Record<string, { label: string; cls: string; icon: any }> = {
  PENDING:    { label: 'En attente', cls: 'bg-amber-50 text-amber-700 border-amber-100', icon: Clock },
  PENDING_DG: { label: 'En attente', cls: 'bg-amber-50 text-amber-700 border-amber-100', icon: Clock },
  ACTIVE:     { label: 'Validé',     cls: 'bg-emerald-50 text-emerald-700 border-emerald-100', icon: CheckCircle2 },
  APPROVED:   { label: 'Validé',     cls: 'bg-emerald-50 text-emerald-700 border-emerald-100', icon: CheckCircle2 },
  PAID:       { label: 'Soldé',      cls: 'bg-emerald-50 text-emerald-700 border-emerald-100', icon: CheckCircle2 },
  DEDUCTED:   { label: 'Déduite',    cls: 'bg-emerald-50 text-emerald-700 border-emerald-100', icon: CheckCircle2 },
  REJECTED:   { label: 'Refusé',     cls: 'bg-red-50 text-red-700 border-red-100', icon: XCircle },
  CANCELLED:  { label: 'Annulé',     cls: 'bg-[var(--surface-2)] text-[var(--text-muted)]', icon: Ban },
};

export default function ValidationsPage() {
  const [loans, setLoans] = useState<any[]>([]);
  const [advances, setAdvances] = useState<any[]>([]);
  const [company, setCompany] = useState<any>(null);
  const [userRole, setUserRole] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const [statusFilter, setStatusFilter] = useState<'' | 'PENDING' | 'VALIDATED' | 'REJECTED'>('');
  const [typeFilter, setTypeFilter] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const [selected, setSelected] = useState<{ kind: 'loan' | 'advance'; item: any } | null>(null);
  const [docData, setDocData] = useState<any>(null);
  const [orcaHtml, setOrcaHtml] = useState<string | null>(null);
  const [rejectMode, setRejectMode] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [recoverViaPayroll, setRecoverViaPayroll] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [isExportingXlsx, setIsExportingXlsx] = useState(false);
  const [isPreparingPrint, setIsPreparingPrint] = useState(false);

  const load = async () => {
    try {
      const [l, a, me]: any = await Promise.all([
        api.get('/loans'), api.get('/loans/advances'), api.get('/auth/me').catch(() => null),
      ]);
      setLoans(l || []); setAdvances(a || []); setCompany(me?.company ?? null);
    } catch (e) { console.error('Erreur chargement validations', e); }
    finally { setIsLoading(false); }
  };

  useEffect(() => {
    try { const stored = localStorage.getItem('user'); if (stored) setUserRole(JSON.parse(stored).role || ''); } catch {}
    load();
  }, []);

  useEffect(() => {
    if (!selected) { setDocData(null); setOrcaHtml(null); return; }
    (async () => {
      try {
        const path = selected.kind === 'loan' ? `/loans/${selected.item.id}/document-data` : `/loans/advances/${selected.item.id}/document-data`;
        const data = await api.get(path);
        setDocData(data);
        if ((data as any)?.company?.documentTemplate === 'ORCA') {
          const htmlPath = selected.kind === 'loan' ? `/loans/${selected.item.id}/document/orca-html` : `/loans/advances/${selected.item.id}/document/orca-html`;
          const res: any = await api.get(htmlPath);
          setOrcaHtml(res?.html ?? null);
        } else {
          setOrcaHtml(null);
        }
      } catch { setDocData(null); setOrcaHtml(null); }
    })();
  }, [selected]);

  // ── Liste unifiée ──────────────────────────────────────────────────────
  const allRequests = useMemo(() => {
    const l = loans.map(x => ({ ...x, kind: 'loan' as const, requestType: x.type ?? 'ARGENT' }));
    const a = advances.map(x => ({ ...x, kind: 'advance' as const, requestType: 'AVANCE' }));
    return [...l, ...a].sort((x, y) => new Date(y.createdAt).getTime() - new Date(x.createdAt).getTime());
  }, [loans, advances]);

  const bucket = (status: string) => {
    if (['PENDING', 'PENDING_DG'].includes(status)) return 'PENDING';
    if (['REJECTED', 'CANCELLED'].includes(status)) return 'REJECTED';
    return 'VALIDATED';
  };

  const kpis = useMemo(() => ({
    total: allRequests.length,
    pending: allRequests.filter(r => bucket(r.status) === 'PENDING').length,
    validated: allRequests.filter(r => bucket(r.status) === 'VALIDATED').length,
    rejected: allRequests.filter(r => bucket(r.status) === 'REJECTED').length,
  }), [allRequests]);

  const departments = useMemo(() => Array.from(new Set(allRequests.map(r => r.employee?.department?.name).filter(Boolean))).sort(), [allRequests]);

  const filtered = useMemo(() => allRequests.filter(r =>
    (!statusFilter || bucket(r.status) === statusFilter) &&
    (!typeFilter || r.requestType === typeFilter) &&
    (!deptFilter || r.employee?.department?.name === deptFilter),
  ), [allRequests, statusFilter, typeFilter, deptFilter]);

  // ── Stats : départements et types avec le plus de demandes ──────────────
  const byDept = useMemo(() => {
    const map: Record<string, number> = {};
    allRequests.forEach(r => { const n = r.employee?.department?.name || 'Sans département'; map[n] = (map[n] ?? 0) + 1; });
    return Object.entries(map).map(([departement, nombre]) => ({ departement, nombre })).sort((a, b) => b.nombre - a.nombre).slice(0, 6);
  }, [allRequests]);

  const byType = useMemo(() => {
    const map: Record<string, number> = {};
    allRequests.forEach(r => { map[r.requestType] = (map[r.requestType] ?? 0) + 1; });
    return Object.entries(map).map(([type, nombre]) => ({ type: TYPE_LABEL[type] ?? type, nombre })).sort((a, b) => b.nombre - a.nombre);
  }, [allRequests]);

  // ── Décision ─────────────────────────────────────────────────────────────
  const handleDecision = async (decision: 'OUI' | 'NON' | 'APPROVED' | 'REJECTED') => {
    if (!selected) return;
    const isReject = decision === 'NON' || decision === 'REJECTED';
    if (isReject && !rejectionReason.trim()) { setRejectMode(true); return; }
    setIsProcessing(true);
    try {
      if (selected.kind === 'loan') {
        await api.patch(`/loans/${selected.item.id}/decision`, { decision, rejectionReason: isReject ? rejectionReason : undefined, recoverViaPayroll });
      } else {
        await api.patch(`/loans/advances/${selected.item.id}/decision`, { decision, rejectionReason: isReject ? rejectionReason : undefined, recoverViaPayroll });
      }
      await load();
      setSelected(null); setRejectMode(false); setRejectionReason('');
    } catch (e: any) { alert(e?.message || 'Erreur'); } finally { setIsProcessing(false); }
  };

  const quickDecide = (r: any, decision: 'OUI' | 'NON' | 'APPROVED' | 'REJECTED', e: React.MouseEvent) => {
    e.stopPropagation();
    // ⚠️ Ne jamais décider directement ici : on doit d'abord demander au RH
    // si le remboursement se fera en espèces ou par déduction automatique
    // sur la paie. On ouvre donc systématiquement la modale de décision
    // (qui pose la question via la case "Récupérer automatiquement sur la
    // paie") au lieu d'envoyer recoverViaPayroll:true en dur.
    setSelected({ kind: r.kind, item: r });
    if (decision === 'NON' || decision === 'REJECTED') setRejectMode(true);
  };

  // ── Impression / aperçu ────────────────────────────────────────────────
  const reference = selected ? `${selected.kind === 'loan' ? 'PR' : 'AV'}-${selected.item.id.slice(0, 8).toUpperCase()}` : '';
  const printData = selected ? {
    reference,
    company: { legalName: company?.legalName, tradeName: company?.tradeName, logo: company?.logo, rccmNumber: company?.rccmNumber, taxNumber: company?.taxNumber, address: company?.address, phone: company?.phone, cachetUrl: company?.cachetUrl, documentFooterText: company?.documentFooterText },
    employee: { firstName: selected.item.employee?.firstName || '', lastName: selected.item.employee?.lastName || '', position: selected.item.employee?.position, departmentName: selected.item.employee?.department?.name },
    docType: selected.kind === 'loan' ? (selected.item.type || 'ARGENT') : 'AVANCE',
    amount: selected.item.amount, monthlyRepayment: selected.item.monthlyRepayment, status: selected.item.status,
    startDate: selected.item.startDate, endDate: selected.item.endDate, createdAt: selected.item.createdAt,
  } : null;

  const handleDownloadOrcaXlsx = async () => {
    if (!selected) return;
    setIsExportingXlsx(true);
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
      const path = selected.kind === 'loan' ? `/loans/${selected.item.id}/document/orca-xlsx` : `/loans/advances/${selected.item.id}/document/orca-xlsx`;
      const res = await fetch(`${API_URL}${path}`, { credentials: 'include' });
      if (!res.ok) throw new Error('Échec du téléchargement');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = `${reference}.xlsx`;
      document.body.appendChild(a); a.click(); a.remove(); window.URL.revokeObjectURL(url);
    } catch (e: any) { alert(e?.message || 'Erreur'); } finally { setIsExportingXlsx(false); }
  };

  const handlePrintOrcaPdf = async () => {
    if (!selected) return;
    setIsPreparingPrint(true);
    try {
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
      const path = selected.kind === 'loan' ? `/loans/${selected.item.id}/document/orca-pdf` : `/loans/advances/${selected.item.id}/document/orca-pdf`;
      const res = await fetch(`${API_URL}${path}`, { credentials: 'include' });
      if (!res.ok) { const body = await res.json().catch(() => null); throw new Error(body?.message || 'Impression indisponible'); }
      const blob = await res.blob();
      window.open(window.URL.createObjectURL(blob), '_blank');
    } catch (e: any) { alert(e?.message || 'Erreur'); } finally { setIsPreparingPrint(false); }
  };

  if (isLoading) return <div className="flex justify-center py-24"><Loader2 className="animate-spin text-emerald-500" size={40} /></div>;

  return (
    <div className="max-w-[1500px] mx-auto pb-24 space-y-6">
      <FinanceSubNav userRole={userRole} />
      <div>
        <h1 className="text-xl font-bold text-[var(--text)]">Validations</h1>
        <p className="text-sm text-[var(--text-muted)]">Toutes les demandes de prêts et avances, à valider ou refuser.</p>
      </div>

      {/* ══════════════════ KPI ══════════════════ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4">
          <p className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-1">Total</p>
          <p className="text-xl font-bold text-[var(--text)]">{kpis.total}</p>
        </div>
        <div className="bg-amber-50 dark:bg-amber-900/20 rounded-2xl border border-amber-100 dark:border-amber-900 p-4">
          <p className="text-[11px] font-semibold text-amber-600 uppercase tracking-wide mb-1">En attente</p>
          <p className="text-xl font-bold text-amber-700 dark:text-amber-300">{kpis.pending}</p>
        </div>
        <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-900 p-4">
          <p className="text-[11px] font-semibold text-emerald-600 uppercase tracking-wide mb-1">Validées</p>
          <p className="text-xl font-bold text-emerald-700 dark:text-emerald-300">{kpis.validated}</p>
        </div>
        <div className="bg-red-50 dark:bg-red-900/20 rounded-2xl border border-red-100 dark:border-red-900 p-4">
          <p className="text-[11px] font-semibold text-red-600 uppercase tracking-wide mb-1">Refusées</p>
          <p className="text-xl font-bold text-red-700 dark:text-red-300">{kpis.rejected}</p>
        </div>
      </div>

      {/* ══════════════════ STATS ══════════════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
          <p className="text-sm font-bold text-[var(--text)] mb-4">Départements avec le plus de demandes</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={byDept} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} horizontal={false} />
              <XAxis type="number" fontSize={12} allowDecimals={false} />
              <YAxis type="category" dataKey="departement" fontSize={12} width={110} />
              <Tooltip />
              <Bar dataKey="nombre" fill="#0ea5e9" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
          <p className="text-sm font-bold text-[var(--text)] mb-4">Types de demande les plus fréquents</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={byType} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} horizontal={false} />
              <XAxis type="number" fontSize={12} allowDecimals={false} />
              <YAxis type="category" dataKey="type" fontSize={12} width={110} />
              <Tooltip />
              <Bar dataKey="nombre" fill="#8b5cf6" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ══════════════════ FILTRES ══════════════════ */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-2">
          <FilterSelect icon={Filter} value={statusFilter} onChange={(v: any) => setStatusFilter(v)} placeholder="Tous les statuts" options={[['PENDING', 'En attente'], ['VALIDATED', 'Validées'], ['REJECTED', 'Refusées']]} />
          <FilterSelect icon={Filter} value={typeFilter} onChange={setTypeFilter} placeholder="Tous les types" options={Object.entries(TYPE_LABEL)} />
          {departments.length > 0 && <FilterSelect icon={Users2} value={deptFilter} onChange={setDeptFilter} placeholder="Tous les départements" options={departments.map(d => [d, d] as [string, string])} />}
        </div>
        <div className="flex gap-1 bg-[var(--surface-2)] p-1 rounded-lg shrink-0">
          <button onClick={() => setViewMode('grid')} className={`p-1.5 rounded-md ${viewMode === 'grid' ? 'bg-[var(--surface)] shadow-sm text-[var(--text)]' : 'text-[var(--text-muted)]'}`} title="Vue grille"><LayoutGrid size={16} /></button>
          <button onClick={() => setViewMode('list')} className={`p-1.5 rounded-md ${viewMode === 'list' ? 'bg-[var(--surface)] shadow-sm text-[var(--text)]' : 'text-[var(--text-muted)]'}`} title="Vue liste"><List size={16} /></button>
        </div>
      </div>

      {/* ══════════════════ DEMANDES : GRILLE ══════════════════ */}
      {viewMode === 'grid' && (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.length === 0 ? (
          <div className="col-span-full text-center py-16 bg-[var(--surface)] rounded-2xl border border-[var(--border)] text-sm text-[var(--text-muted)]">Aucune demande pour ce filtre.</div>
        ) : filtered.map(r => {
          const cfg = STATUS_CFG[r.status] ?? STATUS_CFG.PENDING;
          const Icon = cfg.icon;
          const isPending = bucket(r.status) === 'PENDING';
          return (
            <button key={`${r.kind}-${r.id}`} onClick={() => setSelected({ kind: r.kind, item: r })} className="text-left bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4 hover:shadow-md hover:border-emerald-200 dark:hover:border-emerald-800 transition-all">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="font-semibold text-[var(--text)] text-sm">{r.employee?.firstName} {r.employee?.lastName}</p>
                  <p className="text-xs text-[var(--text-muted)]">{r.employee?.department?.name || '—'}</p>
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border flex items-center gap-1 shrink-0 ${cfg.cls}`}><Icon size={10} /> {cfg.label}</span>
              </div>
              <p className="text-xs text-[var(--text-muted)] mb-1">{TYPE_LABEL[r.requestType] ?? r.requestType}</p>
              <p className="font-bold text-[var(--text)] mb-3">{fmt(Number(r.amount))}</p>
              {isPending && DRH_ROLES.includes(userRole) ? (
                <div className="flex gap-2">
                  <button onClick={(e) => quickDecide(r, r.kind === 'loan' ? 'OUI' : 'APPROVED', e)} disabled={isProcessing} className="flex-1 py-1.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1"><Check size={13} /> Valider</button>
                  <button onClick={(e) => quickDecide(r, r.kind === 'loan' ? 'NON' : 'REJECTED', e)} className="flex-1 py-1.5 border border-[var(--border)] hover:bg-red-50 hover:text-red-600 text-[var(--text-muted)] text-xs font-bold rounded-lg flex items-center justify-center gap-1"><X size={13} /> Refuser</button>
                </div>
              ) : (
                <p className="text-[11px] text-[var(--text-muted)]">{new Date(r.createdAt).toLocaleDateString('fr-FR')}</p>
              )}
            </button>
          );
        })}
      </div>
      )}

      {/* ══════════════════ DEMANDES : LISTE ══════════════════ */}
      {viewMode === 'list' && (
      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden divide-y divide-[var(--border)]">
        {filtered.length === 0 ? (
          <div className="text-center py-16 text-sm text-[var(--text-muted)]">Aucune demande pour ce filtre.</div>
        ) : filtered.map(r => {
          const cfg = STATUS_CFG[r.status] ?? STATUS_CFG.PENDING;
          const Icon = cfg.icon;
          const isPending = bucket(r.status) === 'PENDING';
          return (
            <button key={`${r.kind}-${r.id}`} onClick={() => setSelected({ kind: r.kind, item: r })} className="w-full text-left flex flex-col sm:flex-row sm:items-center gap-3 p-4 hover:bg-[var(--surface-2)]/40 transition-colors">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-[var(--text)] text-sm">{r.employee?.firstName} {r.employee?.lastName}</p>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border flex items-center gap-1 shrink-0 ${cfg.cls}`}><Icon size={10} /> {cfg.label}</span>
                </div>
                <p className="text-xs text-[var(--text-muted)]">{r.employee?.department?.name || '—'} · {TYPE_LABEL[r.requestType] ?? r.requestType} · {new Date(r.createdAt).toLocaleDateString('fr-FR')}</p>
              </div>
              <p className="font-bold text-[var(--text)] text-sm shrink-0">{fmt(Number(r.amount))}</p>
              {isPending && DRH_ROLES.includes(userRole) && (
                <div className="flex gap-2 shrink-0">
                  <button onClick={(e) => quickDecide(r, r.kind === 'loan' ? 'OUI' : 'APPROVED', e)} disabled={isProcessing} className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1"><Check size={13} /> Valider</button>
                  <button onClick={(e) => quickDecide(r, r.kind === 'loan' ? 'NON' : 'REJECTED', e)} className="px-3 py-1.5 border border-[var(--border)] hover:bg-red-50 hover:text-red-600 text-[var(--text-muted)] text-xs font-bold rounded-lg flex items-center justify-center gap-1"><X size={13} /> Refuser</button>
                </div>
              )}
            </button>
          );
        })}
      </div>
      )}

      {/* ══════════════════ MODAL DÉTAIL + DÉCISION ══════════════════ */}
      {selected && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => { setSelected(null); setRejectMode(false); setRejectionReason(''); }}>
          <div onClick={e => e.stopPropagation()} className="bg-[var(--surface)] rounded-2xl shadow-2xl max-w-md w-full p-5">
            <div className="flex items-center justify-between mb-4">
              <p className="font-bold text-[var(--text)]">{selected.item.employee?.firstName} {selected.item.employee?.lastName}</p>
              <button onClick={() => setSelected(null)} className="text-[var(--text-muted)] hover:text-[var(--text)]"><X size={20} /></button>
            </div>

            <div className="space-y-2 text-sm mb-4">
              <Row label="Type" value={TYPE_LABEL[selected.kind === 'loan' ? (selected.item.type ?? 'ARGENT') : 'AVANCE']} />
              <Row label="Montant" value={fmt(Number(selected.item.amount))} />
              {selected.kind === 'loan' && <Row label="Mensualité" value={fmt(Number(selected.item.monthlyRepayment))} />}
              <Row label="Département" value={selected.item.employee?.department?.name || '—'} />
              <Row label="Statut" value={(STATUS_CFG[selected.item.status] ?? STATUS_CFG.PENDING).label} />
              <Row label="Demandée le" value={new Date(selected.item.createdAt).toLocaleDateString('fr-FR')} />
              {selected.item.reason && <Row label="Motif" value={selected.item.reason} />}
              {selected.item.rejectionReason && <Row label="Motif du refus" value={selected.item.rejectionReason} />}
            </div>

            {bucket(selected.item.status) === 'PENDING' && DRH_ROLES.includes(userRole) && (
              <div className="space-y-2 pt-3 border-t border-[var(--border)] mb-3">
                {!rejectMode ? (
                  <>
                    <div>
                      <p className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5">Remboursement</p>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setRecoverViaPayroll(true)}
                          className={`px-3 py-2 rounded-xl border-2 text-xs font-bold transition-all ${recoverViaPayroll ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300' : 'border-[var(--border)] text-[var(--text-muted)]'}`}
                        >
                          Sur la paie
                        </button>
                        <button
                          type="button"
                          onClick={() => setRecoverViaPayroll(false)}
                          className={`px-3 py-2 rounded-xl border-2 text-xs font-bold transition-all ${!recoverViaPayroll ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300' : 'border-[var(--border)] text-[var(--text-muted)]'}`}
                        >
                          En espèces
                        </button>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => handleDecision(selected.kind === 'loan' ? 'OUI' : 'APPROVED')} disabled={isProcessing} className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white text-sm font-bold rounded-xl flex items-center justify-center gap-2"><Check size={16} /> Valider</button>
                      <button onClick={() => setRejectMode(true)} className="flex-1 py-2.5 border border-[var(--border)] hover:bg-red-50 hover:text-red-600 text-[var(--text-muted)] text-sm font-bold rounded-xl flex items-center justify-center gap-2"><X size={16} /> Refuser</button>
                    </div>
                  </>
                ) : (
                  <div className="space-y-2">
                    <textarea value={rejectionReason} onChange={e => setRejectionReason(e.target.value)} placeholder="Motif du refus (obligatoire)" rows={2} className="w-full text-sm p-2 rounded-lg border border-[var(--border)] bg-[var(--surface)]" />
                    <div className="flex gap-2">
                      <button onClick={() => handleDecision(selected.kind === 'loan' ? 'NON' : 'REJECTED')} disabled={isProcessing} className="flex-1 py-2 bg-red-500 hover:bg-red-600 disabled:opacity-50 text-white text-sm font-bold rounded-xl">Confirmer le refus</button>
                      <button onClick={() => { setRejectMode(false); setRejectionReason(''); }} className="flex-1 py-2 border border-[var(--border)] text-sm font-semibold rounded-xl text-[var(--text-muted)]">Annuler</button>
                    </div>
                  </div>
                )}
              </div>
            )}

            <button onClick={() => setShowPreviewModal(true)} className="w-full py-2 border border-dashed border-[var(--border)] text-xs font-semibold rounded-xl text-[var(--text-muted)] flex items-center justify-center gap-2 hover:bg-[var(--surface-2)] mb-2">
              <Eye size={14} /> Aperçu de la fiche
            </button>
            <div className="flex gap-2">
              <button onClick={() => setTimeout(() => printLoanDocument('val-print-target'), 50)} className="flex-1 py-2 border border-[var(--border)] text-xs font-semibold rounded-xl text-[var(--text-muted)] flex items-center justify-center gap-1.5 hover:bg-[var(--surface-2)]"><Printer size={13} /> Imprimer</button>
              {docData?.company?.documentTemplate === 'ORCA' && (
                <button onClick={handleDownloadOrcaXlsx} disabled={isExportingXlsx} className="flex-1 py-2 border border-[var(--border)] text-xs font-semibold rounded-xl text-[var(--text-muted)] flex items-center justify-center gap-1.5 hover:bg-[var(--surface-2)] disabled:opacity-40">{isExportingXlsx ? <Loader2 size={13} className="animate-spin" /> : <Download size={13} />} Fiche Excel</button>
              )}
            </div>

            {/* Rendu réel hors-écran : nécessaire pour la capture d'impression navigateur */}
            <div className="fixed -left-[9999px] top-0 pointer-events-none" aria-hidden="true">
              {selected && docData && (
                docData.company?.documentTemplate === 'ORCA' ? (
                  orcaHtml && <div id="val-print-target" dangerouslySetInnerHTML={{ __html: orcaHtml }} />
                ) : (
                  printData && <LoanRequestPrintable id="val-print-target" data={printData as any} />
                )
              )}
            </div>
          </div>
        </div>
      )}

      <DocumentPreviewModal open={showPreviewModal} onClose={() => setShowPreviewModal(false)}>
        {selected && docData && (
          docData.company?.documentTemplate === 'ORCA' ? (
            orcaHtml && <div dangerouslySetInnerHTML={{ __html: orcaHtml }} />
          ) : (
            printData && <LoanRequestPrintable id="val-doc-preview" data={printData as any} />
          )
        )}
      </DocumentPreviewModal>
    </div>
  );
}

function FilterSelect({ icon: IconEl, value, onChange, placeholder, options }: { icon: any; value: string; onChange: (v: string) => void; placeholder: string; options: [string, string][] }) {
  return (
    <div className="relative">
      <IconEl size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
      <select value={value} onChange={e => onChange(e.target.value)} className="pl-7 pr-3 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-xs">
        <option value="">{placeholder}</option>
        {options.map(([val, label]) => <option key={val} value={val}>{label}</option>)}
      </select>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-[var(--text-muted)]">{label}</span>
      <span className="font-semibold text-[var(--text)] text-right">{value}</span>
    </div>
  );
}