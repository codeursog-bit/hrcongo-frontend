'use client';

import { ModulePageFrame, ModulePageSkeleton } from '@/components/requests/ModulePageFrame';
import { Button } from '@/components/design-system/primitives';
import './refonte.css';
import { Modal, useToast } from '@/components/design-system/feedback';
import React, { useState, useEffect, useRef } from 'react';
import {
  Search, Plus, Monitor, Car, HardHat, Smartphone,
  CheckCircle2, AlertCircle, User,
  Laptop, X, Loader2, Tag, Armchair, Zap, RefreshCw,
  MoreVertical, Wrench, Archive, CheckCheck, UserCheck,
  Pencil, Trash2, Shirt, KeyRound, Package, UtensilsCrossed, Stethoscope
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '@/services/api';
import { FancySelect } from '@/components/ui/FancySelect';
import { KonzaLoader } from '@/components/ui/KonzaLoader';

// ── Types ─────────────────────────────────────────────────────────────────────
type AssetStatus = 'AVAILABLE' | 'IN_USE' | 'MAINTENANCE' | 'RETIRED';

interface Asset {
  id: string;
  name: string;
  serialNumber?: string;
  category: string;
  status: AssetStatus;
  employee?: { id: string; firstName: string; lastName: string; photoUrl?: string };
  purchasePrice?: number;
  purchaseValue?: number;
  purchaseDate?: string;
}

interface EmployeeOption {
  id: string;
  firstName: string;
  lastName: string;
}

// ── Catégories ────────────────────────────────────────────────────────────────
const CATEGORY_SUGGESTIONS = [
  { value: 'COMPUTER',         label: 'Informatique',      icon: Laptop },
  { value: 'VEHICLE',          label: 'Véhicule',          icon: Car },
  { value: 'EPI',              label: 'Sécurité (EPI)',    icon: HardHat },
  { value: 'PHONE',            label: 'Mobile / Téléphone',icon: Smartphone },
  { value: 'FURNITURE',        label: 'Mobilier',          icon: Armchair },
  { value: 'OFFICE_EQUIPMENT', label: 'Équipement bureau', icon: Monitor },
  { value: 'TOOLS',            label: 'Outillage & machines', icon: Wrench },
  { value: 'UNIFORM',          label: 'Uniformes & vêtements', icon: Shirt },
  { value: 'KEYS_BADGES',      label: 'Clés & badges',     icon: KeyRound },
  { value: 'SUPPLIES',         label: 'Fournitures',       icon: Package },
  { value: 'KITCHEN',          label: 'Cuisine & restauration', icon: UtensilsCrossed },
  { value: 'MEDICAL',          label: 'Médical & santé',   icon: Stethoscope },
];

// La catégorie est libre : ces suggestions ne sont qu'un point de départ. Les
// catégories saisies par l'entreprise s'y ajoutent automatiquement.
const findSuggestion = (raw: string) => {
  const r = (raw || '').trim().toLowerCase();
  return r ? CATEGORY_SUGGESTIONS.find(c => c.value.toLowerCase() === r || c.label.toLowerCase() === r) : undefined;
};
const categoryLabel = (cat: string) => findSuggestion(cat)?.label ?? (cat || '').trim();
// Clé stable : "Informatique" et "COMPUTER" désignent la même catégorie.
const categoryKey = (cat: string) => findSuggestion(cat)?.value ?? (cat || '').trim();

// ── Statuts disponibles pour changer via le menu ──────────────────────────────
const STATUS_ACTIONS: { status: AssetStatus; label: string; icon: React.ElementType; color: string }[] = [
  { status: 'AVAILABLE',   label: 'Marquer Disponible',   icon: CheckCheck, color: 'text-emerald-500' },
  { status: 'MAINTENANCE', label: 'Mettre en Maintenance', icon: Wrench,     color: 'text-amber-500' },
  { status: 'RETIRED',     label: 'Réformer (Retraité)',  icon: Archive,    color: 'text-red-500' },
];

// ── CategoryInput ─────────────────────────────────────────────────────────────
// Champ libre : on peut taper n'importe quelle catégorie. Les suggestions (les
// catégories de l'entreprise d'abord, puis les modèles) s'affichent en dessous,
// dans une zone qui défile — pas de menu flottant qui se fait couper.
const CategoryInput = ({
  value, onChange, existing,
}: { value: string; onChange: (v: string) => void; existing: string[] }) => {
  const q = value.trim().toLowerCase();

  const options = React.useMemo(() => {
    const seen = new Set<string>();
    const list: { label: string; icon: React.ElementType; mine: boolean }[] = [];
    // 1) catégories déjà utilisées par l'entreprise
    existing.forEach(cat => {
      const key = categoryKey(cat).toLowerCase();
      if (!key || seen.has(key)) return;
      seen.add(key);
      list.push({ label: categoryLabel(cat), icon: findSuggestion(cat)?.icon ?? Tag, mine: true });
    });
    // 2) modèles proposés
    CATEGORY_SUGGESTIONS.forEach(c => {
      const key = c.value.toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      list.push({ label: c.label, icon: c.icon, mine: false });
    });
    return q ? list.filter(o => o.label.toLowerCase().includes(q)) : list;
  }, [existing, q]);

  const isExact = options.some(o => o.label.toLowerCase() === q);

  return (
    <div className="col-span-2">
      <label className="block text-xs font-bold text-[var(--text-muted)] uppercase mb-2 ml-1">Catégorie</label>
      <div className="relative">
        <Tag size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
        <input
          type="text"
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder="Choisissez ou tapez votre propre catégorie…"
          className="w-full pl-9 pr-3 py-3.5 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl text-[var(--text)] outline-none focus:border-emerald-500/70 focus:ring-1 focus:ring-emerald-500/50 transition-colors placeholder:text-[var(--text-muted)] text-sm"
        />
      </div>

      {q && !isExact && (
        <p className="mt-2 ml-1 text-xs text-amber-500 flex items-center gap-1.5">
          <Plus size={12} /> Nouvelle catégorie : « {value.trim()} » sera créée à l'enregistrement.
        </p>
      )}

      {options.length > 0 && (
        <div className="mt-2 max-h-32 overflow-y-auto overscroll-contain pr-1 flex flex-wrap gap-2">
          {options.map(o => (
            <Button variant="ghost"
              key={o.label}
              type="button"
              onClick={() => onChange(o.label)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold transition-colors
                ${o.label.toLowerCase() === q
                  ? 'bg-emerald-500 text-white border-emerald-500'
                  : o.mine
                    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                    : 'bg-[var(--surface-2)] text-[var(--text-muted)] border-[var(--border)] hover:bg-[var(--border)]'}`}
            >
              <o.icon size={12} /> {o.label}
            </Button>
          ))}
        </div>
      )}
    </div>
  );
};

// ── Menu actions (⋯) sur chaque card ─────────────────────────────────────────
const AssetActionsMenu = ({
  asset,
  onStatusChange,
  onAssign,
  onUnassign,
  onEdit,
  onDelete,
}: {
  asset: Asset;
  onStatusChange: (id: string, status: AssetStatus) => void;
  onAssign: () => void;
  onUnassign: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const availableActions = STATUS_ACTIONS.filter(a => a.status !== asset.status);

  return (
    <div ref={ref} className="relative">
      <Button variant="ghost"
        onClick={e => { e.stopPropagation(); setOpen(o => !o); }}
        className="p-1.5 rounded-lg hover:bg-[var(--surface-2)] text-[var(--text-muted)] hover:text-[var(--text)] transition-colors"
      >
        <MoreVertical size={16} />
      </Button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -4 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -4 }}
            transition={{ duration: 0.12 }}
            // ✅ Fond solide, z élevé, ombre forte
            className="absolute right-0 top-8 w-52 bg-[var(--surface)] border border-[var(--border)] rounded-2xl shadow-xl z-[100] overflow-hidden py-1"
          >
            {/* Modifier */}
            <Button variant="ghost"
              onClick={() => { setOpen(false); onEdit(); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[var(--surface-2)] transition-colors text-left"
            >
              <Pencil size={15} className="text-sky-500" />
              <span className="text-sm text-[var(--text)]">Modifier</span>
            </Button>

            {/* Assigner / désassigner */}
            {asset.status === 'AVAILABLE' && (
              <Button variant="ghost"
                onClick={() => { setOpen(false); onAssign(); }}
                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[var(--surface-2)] transition-colors text-left"
              >
                <UserCheck size={15} className="text-emerald-500" />
                <span className="text-sm text-[var(--text)]">Assigner à un employé</span>
              </Button>
            )}
            {asset.status === 'IN_USE' && asset.employee && (
              <Button variant="ghost"
                onClick={() => { setOpen(false); onUnassign(); }}
                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[var(--surface-2)] transition-colors text-left"
              >
                <User size={15} className="text-red-500" />
                <span className="text-sm text-red-500">Retirer à {asset.employee.firstName}</span>
              </Button>
            )}

            {/* Séparateur si actions statut */}
            {availableActions.length > 0 && (
              <div className="border-t border-[var(--border)] my-1" />
            )}

            {/* Changer statut */}
            {availableActions.map(action => (
              <Button variant="ghost"
                key={action.status}
                onClick={() => { setOpen(false); onStatusChange(asset.id, action.status); }}
                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[var(--surface-2)] transition-colors text-left"
              >
                <action.icon size={15} className={action.color} />
                <span className="text-sm text-[var(--text)]">{action.label}</span>
              </Button>
            ))}

            {/* Supprimer */}
            <div className="border-t border-[var(--border)] my-1" />
            <Button variant="ghost"
              onClick={() => { setOpen(false); onDelete(); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-red-500/10 transition-colors text-left"
            >
              <Trash2 size={15} className="text-red-500" />
              <span className="text-sm text-red-500">Supprimer</span>
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// ── Page principale ───────────────────────────────────────────────────────────
export default function AssetsPage() {
  const uiNotify = useToast();
  const [uiLoadError, setUiLoadError] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [assets, setAssets] = useState<Asset[]>([]);
  const [employees, setEmployees] = useState<EmployeeOption[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [assignAsset, setAssignAsset] = useState<Asset | null>(null);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);
  const [deleteAsset, setDeleteAsset] = useState<Asset | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const emptyForm = () => ({
    name: '', serialNumber: '', category: '', condition: 'NEW',
    purchaseValue: '',
    purchaseDate: new Date().toISOString().split('T')[0],
  });
  const [newAsset, setNewAsset] = useState(emptyForm());

  const openCreate = () => {
    setEditingAsset(null);
    setNewAsset(emptyForm());
    setShowCreateModal(true);
  };

  const openEdit = (asset: Asset) => {
    setEditingAsset(asset);
    setNewAsset({
      name: asset.name,
      serialNumber: asset.serialNumber || '',
      category: categoryLabel(asset.category),
      condition: 'NEW',
      purchaseValue: String(asset.purchasePrice ?? asset.purchaseValue ?? ''),
      purchaseDate: asset.purchaseDate ? new Date(asset.purchaseDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
    });
    setShowCreateModal(true);
  };

  const closeForm = () => {
    setShowCreateModal(false);
    setEditingAsset(null);
    setNewAsset(emptyForm());
  };

  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [isAssigning, setIsAssigning] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [assetsData, employeesRaw] = await Promise.all([
          api.get<any>('/assets'),
          api.get<any>('/employees/simple'),
        ]);
        const assetList: Asset[] = Array.isArray(assetsData) ? assetsData : (assetsData?.data ?? []);
        setAssets(assetList);
        const empList: EmployeeOption[] = Array.isArray(employeesRaw) ? employeesRaw : (employeesRaw?.data ?? []);
        setEmployees(empList);
      } catch (e) {
        console.error('Erreur chargement:', e);
        setUiLoadError('Le parc matériel n’a pas pu être chargé. Réessayez dans un instant.');
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleCreateAsset = async () => {
    if (!newAsset.name.trim() || !newAsset.category.trim()) return;
    setIsCreating(true);
    try {
      const payload = {
        name: newAsset.name.trim(),
        serialNumber: newAsset.serialNumber || undefined,
        // "Informatique" saisi à la main → même code que la suggestion
        category: categoryKey(newAsset.category),
        purchaseValue: newAsset.purchaseValue !== '' ? Number(newAsset.purchaseValue) : 0,
        purchaseDate: new Date(newAsset.purchaseDate).toISOString(),
      };
      if (editingAsset) {
        const updated = await api.patch<Asset>(`/assets/${editingAsset.id}`, {
          ...payload,
          serialNumber: newAsset.serialNumber, // chaîne vide autorisée = effacer le n° de série
        });
        setAssets(prev => prev.map(a => a.id === editingAsset.id ? { ...a, ...updated } : a));
      } else {
        const created = await api.post<Asset>('/assets', { ...payload, condition: newAsset.condition });
        setAssets(prev => [created, ...prev]);
      }
      closeForm();
      uiNotify('success', editingAsset ? 'Matériel mis à jour' : 'Matériel ajouté');
    } catch (e: any) {
      alert(e?.message || (editingAsset ? 'Erreur lors de la modification.' : 'Erreur lors de la création.'));
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteAsset = async () => {
    if (!deleteAsset) return;
    setIsDeleting(true);
    try {
      await api.delete(`/assets/${deleteAsset.id}`);
      setAssets(prev => prev.filter(a => a.id !== deleteAsset.id));
      setDeleteAsset(null);
      uiNotify('success', 'Matériel supprimé');
    } catch (e: any) {
      alert(e?.message || 'Erreur lors de la suppression.');
      setDeleteAsset(null);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleAssignSubmit = async () => {
    if (!assignAsset || !selectedEmployeeId) return;
    setIsAssigning(true);
    try {
      const updated = await api.patch<Asset>(`/assets/${assignAsset.id}/assign`, { employeeId: selectedEmployeeId });
      setAssets(prev => prev.map(a => a.id === assignAsset.id ? updated : a));
      setAssignAsset(null);
      setSelectedEmployeeId('');
      uiNotify('success', 'Matériel attribué');
    } catch (e: any) {
      alert(e?.message || "Erreur lors de l'assignation.");
    } finally {
      setIsAssigning(false);
    }
  };

  const handleUnassign = async (asset: Asset) => {
    if (!confirm(`Retirer ${asset.name} à ${asset.employee?.firstName} ?`)) return;
    try {
      const updated = await api.patch<Asset>(`/assets/${asset.id}/assign`, { employeeId: null });
      setAssets(prev => prev.map(a => a.id === asset.id ? updated : a));
      uiNotify('success', 'Attribution retirée');
    } catch { alert('Erreur technique.'); }
  };

  // ✅ Changer le statut directement via l'API
  const handleStatusChange = async (assetId: string, newStatus: AssetStatus) => {
    try {
      const updated = await api.patch<Asset>(`/assets/${assetId}/status`, { status: newStatus });
      setAssets(prev => prev.map(a => a.id === assetId ? updated : a));
      uiNotify('success', 'Statut mis à jour');
    } catch (e: any) {
      alert(e?.message || 'Erreur lors du changement de statut.');
    }
  };

  // Filtres = catégories réellement présentes dans le parc (plus de liste figée)
  const categoryChips = React.useMemo(() => {
    const counts = new Map<string, { label: string; n: number }>();
    assets.forEach(a => {
      const key = categoryKey(a.category);
      if (!key) return;
      const cur = counts.get(key);
      if (cur) cur.n += 1; else counts.set(key, { label: categoryLabel(a.category), n: 1 });
    });
    return Array.from(counts.entries())
      .map(([id, v]) => ({ id, label: v.label, n: v.n }))
      .sort((x, y) => y.n - x.n || x.label.localeCompare(y.label));
  }, [assets]);

  const existingCategories = React.useMemo(() => assets.map(a => a.category).filter(Boolean), [assets]);

  // Si la dernière carte d'une catégorie disparaît, on revient sur "Tout"
  const effectiveCategory = activeCategory === 'All' || categoryChips.some(c => c.id === activeCategory) ? activeCategory : 'All';

  const filteredAssets = assets.filter(a => {
    const matchCat = effectiveCategory === 'All' || categoryKey(a.category) === effectiveCategory;
    const matchSearch = a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        a.serialNumber?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  const getCategoryIcon = (cat: string) => {
    const found = findSuggestion(cat);
    return found ? <found.icon size={22} /> : <Tag size={22} />;
  };

  const getCategoryLabel = (cat: string) => categoryLabel(cat);

  const getStatusStyle = (status: AssetStatus) => {
    switch (status) {
      case 'IN_USE':      return { bg: 'bg-emerald-500/10', text: 'text-emerald-500', border: 'border-emerald-500/30', icon: User,          label: 'Assigné' };
      case 'AVAILABLE':   return { bg: 'bg-[var(--surface-2)]', text: 'text-[var(--text-muted)]', border: 'border-[var(--border)]', icon: CheckCircle2,  label: 'Disponible' };
      case 'MAINTENANCE': return { bg: 'bg-amber-500/10', text: 'text-amber-500', border: 'border-amber-500/30', icon: RefreshCw,     label: 'Maintenance' };
      case 'RETIRED':     return { bg: 'bg-red-500/10', text: 'text-red-500', border: 'border-red-500/30', icon: AlertCircle,   label: 'Retraité' };
      default:            return { bg: 'bg-[var(--surface-2)]', text: 'text-[var(--text-muted)]', border: 'border-[var(--border)]', icon: AlertCircle,   label: status };
    }
  };

  const assetValue = (a: Asset) => a.purchasePrice ?? a.purchaseValue ?? 0;

  // ── Classes communes dark/light ────────────────────────────────────────────
  const inputCls = "w-full p-3.5 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl text-[var(--text)] outline-none focus:border-emerald-500/70 focus:ring-1 focus:ring-emerald-500/50 transition-colors placeholder:text-[var(--text-muted)] text-sm";
  const labelCls = "block text-xs font-bold text-[var(--text-muted)] uppercase mb-2 ml-1";
  const modalBg  = "bg-[var(--surface)]";
  const modalBorder = "border border-[var(--border)]";

  return (
    <ModulePageFrame kind="list" error={uiLoadError}><div className="materiel-refonte"><div className="max-w-[1600px] mx-auto pb-20 space-y-8 relative">

      {/* Ambiance background — visible surtout en dark */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-20 left-20 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-20 right-20 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-[120px]" />
      </div>

      {/* ── HEADER ── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-emerald-500/10 backdrop-blur-md rounded-2xl border border-emerald-500/20 shadow-sm text-emerald-500">
            <Zap size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-[var(--text)] tracking-tight">
              Parc <span className="text-emerald-500">Matériel</span>
            </h1>
            <p className="text-[var(--text-muted)]">Gestion centralisée des actifs et dotations.</p>
          </div>
        </div>
        <Button variant="primary"
          onClick={openCreate}
          className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold shadow-lg hover:shadow-emerald-500/30 transition-colors flex items-center gap-2 group"
        >
          <Plus size={20} className="group-hover:rotate-90 transition-transform" /> Nouvelle Dotation
        </Button>
      </div>

      {/* ── MÉTRIQUES ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 relative z-10">
        {[
          { label: 'Total Actifs', val: assets.length,                                       col: 'text-[var(--text)]',       bg: 'bg-[var(--surface-2)]',         icon: Tag,          border: 'border-[var(--border)]' },
          { label: 'Assignés',     val: assets.filter(a => a.status === 'IN_USE').length,     col: 'text-emerald-500', bg: 'bg-emerald-500/10',   icon: User,         border: 'border-emerald-500/20' },
          { label: 'Disponibles',  val: assets.filter(a => a.status === 'AVAILABLE').length,  col: 'text-[var(--text-muted)]',       bg: 'bg-[var(--surface-2)]',         icon: CheckCircle2, border: 'border-[var(--border)]' },
          { label: 'Maintenance',  val: assets.filter(a => a.status === 'MAINTENANCE').length, col: 'text-amber-500',  bg: 'bg-amber-500/10',     icon: RefreshCw,    border: 'border-amber-500/20' },
        ].map((m, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
            className={`p-5 rounded-2xl border ${m.bg} ${m.border} shadow-sm`}>
            <div className="flex justify-between items-start">
              <div>
                <p className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest">{m.label}</p>
                <p className={`text-3xl font-black mt-1 ${m.col}`}>{m.val}</p>
              </div>
              <m.icon className={`${m.col} opacity-70`} size={22} />
            </div>
          </motion.div>
        ))}
      </div>

      {/* ── CONTENU PRINCIPAL ── */}
      <div className="bg-[var(--surface)] backdrop-blur-xl rounded-[28px] border border-[var(--border)] min-h-[500px] relative z-10 shadow-sm">

        {/* Toolbar */}
        <div className="p-5 border-b border-[var(--border)] flex flex-col md:flex-row gap-4 justify-between items-center">
          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
            {[{ id: 'All', label: 'Tout', n: assets.length }, ...categoryChips].map(cat => (
              <Button variant="ghost" key={cat.id} onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-sm font-bold whitespace-nowrap border transition-colors
                  ${effectiveCategory === cat.id
                    ? 'bg-emerald-500 text-white border-emerald-500 shadow-md shadow-emerald-500/20'
                    : 'bg-[var(--surface-2)] text-[var(--text-muted)] border-[var(--border)] hover:bg-[var(--border)]'}`}>
                {cat.label} <span className="opacity-60 font-semibold">({cat.n})</span>
              </Button>
            ))}
          </div>
          <div className="relative w-full md:w-64 group">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] group-focus-within:text-emerald-500 transition-colors" size={16} />
            <input type="text" placeholder="Rechercher..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl text-sm text-[var(--text)] focus:ring-1 focus:ring-emerald-500/50 focus:border-emerald-500/50 outline-none transition-colors placeholder:text-[var(--text-muted)]" />
          </div>
        </div>

        {/* Grid */}
        {isLoading ? (
          <ModulePageSkeleton label="Chargement du matériel" />
        ) : filteredAssets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-32 text-[var(--text-muted)]">
            <Search size={40} className="mb-3 opacity-30" />
            <p className="text-sm">{searchQuery ? 'Essayez un autre nom ou numéro de série.' : 'Ajoutez votre premier équipement pour suivre ses attributions.'}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 p-5">
            <AnimatePresence>
              {filteredAssets.map((asset, i) => {
                const style = getStatusStyle(asset.status);
                return (
                  <motion.div key={asset.id}
                    initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.04 }}
                    className="group relative bg-[var(--surface)] hover:bg-[var(--surface-2)] border border-[var(--border)] hover:border-emerald-500/40 rounded-2xl p-5 transition-colors duration-300 hover:-translate-y-0.5 hover:shadow-lg overflow-visible"
                  >
                    {/* En-tête card */}
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-[var(--surface-2)] border border-[var(--border)] flex items-center justify-center text-[var(--text-muted)] group-hover:scale-105 transition-transform">
                          {getCategoryIcon(asset.category)}
                        </div>
                        <div>
                          <h3 className="font-bold text-[var(--text)] text-base line-clamp-1 group-hover:text-emerald-500 transition-colors">{asset.name}</h3>
                          <p className="text-xs text-[var(--text-muted)] mt-0.5 font-mono">{asset.serialNumber || 'S/N —'}</p>
                          <p className="text-[10px] text-emerald-500/70 mt-0.5">{getCategoryLabel(asset.category)}</p>
                        </div>
                      </div>

                      {/* Badge statut + menu ⋯ */}
                      <div className="flex items-center gap-1.5">
                        <div className={`px-2.5 py-1 rounded-full text-[10px] font-bold border flex items-center gap-1 ${style.bg} ${style.text} ${style.border}`}>
                          <style.icon size={11} /> {style.label}
                        </div>
                        {/* ✅ Menu actions statut */}
                        <AssetActionsMenu
                          asset={asset}
                          onStatusChange={handleStatusChange}
                          onAssign={() => setAssignAsset(asset)}
                          onUnassign={() => handleUnassign(asset)}
                          onEdit={() => openEdit(asset)}
                          onDelete={() => setDeleteAsset(asset)}
                        />
                      </div>
                    </div>

                    {/* Valeur */}
                    <div className="flex justify-between items-center p-3 rounded-xl bg-[var(--surface-2)] border border-[var(--border)] mb-4">
                      <span className="text-xs text-[var(--text-muted)] uppercase font-bold">Valeur</span>
                      <span className="font-mono font-bold text-emerald-500 text-sm">
                        {assetValue(asset).toLocaleString() || '—'} <span className="text-[10px] text-[var(--text-muted)]">FCFA</span>
                      </span>
                    </div>

                    {/* Footer card */}
                    <div className="pt-3 border-t border-[var(--border)]">
                      {asset.status === 'IN_USE' && asset.employee ? (
                        <div className="flex items-center gap-2.5">
                          <img
                            src={asset.employee.photoUrl || `https://ui-avatars.com/api/?name=${asset.employee.firstName}+${asset.employee.lastName}&background=10B981&color=fff`}
                            className="w-7 h-7 rounded-full border border-[var(--border)]" alt=""
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-[10px] text-[var(--text-muted)] uppercase font-bold">Détenteur</p>
                            <p className="text-sm font-bold text-[var(--text)] truncate">{asset.employee.firstName} {asset.employee.lastName}</p>
                          </div>
                        </div>
                      ) : asset.status === 'MAINTENANCE' ? (
                        <div className="flex items-center gap-2 text-amber-500">
                          <RefreshCw size={14} className="animate-spin" />
                          <span className="text-xs font-bold">En cours de maintenance</span>
                        </div>
                      ) : asset.status === 'RETIRED' ? (
                        <div className="flex items-center gap-2 text-[var(--text-muted)]">
                          <AlertCircle size={14} />
                          <span className="text-xs font-bold">Matériel retraité / réformé</span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-[var(--text-muted)] italic flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-[var(--border)] inline-block" /> En stock
                          </span>
                          <Button variant="primary" onClick={() => setAssignAsset(asset)}
                            className="text-xs font-bold text-white bg-emerald-500 hover:bg-emerald-600 px-3 py-1.5 rounded-lg transition-colors shadow-md shadow-emerald-500/20">
                            Assigner
                          </Button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* ── MODAL CRÉER ── */}
      <AnimatePresence>
        {showCreateModal && (
          <Modal open title={editingAsset ? "Modifier le matériel" : "Nouveau matériel"} onClose={closeForm}>

              <div className="space-y-4">
                <div>
                  <label className={labelCls}>Nom du matériel</label>
                  <input value={newAsset.name} onChange={e => setNewAsset({ ...newAsset, name: e.target.value })}
                    className={inputCls} placeholder="Ex: MacBook Pro M3 Max" />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={labelCls}>Numéro Série</label>
                    <input value={newAsset.serialNumber} onChange={e => setNewAsset({ ...newAsset, serialNumber: e.target.value })}
                      className={inputCls} placeholder="SN-12345" />
                  </div>
                  <div>
                    <label className={labelCls}>Date d'achat</label>
                    <input type="date" value={newAsset.purchaseDate} onChange={e => setNewAsset({ ...newAsset, purchaseDate: e.target.value })}
                      className={inputCls} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <CategoryInput value={newAsset.category} onChange={v => setNewAsset({ ...newAsset, category: v })} existing={existingCategories} />
                  <div className="col-span-2">
                    <label className={labelCls}>Valeur (FCFA)</label>
                    <input type="number" value={newAsset.purchaseValue}
                      onChange={e => setNewAsset({ ...newAsset, purchaseValue: e.target.value })}
                      className={inputCls} placeholder="0" min={0} />
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-7">
                <Button variant="ghost" onClick={closeForm}
                  className="flex-1 py-3.5 border border-[var(--border)] rounded-xl font-bold text-[var(--text-muted)] hover:bg-[var(--surface-2)] transition-colors">
                  Annuler
                </Button>
                <Button variant="primary" onClick={handleCreateAsset} disabled={isCreating || !newAsset.name.trim() || !newAsset.category.trim()}
                  className="flex-1 py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl flex justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-emerald-500/20">
                  {isCreating && <Loader2 className="animate-spin" size={18} />} {editingAsset ? 'Enregistrer' : 'Créer'}
                </Button>
              </div>
            </Modal>
        )}
      </AnimatePresence>

      {/* ── MODAL SUPPRIMER ── */}
      <AnimatePresence>
        {deleteAsset && (
          <Modal open title={"Supprimer ce matériel ?"} onClose={() => setDeleteAsset(null)}>
              <p className="text-sm text-[var(--text-muted)]">
                <span className="font-bold text-[var(--text)]">« {deleteAsset.name} »</span> sera supprimé définitivement du parc.
              </p>
              {deleteAsset.status === 'IN_USE' && (
                <div className="mt-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-500 text-sm">
                  Ce matériel est attribué{deleteAsset.employee ? ` à ${deleteAsset.employee.firstName} ${deleteAsset.employee.lastName}` : ''}. Retirez-le d'abord (menu ⋯ → « Retirer ») avant de le supprimer.
                </div>
              )}
              <div className="flex gap-3 mt-7">
                <Button variant="ghost" onClick={() => setDeleteAsset(null)} disabled={isDeleting}
                  className="flex-1 py-3.5 border border-[var(--border)] rounded-xl font-bold text-[var(--text-muted)] hover:bg-[var(--surface-2)] transition-colors">
                  Annuler
                </Button>
                <Button variant="ghost" onClick={handleDeleteAsset} disabled={isDeleting || deleteAsset.status === 'IN_USE'}
                  className="flex-1 py-3.5 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl flex justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                  {isDeleting ? <Loader2 className="animate-spin" size={18} /> : <Trash2 size={18} />} Supprimer
                </Button>
              </div>
            </Modal>
        )}
      </AnimatePresence>

      {/* ── MODAL ASSIGNER ── */}
      <AnimatePresence>
        {assignAsset && (
          <Modal open title={"Attribuer le matériel"} onClose={() => setAssignAsset(null)}>

              <div className="space-y-5">
                <div className="bg-[var(--surface-2)] p-4 rounded-xl border border-[var(--border)] flex items-center gap-4">
                  <div className="w-11 h-11 bg-emerald-500/10 rounded-lg flex items-center justify-center text-emerald-500">
                    {getCategoryIcon(assignAsset.category)}
                  </div>
                  <div>
                    <p className="text-[10px] text-[var(--text-muted)] uppercase font-bold">Équipement</p>
                    <p className="font-bold text-[var(--text)]">{assignAsset.name}</p>
                    <p className="text-xs text-[var(--text-muted)] font-mono">{assignAsset.serialNumber || '—'}</p>
                  </div>
                </div>

                {employees.length === 0 ? (
                  <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-500 text-sm">
                    Aucun employé disponible.
                  </div>
                ) : (
                  <FancySelect
                    label="Bénéficiaire"
                    value={selectedEmployeeId}
                    onChange={v => setSelectedEmployeeId(v)}
                    icon={User}
                    options={employees.map(emp => ({ value: emp.id, label: `${emp.firstName} ${emp.lastName}` }))}
                  />
                )}
              </div>

              <div className="flex gap-3 mt-7">
                <Button variant="ghost" onClick={() => setAssignAsset(null)}
                  className="flex-1 py-3.5 border border-[var(--border)] rounded-xl font-bold text-[var(--text-muted)] hover:bg-[var(--surface-2)] transition-colors">
                  Annuler
                </Button>
                <Button variant="primary" onClick={handleAssignSubmit} disabled={isAssigning || !selectedEmployeeId}
                  className="flex-1 py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl flex justify-center gap-2 transition-colors disabled:opacity-50 shadow-lg shadow-emerald-500/20">
                  {isAssigning && <Loader2 className="animate-spin" size={18} />} Confirmer
                </Button>
              </div>
            </Modal>
        )}
      </AnimatePresence>
    </div></div></ModulePageFrame>
  );
}
