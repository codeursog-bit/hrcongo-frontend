'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Users, Pencil , Wallet, Search, Filter, Trash2, AlertCircle, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ModulePageFrame, ModulePageSkeleton } from '@/components/requests/ModulePageFrame';
import { api } from '@/services/api';

import { PayrollStatsCards } from './components/PayrollStatsCards';
import { PayrollMonthSelector } from './components/PayrollMonthSelector';
import { PayrollTableRow } from './components/PayrollTableRow';
import { PayrollBatchActionsFooter } from './components/PayrollBatchActionsFooter';
import { PayrollPagination } from './components/PayrollPagination';
import BulletinBatchPrintHidden from '@/components/BulletinBatchPrintHidden';
import { printBulletinBatch } from '@/lib/bulletin-print';
import { usePayrollData } from '@/hooks/usePayrollData';
import { useBasePath } from '@/hooks/useBasePath';
import PayrollAuditBanner from '@/components/audit/PayrollAuditBanner';
import AuditBlockedModal from '@/components/audit/AuditBlockedModal';
import { auditBlockedOf, type AuditBlocked } from '@/services/audit-engine';

type PayrollStatus = 'Draft' | 'Validated' | 'ToPay' | 'Paid' | 'Cancelled';

const ITEMS_PER_PAGE = 25;

export default function PayrollPage() {
  const router = useRouter();
  const { bp } = useBasePath();
  const now    = new Date();
  const MONTHS = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];

  // ✅ Mois/année sélectionnés persistés en sessionStorage — sans ça, revenir
  // sur cette page (bouton retour depuis un bulletin, navigation interne...)
  // remonte le composant avec un state React tout neuf, qui retombe toujours
  // sur le mois en cours. On ne perd la sélection qu'à la fin de la session
  // (fermeture de l'onglet/navigateur ou déconnexion), ce qui est le
  // comportement voulu.
  const PAIE_MONTH_KEY = 'paie:selectedMonth';
  const PAIE_YEAR_KEY  = 'paie:selectedYear';

  const [selectedMonth, setSelectedMonthState] = useState(() => {
    if (typeof window === 'undefined') return MONTHS[now.getMonth()];
    return sessionStorage.getItem(PAIE_MONTH_KEY) || MONTHS[now.getMonth()];
  });
  const [selectedYear, setSelectedYearState] = useState(() => {
    if (typeof window === 'undefined') return now.getFullYear();
    const stored = sessionStorage.getItem(PAIE_YEAR_KEY);
    return stored ? Number(stored) : now.getFullYear();
  });

  const setSelectedMonth = (month: string) => {
    setSelectedMonthState(month);
    if (typeof window !== 'undefined') sessionStorage.setItem(PAIE_MONTH_KEY, month);
  };
  const setSelectedYear = (year: number) => {
    setSelectedYearState(year);
    if (typeof window !== 'undefined') sessionStorage.setItem(PAIE_YEAR_KEY, String(year));
  };
  const [activeTab,          setActiveTab]           = useState<'All' | PayrollStatus>('All');
  const [searchQuery,        setSearchQuery]         = useState('');
  const [selectedIds,        setSelectedIds]         = useState<string[]>([]);
  const [showFilters,        setShowFilters]         = useState(false);
  const [actionLoadingId,    setActionLoadingId]     = useState<string | null>(null);
  const [filterDept,         setFilterDept]          = useState('Tous');
  const [showMonthSelector,  setShowMonthSelector]   = useState(false);
  const [isBatchActionLoading, setIsBatchActionLoading] = useState(false);
  const [currentPage,        setCurrentPage]         = useState(1);

  // ── ÉTAT IMPRESSION GROUPÉE ───────────────────────────────────────────────
  // ✅ printBatchIds déclenche le montage hors-écran de BulletinBatchPrintHidden
  // (un par bulletin sélectionné, même rendu que l'impression à l'unité).
  // Une fois chargé+rendu, son onReady() lance l'impression puis on démonte.
  const [printBatchIds, setPrintBatchIds] = useState<string[] | null>(null);

  // ── ÉTAT MODAL SUPPRESSION ───────────────────────────────────────────────
  const [deleteModal, setDeleteModal] = useState<{ open: boolean; id: string; name: string }>({
    open: false, id: '', name: '',
  });
  const [isDeleting, setIsDeleting] = useState(false);

  const { entries, isLoading, stats, refetch, setEntries } = usePayrollData(selectedMonth, selectedYear);
  const [auditBlocked, setAuditBlocked] = useState<AuditBlocked | null>(null);
  const [auditRefresh, setAuditRefresh] = useState(0);

  // ── CHANGEMENT STATUT ────────────────────────────────────────────────────
  const handleStatusChange = async (id: string, newStatus: string) => {
    setActionLoadingId(id);
    const backendStatus  = newStatus.toUpperCase();
    const frontendStatus = newStatus === 'VALIDATED' ? 'Validated'
                         : newStatus === 'TO_PAY'    ? 'ToPay'
                         : newStatus === 'PAID'      ? 'Paid'
                         : newStatus === 'DRAFT'     ? 'Draft'
                         : 'Cancelled';
    try {
      if (newStatus === 'CANCELLED') {
        const cur = entries.find(e => e.id === id);
        if (cur?.status === 'Paid') {
          await api.delete(`/payrolls/${id}`);
        } else {
          await api.patch(`/payrolls/${id}`, { status: backendStatus });
        }
      } else {
        await api.patch(`/payrolls/${id}`, { status: backendStatus });
      }
      setEntries(prev => prev.map(e => e.id === id ? { ...e, status: frontendStatus as PayrollStatus } : e));
    } catch (e: any) {
      const b = auditBlockedOf(e);
      if (b) setAuditBlocked(b);
      else alert(`❌ ${e.message || 'Impossible de mettre à jour le statut'}`);
      setAuditRefresh(k => k + 1);
      refetch();
    } finally {
      setActionLoadingId(null);
    }
  };

  // ── SUPPRESSION DÉFINITIVE ────────────────────────────────────────────────
  const openDeleteModal = (id: string, name: string) => {
    setDeleteModal({ open: true, id, name });
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await api.delete(`/payrolls/${deleteModal.id}`);
      setEntries(prev => prev.filter(e => e.id !== deleteModal.id));
      setSelectedIds(prev => prev.filter(i => i !== deleteModal.id));
      setDeleteModal({ open: false, id: '', name: '' });
    } catch (e: any) {
      alert(`❌ ${e.message || 'Impossible de supprimer le bulletin'}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // ── ACTIONS EN MASSE ──────────────────────────────────────────────────────
  const handleBatchAction = async (action: string) => {
    if (selectedIds.length === 0) {
      alert('⚠️ Veuillez sélectionner au moins un bulletin');
      return;
    }
    const label = action === 'VALIDATED' ? 'Valider' : action === 'TO_PAY' ? 'Passer à payer' : 'Annuler';
    if (!confirm(`Voulez-vous vraiment ${label} ${selectedIds.length} bulletin(s) ?`)) return;

    setIsBatchActionLoading(true);
    let successCount = 0, failCount = 0;
    let blockedForModal: AuditBlocked | null = null;
    for (const id of selectedIds) {
      try {
        if (action === 'CANCELLED') {
          const cur = entries.find(e => e.id === id);
          if (cur?.status === 'Paid') await api.delete(`/payrolls/${id}`);
          else await api.patch(`/payrolls/${id}`, { status: action });
        } else {
          await api.patch(`/payrolls/${id}`, { status: action });
        }
        successCount++;
      } catch (e: any) {
        failCount++;
        // 🛡️ Refus du contrôle de paie : on garde le premier refus pour l'afficher
        const b = auditBlockedOf(e);
        if (b && !blockedForModal) blockedForModal = b;
      }
    }
    alert(`✅ ${successCount} réussis, ❌ ${failCount} échecs`);
    if (blockedForModal) setAuditBlocked(blockedForModal);
    setAuditRefresh(k => k + 1);
    setSelectedIds([]);
    refetch();
    setIsBatchActionLoading(false);
  };

  // ── IMPRESSION GROUPÉE ────────────────────────────────────────────────────
  // ✅ Réutilise le même DOM que l'impression à l'unité (BulletinDisplay) —
  // même gabarit choisi en paramètres, mêmes calculs, même logo. Pas de
  // génération séparée côté backend.
  const handleBatchPrint = () => {
    if (selectedIds.length === 0) {
      alert('⚠️ Veuillez sélectionner au moins un bulletin');
      return;
    }
    setPrintBatchIds(selectedIds);
  };

  // ── FILTRAGE + PAGINATION ─────────────────────────────────────────────────
  const filteredEntries = useMemo(() => entries.filter(entry => {
    const matchesTab    = activeTab === 'All' || entry.status === activeTab;
    const matchesSearch = entry.name.toLowerCase().includes(searchQuery.toLowerCase())
                       || entry.matricule.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept   = filterDept === 'Tous' || entry.department === filterDept;
    return matchesTab && matchesSearch && matchesDept;
  }), [entries, activeTab, searchQuery, filterDept]);

  const totalPages      = Math.ceil(filteredEntries.length / ITEMS_PER_PAGE);
  const paginatedEntries = filteredEntries.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE,
  );

  const toggleSelection = (id: string) =>
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);

  const selectAll = () =>
    setSelectedIds(selectedIds.length === paginatedEntries.length ? [] : paginatedEntries.map(e => e.id));

  if (isLoading) return <ModulePageSkeleton label="Chargement des bulletins de paie" />;

  return (
    <ModulePageFrame kind="list">
    <div className="space-y-6 min-h-screen pb-32" onClick={() => setShowMonthSelector(false)}>

      {/* ── HEADER ── */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-semibold text-[var(--text)]">Gestion de Paie</h1>
          <p className="text-[var(--text-muted)]">Gérez les bulletins, validations et paiements.</p>
        </div>

        <PayrollMonthSelector
          selectedMonth={selectedMonth}
          selectedYear={selectedYear}
          onMonthChange={m => { setSelectedMonth(m); setShowMonthSelector(false); setCurrentPage(1); }}
          onYearChange={y => { setSelectedYear(y); setCurrentPage(1); }}
          isOpen={showMonthSelector}
          onToggle={e => { e.stopPropagation(); setShowMonthSelector(!showMonthSelector); }}
        />

        <div data-guide="paie-modes" className="flex items-center gap-3">
          <Link data-guide="paie-manuelle" href={bp('/paie/manuel')}
            aria-label="Saisie manuelle de la paie"
            className="k-button k-button-secondary whitespace-nowrap">
            <Pencil size={18} />
            <span className="hidden sm:inline">Saisie manuelle</span>
          </Link>
          <Link data-guide="paie-masse" href={bp('/paie/masse')}
            aria-label="Paie en masse"
            className="k-button k-button-secondary whitespace-nowrap">
            <Users size={18} />
            <span className="hidden sm:inline">Paie en Masse</span>
          </Link>
          <Link data-guide="paie-individuelle" href={bp('/paie/nouveau')}
            aria-label="Créer une paie"
            className="k-button k-button-primary whitespace-nowrap">
            <Wallet size={18} />
            <span className="hidden sm:inline">Créer Paie</span>
          </Link>
        </div>
      </div>

      {/* ── STATS ── */}
      <PayrollAuditBanner month={Math.max(1, MONTHS.indexOf(selectedMonth) + 1)} year={selectedYear} refreshKey={auditRefresh} />

      <PayrollStatsCards
        totalGross={stats.totalGross}
        totalCharges={stats.totalCharges}
        totalNet={stats.totalNet}
        paidCount={stats.paidCount}
        totalActive={stats.totalActive}
      />

      {/* ── TABLE ── */}
      <div className="bg-[var(--surface)] rounded-2xl shadow-sm border border-[var(--border)] overflow-hidden flex flex-col">

        {/* Toolbar */}
        <div className="p-4 border-b border-[var(--border)] flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex bg-[var(--surface-2)] p-1 rounded-xl w-full sm:w-auto overflow-x-auto">
            {[
              { id: 'All',       label: 'Tous',       count: entries.length },
              { id: 'Draft',     label: 'Brouillons', count: entries.filter(e => e.status === 'Draft').length },
              { id: 'Validated', label: 'Validés',    count: entries.filter(e => e.status === 'Validated').length },
              { id: 'ToPay',     label: 'À payer',    count: entries.filter(e => e.status === 'ToPay').length },
              { id: 'Paid',      label: 'Payés',      count: entries.filter(e => e.status === 'Paid').length },
            ].map(tab => (
              <button key={tab.id}
                type="button"
                aria-pressed={activeTab === tab.id}
                onClick={() => { setActiveTab(tab.id as any); setCurrentPage(1); }}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap flex items-center gap-2
                  ${activeTab === tab.id ? 'bg-[var(--surface)] text-[var(--text)] shadow-sm' : 'text-[var(--text-muted)]'}`}
              >
                {tab.label}
                <span className={`text-xs px-1.5 py-0.5 rounded-full
                  ${activeTab === tab.id ? 'bg-[var(--surface-2)]' : 'bg-[var(--surface-2)]'}`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-secondary)]" size={16} />
              <input type="text" placeholder="Rechercher..." value={searchQuery}
                onChange={e => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                className="w-full pl-9 pr-4 py-2 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl text-sm focus:ring-2 focus:ring-[var(--focus)] focus:border-[var(--border)]"
              />
            </div>
            <button type="button" aria-label="Filtres" aria-pressed={showFilters} onClick={() => setShowFilters(!showFilters)}
              className={`p-2 rounded-xl border ${showFilters ? 'bg-[var(--brand-soft)]  border-[var(--border)]  text-[var(--action)] ' : 'border-[var(--border)] text-[var(--text-secondary)]'}`}>
              <Filter size={18} />
            </button>
          </div>
        </div>

        {/* Tableau */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-[var(--surface-2)] text-xs uppercase text-[var(--text-secondary)] font-semibold sticky top-0 z-10">
              <tr>
                <th className="px-6 py-4 w-10">
                  <span className="k-sr-only">Sélection</span>
                  <input type="checkbox"
                    aria-label="Sélectionner tous les bulletins de la page"
                    checked={selectedIds.length === paginatedEntries.length && paginatedEntries.length > 0}
                    onChange={selectAll}
                    className="rounded border-[var(--border)] text-[var(--success-text)] focus:ring-[var(--focus)]"
                  />
                </th>
                <th className="px-6 py-4">Employé</th>
                <th className="px-6 py-4">Poste</th>
                <th className="px-6 py-4 text-center">Jours</th>
                <th className="px-6 py-4 text-right">Salaire Net</th>
                <th className="px-6 py-4 text-center">Statut</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)] text-sm">
              {paginatedEntries.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-20 text-center">
                    <p className="text-[var(--text-secondary)]">Aucun bulletin trouvé.</p>
                  </td>
                </tr>
              ) : (
                paginatedEntries.map(entry => (
                  <PayrollTableRow
                    key={entry.id}
                    entry={entry}
                    isSelected={selectedIds.includes(entry.id)}
                    isActionLoading={actionLoadingId === entry.id}
                    onToggleSelect={() => toggleSelection(entry.id)}
                    onView={() => router.push(bp(`/paie/${entry.id}`))}
                    onStatusChange={status => handleStatusChange(entry.id, status)}
                    // ✅ NOUVEAU : modifier (seulement DRAFT) + supprimer définitivement
                    onEdit={entry.status === 'Draft'
                      ? () => router.push(bp(`/paie/${entry.id}/modifier`))
                      : undefined}
                    onDelete={entry.status === 'ToPay' || entry.status === 'Paid' ? undefined : () => openDeleteModal(entry.id, entry.name)}
                  />
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <PayrollPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        )}
      </div>

      {/* ── FOOTER BATCH ── */}
      <PayrollBatchActionsFooter
        selectedCount={selectedIds.length}
        isLoading={isBatchActionLoading}
        onValidate={() => handleBatchAction('VALIDATED')}
        onPay={() => handleBatchAction('TO_PAY')}
        onCancel={() => handleBatchAction('CANCELLED')}
        onClear={() => setSelectedIds([])}
        onPrintAll={handleBatchPrint}
        isPrinting={printBatchIds !== null}
      />

      {/* ── IMPRESSION GROUPÉE — rendu hors-écran, invisible, démonté après usage ── */}
      {printBatchIds && (
        <div className="loan-document-protected">
          <BulletinBatchPrintHidden
            payrollIds={printBatchIds}
            onReady={() => {
              printBulletinBatch('bul-batch-root');
              setPrintBatchIds(null);
            }}
            onError={(msg) => {
              alert(`❌ ${msg}`);
              setPrintBatchIds(null);
            }}
          />
        </div>
      )}

      {/* ── MODAL SUPPRESSION DÉFINITIVE ── */}
      <AnimatePresence>
        {deleteModal.open && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-[rgb(0_0_0_/.48)]  p-4"
            onClick={() => !isDeleting && setDeleteModal({ open: false, id: '', name: '' })}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
              onClick={e => e.stopPropagation()}
              className="bg-[var(--surface)] rounded-2xl p-6 max-w-sm w-full shadow-2xl"
            >
              <div className="flex flex-col items-center text-center">
                {/* Icône */}
                <div className="w-16 h-16 bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  rounded-full flex items-center justify-center mb-4">
                  <Trash2 size={32} className="text-[var(--danger-text)] " />
                </div>

                <h3 className="text-xl font-semibold text-[var(--text)] mb-2">
                  Supprimer définitivement ?
                </h3>
                <p className="text-[var(--text-muted)] text-sm mb-3">
                  Le bulletin de <strong className="text-[var(--text)]">{deleteModal.name}</strong> sera supprimé de la base de données.
                </p>

                {/* Avertissement */}
                <div className="w-full mb-5 p-3 bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  border border-[var(--border)]  rounded-xl flex items-start gap-2 text-left">
                  <AlertCircle size={14} className="text-[var(--danger-text)]  shrink-0 mt-0.5" />
                  <p className="text-xs text-[var(--danger-text)]  font-medium">
                    Action irréversible. Vous devrez recréer le bulletin si nécessaire.
                  </p>
                </div>

                <div className="flex gap-3 w-full">
                  <button
                    onClick={() => setDeleteModal({ open: false, id: '', name: '' })}
                    disabled={isDeleting}
                    className="flex-1 py-3 border border-[var(--border)] rounded-xl font-semibold hover:bg-[var(--surface-2)] transition-colors disabled:opacity-50"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={handleDelete}
                    disabled={isDeleting}
                    className="flex-1 py-3 bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] hover:bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] text-[var(--danger-text)] font-semibold rounded-xl flex justify-center items-center gap-2 transition-colors disabled:opacity-50"
                  >
                    {isDeleting ? <Loader2 className="animate-spin" size={20} /> : <Trash2 size={18} />}
                    {isDeleting ? 'Suppression...' : 'Supprimer'}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {auditBlocked && (
        <AuditBlockedModal
          blocked={auditBlocked}
          month={Math.max(1, MONTHS.indexOf(selectedMonth) + 1)}
          year={selectedYear}
          onClose={() => setAuditBlocked(null)}
          onRetry={() => { setAuditBlocked(null); refetch(); }}
        />
      )}
    </div>
    </ModulePageFrame>
  );
}
