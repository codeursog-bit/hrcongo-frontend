'use client';

import React, { useState, useEffect } from 'react';
import {
  FlaskConical, Play, Plus, Trash2, ChevronDown, ChevronUp,
  Copy, Check, Loader2, AlertCircle, Info,
  Clock, Gift, Minus, User, Calculator, Users, UserPlus,
  Percent, Lock, Unlock, Building2, CreditCard
} from 'lucide-react';
import { api } from '@/services/api';
import { PayslipBreakdown } from '@/components/payroll/PayslipBreakdown';
import { ModulePageFrame } from '@/components/requests/ModulePageFrame';

interface Employee { id: string; firstName: string; lastName: string; baseSalary: number; }

interface ManualBonus {
  localId: string; bonusType: string; amount: number; isTaxable: boolean; isCnss: boolean;
}

interface ManualAdvance {
  localId: string; label: string; amount: number;
}

interface SimResult {
  employee: {
    id?: string; firstName: string; lastName: string;
    baseSalary: number; effectiveBaseSalary: number;
    isSubjectToCnss: boolean; isSubjectToIrpp: boolean;
  };
  month: number; year: number; daysToPay: number; workDays: number;
  overtime: { hours10: number; amount10: number; hours25: number; amount25: number; hours50: number; amount50: number; hours100: number; amount100: number; total: number; };
  bonuses: Array<{ id: string; bonusType: string; amount: number; source: string; isTaxable: boolean; isCnss: boolean; fiscalType?: 'TAXABLE_CNSS' | 'TAXABLE_NO_CNSS' | 'NON_TAXABLE'; }>;
  totalBonuses: number; adjustedBaseSalary: number; absenceDeduction: number;
  grossSalary: number;
  cnssSalarial: number; cnssEmployer: number;
  cnssEmployerPension: number; cnssEmployerFamily: number; cnssEmployerAccident: number;
  // ✅ TUS — 3 champs
  tusDgiAmount: number;
  tusCnssAmount: number;
  tusTotal: number;
  its: number; irppDetails: any;
  totalLoanDeduction: number; totalAdvanceDeduction: number; totalDeductions: number;
  netSalary: number; totalEmployerCost: number; simulationMode: string;
  customTaxes?: any[]; isBncWorker?: boolean; bncLabel?: string; contractType?: string;
}

const MONTHS = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
type FiscalMode = 'AUTO' | 'ITS_2026' | 'IRPP_LEGACY' | 'FORFAIT';
const FISCAL_MODES: { value: FiscalMode; label: string; sub: string; color: string }[] = [
  { value: 'AUTO',        label: 'Auto',        sub: "Selon l'année",       color: 'gray'   },
  { value: 'ITS_2026',    label: 'ITS 2026',    sub: 'Barème progressif',   color: 'violet' },
  { value: 'IRPP_LEGACY', label: 'IRPP Ancien', sub: 'Avant 2026 / parts',  color: 'amber'  },
  { value: 'FORFAIT',     label: 'Forfait',      sub: 'Taux fixe 6/8/10%',  color: 'cyan'   },
];

const fmt = (v: number) => Math.round(v ?? 0).toLocaleString('fr-FR');
const uid = () => Math.random().toString(36).slice(2, 9);

const BonusFiscalBadge = ({ label, active, onChange, color }: { label: string; active: boolean; onChange: () => void; color: string }) => (
  <button onClick={onChange} className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border transition-colors cursor-pointer select-none
    ${active ? color === 'cyan' ? 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))]  text-[var(--warning-text)]  border-[var(--border)] '
      : 'bg-[var(--brand-soft)]  text-[var(--action)]  border-[var(--border)] '
    : 'bg-[var(--surface-2)]  text-[var(--text-secondary)] border-[var(--border)]  line-through opacity-60'}`}>
    {label}
  </button>
);

const ResultRow = ({ label, sub, value, valueColor, bold }: { label: string; sub?: string; value: string; valueColor?: string; bold?: boolean; }) => (
  <tr className="border-b border-[var(--border)] ">
    <td className="px-4 py-2.5 text-[var(--text-secondary)] ">
      <span className={bold ? 'font-semibold text-[var(--text-secondary)]  text-sm' : 'text-sm'}>{label}</span>
      {sub && <p className="text-[10px] text-[var(--text-secondary)] mt-0.5 leading-tight">{sub}</p>}
    </td>
    <td className={`px-4 py-2.5 text-right font-mono font-semibold text-sm ${valueColor ?? 'text-[var(--text-secondary)] '}`}>{value}</td>
  </tr>
);

const TotalRow = ({ label, value, bgClass, textClass }: { label: string; value: string; bgClass: string; textClass: string; }) => (
  <tr className={bgClass}>
    <td className={`px-4 py-3 font-semibold text-sm ${textClass}`}>{label}</td>
    <td className={`px-4 py-3 text-right font-semibold font-mono text-base ${textClass}`}>{value}</td>
  </tr>
);

export default function SimulateurPage() {
  const [mode, setMode]               = useState<'existing' | 'free'>('existing');
  const [employees, setEmployees]     = useState<Employee[]>([]);
  const [selectedEmp, setSelectedEmp] = useState<Employee | null>(null);
  const [empSearch, setEmpSearch]     = useState('');
  const [showDropdown, setShowDropdown] = useState(false);

  // Free mode identity
  const [freeFirstName, setFreeFirstName] = useState('');
  const [freeLastName, setFreeLastName]   = useState('');

  // Rémunération
  const [month, setMonth]         = useState(new Date().getMonth() + 1);
  const [year, setYear]           = useState(new Date().getFullYear());
  const [baseSalary, setBaseSalary] = useState('');
  const [workedDays, setWorkedDays] = useState(26);
  const workDays = 26;

  // Heures sup
  const [ot10, setOt10]   = useState(0);
  const [ot25, setOt25]   = useState(0);
  const [ot50, setOt50]   = useState(0);
  const [ot100, setOt100] = useState(0);

  // Primes manuelles
  const [manualBonuses, setManualBonuses] = useState<ManualBonus[]>([]);

  // ✅ Avances manuelles (pour simuler la déduction)
  const [manualAdvances, setManualAdvances] = useState<ManualAdvance[]>([]);

  // Fiscal (libre uniquement)
  const [fiscalMode, setFiscalMode]   = useState<FiscalMode>('AUTO');
  const [forfaitRate, setForfaitRate] = useState(0.08);
  const [isSubjectCnss, setIsSubjectCnss] = useState(true);
  const [isSubjectIts, setIsSubjectIts]   = useState(true);
  const [maritalStatus, setMaritalStatus] = useState<'SINGLE'|'MARRIED'|'DIVORCED'|'WIDOWED'>('SINGLE');
  const [nbChildren, setNbChildren]       = useState(0);
  const [contractType, setContractType]   = useState('CDI');
  const [tolZone, setTolZone]             = useState<'VILLE'|'PERIPHERIE'>('VILLE');
  const [isResident, setIsResident]       = useState(true);

  const [isSimulating, setIsSimulating] = useState(false);
  const [result, setResult]   = useState<SimResult | null>(null);
  const [error, setError]     = useState('');
  const [showItsDetail, setShowItsDetail] = useState(false);
  const [showEmpDetail, setShowEmpDetail] = useState(true);
  const [copied, setCopied]   = useState(false);

  useEffect(() => {
    api.get('/employees?limit=500').then((data: any) => {
      setEmployees(Array.isArray(data) ? data : data?.data || data?.employees || []);
    }).catch(() => {});
  }, []);

  const filteredEmps = empSearch.length >= 2
    ? employees.filter(e => `${e.firstName} ${e.lastName}`.toLowerCase().includes(empSearch.toLowerCase())).slice(0, 8)
    : [];

  const handleSelectEmployee = (emp: Employee) => {
    setSelectedEmp(emp); setEmpSearch(`${emp.firstName} ${emp.lastName}`);
    setBaseSalary(String(emp.baseSalary)); setShowDropdown(false); setResult(null); setError('');
  };

  const switchMode = (m: 'existing' | 'free') => {
    setMode(m); setResult(null); setError(''); setSelectedEmp(null);
    setEmpSearch(''); setBaseSalary(''); setManualBonuses([]); setManualAdvances([]);
    setOt10(0); setOt25(0); setOt50(0); setOt100(0);
  };

  const addBonus   = () => setManualBonuses(b => [...b, { localId: uid(), bonusType: '', amount: 0, isTaxable: true, isCnss: true }]);
  const addAdvance = () => setManualAdvances(a => [...a, { localId: uid(), label: 'Avance sur salaire', amount: 0 }]);
  const updateBonus   = (id: string, patch: Partial<ManualBonus>)   => setManualBonuses(p => p.map(b => b.localId === id ? { ...b, ...patch } : b));
  const updateAdvance = (id: string, patch: Partial<ManualAdvance>) => setManualAdvances(p => p.map(a => a.localId === id ? { ...a, ...patch } : a));

  const canSimulate = mode === 'existing'
    ? !!selectedEmp && !!baseSalary
    : !!baseSalary && Number(baseSalary) >= 70400;

  const handleSimulate = async () => {
    if (!canSimulate) { setError(mode === 'existing' ? 'Sélectionne un employé.' : 'Salaire de base requis (min. 70 400 FCFA).'); return; }
    setIsSimulating(true); setError(''); setResult(null);
    const validBonuses  = manualBonuses.filter(b => b.bonusType.trim() && b.amount > 0);
    const validAdvances = manualAdvances.filter(a => a.amount > 0);
    try {
      let data: SimResult;
      if (mode === 'existing') {
        const payload: Record<string, any> = {
          employeeId: selectedEmp!.id, month, year,
          baseSalary: Number(baseSalary) || selectedEmp!.baseSalary,
          workedDays, overtimeHours10: ot10, overtimeHours25: ot25, overtimeHours50: ot50, overtimeHours100: ot100,
        };
        if (validBonuses.length  > 0) payload.manualBonuses  = validBonuses.map(b => ({ bonusType: b.bonusType, amount: b.amount, isTaxable: b.isTaxable, isCnss: b.isCnss, fiscalType: !b.isTaxable ? 'NON_TAXABLE' : (b.isCnss ? 'TAXABLE_CNSS' : 'TAXABLE_NO_CNSS') }));
        // Avances : si le backend les supporte on les envoie, sinon on les ajoute manuellement au résultat
        if (validAdvances.length > 0) payload.manualAdvances = validAdvances.map(a => ({ label: a.label, amount: a.amount }));
        data = await api.post<SimResult>('/payrolls/simulate', payload);
      } else {
        const payload: Record<string, any> = {
          firstName: freeFirstName || 'Anonyme', lastName: freeLastName || '',
          baseSalary: Number(baseSalary), workedDays, workDays, month, year,
          overtimeHours10: ot10, overtimeHours25: ot25, overtimeHours50: ot50, overtimeHours100: ot100,
          isSubjectToCnss: isSubjectCnss, isSubjectToIrpp: isSubjectIts,
          maritalStatus, numberOfChildren: nbChildren, fiscalMode,
          contractType, tolZone, isResident,
          forfaitItsRate: fiscalMode === 'FORFAIT' ? forfaitRate : undefined,
        };
        if (validBonuses.length  > 0) payload.manualBonuses  = validBonuses.map(b => ({ bonusType: b.bonusType, amount: b.amount, isTaxable: b.isTaxable, isCnss: b.isCnss, fiscalType: !b.isTaxable ? 'NON_TAXABLE' : (b.isCnss ? 'TAXABLE_CNSS' : 'TAXABLE_NO_CNSS') }));
        if (validAdvances.length > 0) payload.manualAdvances = validAdvances.map(a => ({ label: a.label, amount: a.amount }));
        data = await api.post<SimResult>('/payrolls/simulate-free', payload);
      }

      // ── Patch côté front si le backend n'a pas pris en compte les avances manuelles ──
      // On vérifie si les avances manuelles sont déjà dans totalDeductions
      const advanceSum = validAdvances.reduce((s, a) => s + a.amount, 0);
      if (advanceSum > 0 && (data.totalAdvanceDeduction ?? 0) === 0) {
        // Le backend ne les a pas pris → on ajuste le net manuellement pour la simulation
        data = {
          ...data,
          totalAdvanceDeduction: advanceSum,
          totalDeductions: data.totalDeductions + advanceSum,
          netSalary: Math.max(0, data.netSalary - advanceSum),
        };
      }

      setResult(data);
    } catch (e: any) {
      setError(e?.response?.data?.message || e?.message || 'Erreur lors de la simulation.');
    } finally { setIsSimulating(false); }
  };

  const handleCopy = () => {
    if (!result) return;
    const name = [result.employee.firstName, result.employee.lastName].filter(Boolean).join(' ');
    const cnssPatTotal = (result.cnssEmployerPension ?? 0) + (result.cnssEmployerFamily ?? 0) + (result.cnssEmployerAccident ?? 0);
    const tusTotal = result.tusTotal ?? 0;
    const lines = [
      `Simulation — ${name || 'Anonyme'} — ${MONTHS[result.month-1]} ${result.year}`,
      '─'.repeat(55),
      `Salaire brut             : ${fmt(result.grossSalary)} FCFA`,
      `CNSS salarié (4%)        : −${fmt(result.cnssSalarial)} FCFA`,
      `ITS                      : −${fmt(result.its)} FCFA`,
      `─`.repeat(55),
      `NET À PAYER              : ${fmt(result.netSalary)} FCFA`,
      `─`.repeat(55),
      `PART PATRONALE`,
      `  CNSS Pensions (8%)     : +${fmt(result.cnssEmployerPension ?? 0)} FCFA`,
      `  CNSS Famille (10,03%)  : +${fmt(result.cnssEmployerFamily ?? 0)} FCFA`,
      `  CNSS Accident (2,25%)  : +${fmt(result.cnssEmployerAccident ?? 0)} FCFA`,
      `  TUS FISC (2,025%)        : +${fmt(result.tusDgiAmount ?? 0)} FCFA`,
      `  TUS CNSS (5,475%)       : +${fmt(result.tusCnssAmount ?? 0)} FCFA`,
      `  Total patronal         : +${fmt(cnssPatTotal + tusTotal)} FCFA`,
      `─`.repeat(55),
      `COÛT TOTAL EMPLOYEUR     : ${fmt(result.totalEmployerCost)} FCFA`,
    ].join('\n');
    navigator.clipboard.writeText(lines).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2200); });
  };

  const absenceDays   = Math.max(0, workDays - workedDays);
  const isLegacyMode  = result?.irppDetails?.fiscalMode === 'IRPP_LEGACY' || result?.irppDetails?.mode === 'IRPP_LEGACY';
  const isForfait     = result?.irppDetails?.fiscalMode === 'FORFAIT'     || result?.irppDetails?.mode === 'FORFAIT';
  const abattementLabel = isLegacyMode ? 'Abattement 30% (plafonné 75 000/mois)' : 'Abattement 20%';

  const cnssPatPension  = result?.cnssEmployerPension  ?? 0;
  const cnssPatFamily   = result?.cnssEmployerFamily   ?? 0;
  const cnssPatAccident = result?.cnssEmployerAccident ?? 0;
  const tusDgi          = result?.tusDgiAmount  ?? 0;
  const tusCnss         = result?.tusCnssAmount ?? 0;
  const tusTotal        = result?.tusTotal      ?? 0;
  const cnssPatTotal    = cnssPatPension + cnssPatFamily + cnssPatAccident;
  const totalChargesEmp = cnssPatTotal + tusTotal;

  const OtRow = ({ label, sub, value, onChange }: { label: string; sub: string; value: number; onChange: (v: number) => void }) => (
    <div className="flex items-center gap-3 px-4 py-2.5 bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))]  rounded-xl mb-1.5">
      <div className="w-14 shrink-0">
        <span className="font-semibold text-[var(--warning-text)]  text-sm">{label}</span>
        <p className="text-[10px] text-[var(--text-secondary)] mt-0.5 leading-tight">{sub}</p>
      </div>
      <button onClick={() => onChange(Math.max(0, +(value - 0.5).toFixed(1)))} className="w-7 h-7 rounded-lg border border-[var(--border)]  bg-[var(--surface)]  flex items-center justify-center hover:bg-[var(--surface-2)] cursor-pointer"><Minus size={11} /></button>
      <span className="w-12 text-center font-semibold font-mono text-sm">{value.toFixed(1)}</span>
      <button onClick={() => onChange(+(value + 0.5).toFixed(1))} className="w-7 h-7 rounded-lg border border-[var(--border)]  bg-[var(--surface)]  flex items-center justify-center hover:bg-[var(--surface-2)] cursor-pointer"><Plus size={11} /></button>
      <span className="text-xs text-[var(--text-secondary)]">h</span>
    </div>
  );

  return (
    <ModulePageFrame kind="list">
      <div className="max-w-[1100px] mx-auto px-4 py-6 pb-20">

      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 rounded-xl bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] flex items-center justify-center shadow-lg ">
          <FlaskConical size={18} color="white" />
        </div>
        <div>
          <h1 className="text-xl font-semibold text-[var(--text)] dark:text-[var(--on-brand)]">Simulateur de paie</h1>
          <p className="text-xs text-[var(--text-secondary)] ">Calcul 100% backend · Conforme droit congolais · TUS 7,51% (DGI 2,025% + CNSS 5,475%)</p>
        </div>
      </div>

      {/* Mode selector */}
      <div className="flex gap-3 mb-5">
        {[
          { key: 'existing', label: 'Employé existant', sub: "Depuis la liste de l'entreprise", icon: Users,    color: 'violet' },
          { key: 'free',     label: 'Simulation libre', sub: 'Vérifier un bulletin · sans compte', icon: UserPlus, color: 'cyan'   },
        ].map(m => (
          <button key={m.key} onClick={() => switchMode(m.key as any)}
            className={`flex-1 flex items-center gap-3 p-4 rounded-2xl border-2 transition-all cursor-pointer text-left
              ${mode === m.key
                ? m.color === 'violet' ? 'border-[var(--border)] bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] ' : 'border-[var(--border)] bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] '
                : 'border-[var(--border)]  bg-[var(--surface)]  hover:border-[var(--border)]'}`}>
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${mode === m.key ? m.color === 'violet' ? 'bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] text-[var(--success-text)]' : 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] text-[var(--warning-text)]' : 'bg-[var(--surface-2)]  text-[var(--text-secondary)]'}`}>
              <m.icon size={16} />
            </div>
            <div>
              <p className={`font-semibold text-sm ${mode === m.key ? m.color === 'violet' ? 'text-[var(--success-text)] ' : 'text-[var(--warning-text)] ' : 'text-[var(--text-secondary)] '}`}>{m.label}</p>
              <p className="text-[11px] text-[var(--text-secondary)]">{m.sub}</p>
            </div>
            {mode === m.key && <div className={`ml-auto w-2 h-2 rounded-full ${m.color === 'violet' ? 'bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]' : 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))]'}`} />}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 items-start">

        {/* ══ FORMULAIRE ══════════════════════════════════════════════════ */}
        <div className="space-y-4">

          {/* Identité */}
          {mode === 'existing' ? (
            <div className="bg-[var(--surface)]  border border-[var(--border)]  rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3"><User size={14} className="text-[var(--success-text)]" /><h3 className="font-semibold text-sm text-[var(--text)] dark:text-[var(--on-brand)]">Employé</h3></div>
              <div className="relative">
                <input type="text" placeholder="Rechercher un employé..." value={empSearch}
                  onChange={e => { setEmpSearch(e.target.value); setShowDropdown(true); if (!e.target.value) setSelectedEmp(null); }}
                  onFocus={() => setShowDropdown(true)}
                  className={`w-full px-3 py-2.5 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-[var(--focus)]
                    ${selectedEmp ? 'border-[var(--border)] bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] ' : 'border-[var(--border)]  bg-[var(--surface)] '}`} />
                {showDropdown && filteredEmps.length > 0 && (
                  <div className="absolute top-full left-0 right-0 z-50 mt-1 bg-[var(--surface)]  border border-[var(--border)]  rounded-xl shadow-2xl overflow-hidden max-h-52 overflow-y-auto">
                    {filteredEmps.map(e => (
                      <button key={e.id} onMouseDown={() => handleSelectEmployee(e)}
                        className="w-full text-left px-3 py-2.5 hover:bg-[var(--surface-2)]  flex justify-between items-center border-b border-[var(--border)]  last:border-0 cursor-pointer">
                        <span className="font-semibold text-sm">{e.firstName} {e.lastName}</span>
                        <span className="text-xs text-[var(--text-secondary)] font-mono">{fmt(e.baseSalary)} F</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-[var(--surface)]  border border-[var(--border)]  rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3"><UserPlus size={14} className="text-[var(--warning-text)]" /><h3 className="font-semibold text-sm text-[var(--text)] dark:text-[var(--on-brand)]">Identité <span className="font-normal text-[var(--text-secondary)]">(optionnel)</span></h3></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Prénom</label>
                  <input type="text" value={freeFirstName} placeholder="Jean" onChange={e => setFreeFirstName(e.target.value)} className="w-full px-3 py-2.5 border border-[var(--border)]  rounded-xl text-sm bg-[var(--surface)]  outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Nom</label>
                  <input type="text" value={freeLastName} placeholder="Dupont" onChange={e => setFreeLastName(e.target.value)} className="w-full px-3 py-2.5 border border-[var(--border)]  rounded-xl text-sm bg-[var(--surface)]  outline-none" />
                </div>
              </div>
            </div>
          )}

          {/* Rémunération */}
          <div className="bg-[var(--surface)]  border border-[var(--border)]  rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3"><Calculator size={14} className="text-[var(--success-text)]" /><h3 className="font-semibold text-sm text-[var(--text)] dark:text-[var(--on-brand)]">Rémunération</h3></div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Mois</label>
                <select value={month} onChange={e => setMonth(Number(e.target.value))} className="w-full px-3 py-2 border border-[var(--border)]  rounded-xl text-sm bg-[var(--surface)]  outline-none cursor-pointer">
                  {MONTHS.map((m, i) => <option key={i} value={i+1}>{m}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Année</label>
                <input type="number" value={year} onChange={e => setYear(Number(e.target.value))} className="w-full px-3 py-2 border border-[var(--border)]  rounded-xl text-sm bg-[var(--surface)]  outline-none" />
              </div>
            </div>
            <div className="mb-3">
              <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Salaire de base (FCFA)</label>
              <input type="number" value={baseSalary} onChange={e => setBaseSalary(e.target.value)} placeholder="Ex: 500 000"
                className="w-full px-3 py-2.5 border border-[var(--border)]  rounded-xl text-sm font-semibold font-mono bg-[var(--surface)]  outline-none focus:ring-2 focus:ring-[var(--focus)] focus:border-[var(--border)]" />
              {mode === 'free' && Number(baseSalary) > 0 && Number(baseSalary) < 70400 && (
                <p className="text-[10px] text-[var(--danger-text)] mt-1">⚠ En dessous du SMIG (70 400 FCFA)</p>
              )}
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Jours travaillés (sur {workDays})</label>
              <div className="flex items-center gap-2.5 mb-2">
                <button onClick={() => setWorkedDays(d => Math.max(0, d-1))} className="w-8 h-8 rounded-lg border border-[var(--border)]  bg-[var(--surface)]  flex items-center justify-center hover:bg-[var(--surface-2)] cursor-pointer"><Minus size={12} /></button>
                <input type="number" min={0} max={workDays} value={workedDays} onChange={e => setWorkedDays(Math.min(workDays, Math.max(0, Number(e.target.value))))}
                  className="w-16 text-center font-semibold text-lg font-mono border border-[var(--border)]  rounded-xl py-1.5 bg-[var(--surface)]  outline-none" />
                <button onClick={() => setWorkedDays(d => Math.min(workDays, d+1))} className="w-8 h-8 rounded-lg border border-[var(--border)]  bg-[var(--surface)]  flex items-center justify-center hover:bg-[var(--surface-2)] cursor-pointer"><Plus size={12} /></button>
                {absenceDays > 0 ? <span className="text-xs font-semibold text-[var(--warning-text)]">→ {absenceDays}j absence</span> : <span className="text-xs font-semibold text-[var(--success-text)]">✓ Mois complet</span>}
              </div>
              <div className="h-1.5 rounded-full bg-[var(--surface-2)]  overflow-hidden">
                <div className="h-full rounded-full transition-all duration-300" style={{ width: `${(workedDays / workDays) * 100}%`, background: absenceDays === 0 ? 'var(--green)' : 'var(--mustard)' }} />
              </div>
            </div>
          </div>

          {/* Mode fiscal — libre uniquement */}
          {mode === 'free' && (
            <div className="bg-[var(--surface)]  border border-[var(--border)]  rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3"><Percent size={14} className="text-[var(--warning-text)]" /><h3 className="font-semibold text-sm text-[var(--text)] dark:text-[var(--on-brand)]">Mode fiscal & cotisations</h3></div>
              <div className="grid grid-cols-2 gap-2 mb-4">
                <button onClick={() => setIsSubjectCnss(v => !v)}
                  className={`flex items-center gap-2 p-3 rounded-xl border-2 transition-all cursor-pointer ${isSubjectCnss ? 'border-[var(--border)] bg-[var(--brand-soft)] ' : 'border-[var(--border)] '}`}>
                  {isSubjectCnss ? <Lock size={13} className="text-[var(--success-text)] shrink-0" /> : <Unlock size={13} className="text-[var(--text-secondary)] shrink-0" />}
                  <div className="text-left">
                    <p className={`text-xs font-semibold ${isSubjectCnss ? 'text-[var(--success-text)] ' : 'text-[var(--text-secondary)]'}`}>CNSS</p>
                    <p className="text-[10px] text-[var(--text-secondary)]">{isSubjectCnss ? 'Assujetti (4%)' : 'Exonéré'}</p>
                  </div>
                </button>
                <button onClick={() => setIsSubjectIts(v => !v)}
                  className={`flex items-center gap-2 p-3 rounded-xl border-2 transition-all cursor-pointer ${isSubjectIts ? 'border-[var(--border)] bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] ' : 'border-[var(--border)] '}`}>
                  {isSubjectIts ? <Lock size={13} className="text-[var(--warning-text)] shrink-0" /> : <Unlock size={13} className="text-[var(--text-secondary)] shrink-0" />}
                  <div className="text-left">
                    <p className={`text-xs font-semibold ${isSubjectIts ? 'text-[var(--warning-text)] ' : 'text-[var(--text-secondary)]'}`}>ITS / IRPP</p>
                    <p className="text-[10px] text-[var(--text-secondary)]">{isSubjectIts ? 'Assujetti' : 'Exonéré'}</p>
                  </div>
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Type de contrat</label>
                  <select value={contractType} onChange={e => setContractType(e.target.value)}
                    className="w-full px-2 py-2 border border-[var(--border)]  rounded-lg text-xs bg-[var(--surface)]  outline-none cursor-pointer">
                    <option value="CDI">CDI</option>
                    <option value="CDD">CDD</option>
                    <option value="STAGE">Stage</option>
                    <option value="INTERIM">Intérim</option>
                    <option value="CONSULTANT">Consultant (BNC)</option>
                    <option value="PRESTATAIRE">Prestataire (BNC)</option>
                  </select>
                </div>
                {(contractType === 'CDI' || contractType === 'CDD') && (
                  <div>
                    <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Zone TOL</label>
                    <select value={tolZone} onChange={e => setTolZone(e.target.value as any)}
                      className="w-full px-2 py-2 border border-[var(--border)]  rounded-lg text-xs bg-[var(--surface)]  outline-none cursor-pointer">
                      <option value="VILLE">Ville — 5 000 F</option>
                      <option value="PERIPHERIE">Périphérie — 1 000 F</option>
                    </select>
                  </div>
                )}
                {(contractType === 'CONSULTANT' || contractType === 'PRESTATAIRE') && (
                  <div>
                    <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1.5">Résidence fiscale</label>
                    <select value={isResident ? 'R' : 'N'} onChange={e => setIsResident(e.target.value === 'R')}
                      className="w-full px-2 py-2 border border-[var(--border)]  rounded-lg text-xs bg-[var(--surface)]  outline-none cursor-pointer">
                      <option value="R">Résident — BNC 10 %</option>
                      <option value="N">Non-résident — BNC 20 %</option>
                    </select>
                  </div>
                )}
              </div>
              <label className="block text-[10px] font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2">Mode de calcul ITS</label>
              <div className="grid grid-cols-2 gap-2 mb-3">
                {FISCAL_MODES.map(fm => {
                  const isActive = fiscalMode === fm.value;
                  const ac = fm.color === 'violet' ? 'border-[var(--border)] bg-[var(--brand-soft)] ' : fm.color === 'amber' ? 'border-[var(--border)] bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] ' : fm.color === 'cyan' ? 'border-[var(--border)] bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] ' : 'border-[var(--border)] bg-[var(--surface-2)] ';
                  const tc = fm.color === 'violet' ? 'text-[var(--success-text)] ' : fm.color === 'amber' ? 'text-[var(--warning-text)] ' : fm.color === 'cyan' ? 'text-[var(--warning-text)] ' : 'text-[var(--text-secondary)] ';
                  return (
                    <button key={fm.value} onClick={() => setFiscalMode(fm.value)}
                      className={`p-2.5 rounded-xl border-2 text-left transition-all cursor-pointer ${isActive ? ac : 'border-[var(--border)]  hover:border-[var(--border)]'}`}>
                      <p className={`text-xs font-semibold ${isActive ? tc : 'text-[var(--text-secondary)] '}`}>{fm.label}</p>
                      <p className="text-[10px] text-[var(--text-secondary)]">{fm.sub}</p>
                    </button>
                  );
                })}
              </div>
              {fiscalMode === 'FORFAIT' && (
                <div className="p-3 bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))]  rounded-xl border border-[var(--border)]  mt-2">
                  <label className="block text-[10px] font-semibold text-[var(--warning-text)]  uppercase tracking-wider mb-2">Taux forfaitaire ITS</label>
                  <div className="flex gap-2 mb-2">
                    {[{ label: '6%', value: 0.06 }, { label: '8%', value: 0.08 }, { label: '10%', value: 0.10 }].map(p => (
                      <button key={p.value} onClick={() => setForfaitRate(p.value)}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${forfaitRate === p.value ? 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] text-[var(--warning-text)] border-[var(--border)]' : 'bg-[var(--surface)]  text-[var(--text-secondary)] border-[var(--border)] hover:border-[var(--border)]'}`}>
                        {p.label}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="number" min={1} max={40} step={0.5} value={Math.round(forfaitRate * 100 * 10) / 10} onChange={e => setForfaitRate(Number(e.target.value) / 100)}
                      className="w-20 px-2 py-1.5 border border-[var(--border)]  rounded-lg text-sm font-mono font-semibold bg-[var(--surface)]  text-[var(--warning-text)]  outline-none" />
                    <span className="text-sm text-[var(--text-secondary)]">%</span>
                  </div>
                </div>
              )}
              {fiscalMode !== 'FORFAIT' && (
                <div className="p-3 bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))]  rounded-xl border border-[var(--border)]  mt-3">
                  <label className="block text-[10px] font-semibold text-[var(--warning-text)]  uppercase tracking-wider mb-2">Situation familiale (parts fiscales)</label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-[var(--text-secondary)] mb-1">Situation</label>
                      <select value={maritalStatus} onChange={e => setMaritalStatus(e.target.value as any)}
                        className="w-full px-2 py-2 border border-[var(--border)]  rounded-lg text-xs bg-[var(--surface)]  outline-none cursor-pointer">
                        <option value="SINGLE">Célibataire</option>
                        <option value="MARRIED">Marié(e)</option>
                        <option value="DIVORCED">Divorcé(e)</option>
                        <option value="WIDOWED">Veuf/Veuve</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] text-[var(--text-secondary)] mb-1">Enfants</label>
                      <div className="flex items-center gap-1.5">
                        <button onClick={() => setNbChildren(n => Math.max(0, n-1))} className="w-7 h-7 rounded-lg border border-[var(--border)]  bg-[var(--surface)]  flex items-center justify-center cursor-pointer text-[var(--warning-text)]"><Minus size={10} /></button>
                        <span className="w-8 text-center font-semibold text-sm font-mono">{nbChildren}</span>
                        <button onClick={() => setNbChildren(n => Math.min(10, n+1))} className="w-7 h-7 rounded-lg border border-[var(--border)]  bg-[var(--surface)]  flex items-center justify-center cursor-pointer text-[var(--warning-text)]"><Plus size={10} /></button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Heures sup */}
          <div className="bg-[var(--surface)]  border border-[var(--border)]  rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3"><Clock size={14} className="text-[var(--warning-text)]" /><h3 className="font-semibold text-sm text-[var(--text)] dark:text-[var(--on-brand)]">Heures supplémentaires</h3><span className="ml-auto text-[10px] text-[var(--text-secondary)]">Décret 78-360</span></div>
            <OtRow label="+10%"  sub="5 premières heures"   value={ot10}  onChange={setOt10} />
            <OtRow label="+25%"  sub="Heures suivantes"     value={ot25}  onChange={setOt25} />
            <OtRow label="+50%"  sub="Nuit / repos / férié" value={ot50}  onChange={setOt50} />
            <OtRow label="+100%" sub="Nuit dim. / férié"    value={ot100} onChange={setOt100} />
          </div>

          {/* Primes */}
          <div className="bg-[var(--surface)]  border border-[var(--border)]  rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-1">
              <Gift size={14} className="text-[var(--warning-text)]" /><h3 className="font-semibold text-sm text-[var(--text)] dark:text-[var(--on-brand)]">Primes</h3>
              <button onClick={addBonus} className="ml-auto flex items-center gap-1 px-2.5 py-1 bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))]  border border-[var(--border)]  rounded-lg text-xs font-semibold text-[var(--warning-text)]  hover:bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] cursor-pointer"><Plus size={10} /> Ajouter</button>
            </div>
            {manualBonuses.length === 0 ? (
              <p className="text-xs text-[var(--text-secondary)] text-center py-3">{mode === 'existing' ? 'Vide → backend utilisera les primes configurées' : 'Ajoutez les primes de votre bulletin'}</p>
            ) : (
              <div className="space-y-2.5 mt-2">
                {manualBonuses.map(b => (
                  <div key={b.localId} className="flex flex-col gap-1.5">
                    <div className="flex gap-2 items-center">
                      <input placeholder="Libellé" value={b.bonusType} onChange={e => updateBonus(b.localId, { bonusType: e.target.value })}
                        className="flex-1 px-3 py-2 border border-[var(--border)]  rounded-lg text-sm bg-[var(--surface)]  outline-none" />
                      <input type="number" placeholder="Montant" value={b.amount || ''} onChange={e => updateBonus(b.localId, { amount: Number(e.target.value) })}
                        className="w-28 px-3 py-2 border border-[var(--border)]  rounded-lg text-sm font-mono bg-[var(--surface)]  outline-none" />
                      <button onClick={() => setManualBonuses(prev => prev.filter(x => x.localId !== b.localId))} className="w-8 h-8 flex items-center justify-center rounded-lg border border-[var(--border)]  bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  hover:bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] cursor-pointer"><Trash2 size={12} className="text-[var(--danger-text)]" /></button>
                    </div>
                    <div className="flex items-center gap-2 px-1">
                      <span className="text-[10px] text-[var(--text-secondary)]">Fiscal :</span>
                      <BonusFiscalBadge label="ITS"  active={b.isTaxable} onChange={() => updateBonus(b.localId, { isTaxable: !b.isTaxable })} color="cyan" />
                      <BonusFiscalBadge label="CNSS" active={b.isCnss}    onChange={() => updateBonus(b.localId, { isCnss: !b.isCnss })} color="emerald" />
                      {!b.isTaxable && !b.isCnss && <span className="text-[10px] text-[var(--warning-text)] font-semibold">→ versée au net</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ✅ AVANCES / PRÊTS */}
          <div className="bg-[var(--surface)]  border border-[var(--border)]  rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-1">
              <CreditCard size={14} className="text-[var(--danger-text)]" />
              <h3 className="font-semibold text-sm text-[var(--text)] dark:text-[var(--on-brand)]">Avances & Prêts</h3>
              <span className="text-[10px] text-[var(--text-secondary)] ml-1">(déduites du net)</span>
              <button onClick={addAdvance} className="ml-auto flex items-center gap-1 px-2.5 py-1 bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  border border-[var(--border)]  rounded-lg text-xs font-semibold text-[var(--danger-text)]  hover:bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] cursor-pointer"><Plus size={10} /> Ajouter</button>
            </div>
            {manualAdvances.length === 0 ? (
              <p className="text-xs text-[var(--text-secondary)] text-center py-3">Aucune avance · le backend utilise les avances enregistrées</p>
            ) : (
              <div className="space-y-2 mt-2">
                {manualAdvances.map(a => (
                  <div key={a.localId} className="flex gap-2 items-center">
                    <input placeholder="Libellé" value={a.label} onChange={e => updateAdvance(a.localId, { label: e.target.value })}
                      className="flex-1 px-3 py-2 border border-[var(--border)]  rounded-lg text-sm bg-[var(--surface)]  outline-none" />
                    <input type="number" placeholder="Montant" value={a.amount || ''} onChange={e => updateAdvance(a.localId, { amount: Number(e.target.value) })}
                      className="w-28 px-3 py-2 border border-[var(--border)]  rounded-lg text-sm font-mono bg-[var(--surface)]  outline-none" />
                    <button onClick={() => setManualAdvances(prev => prev.filter(x => x.localId !== a.localId))} className="w-8 h-8 flex items-center justify-center rounded-lg border border-[var(--border)]  bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  hover:bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] cursor-pointer"><Trash2 size={12} className="text-[var(--danger-text)]" /></button>
                  </div>
                ))}
                <p className="text-[10px] text-[var(--danger-text)] mt-1">ℹ Si le backend gère déjà ces avances, elles seront dédupliquées automatiquement</p>
              </div>
            )}
          </div>

          {/* Erreur */}
          {error && (
            <div className="flex items-center gap-2 p-3 bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  border border-[var(--border)]  rounded-xl">
              <AlertCircle size={14} className="text-[var(--danger-text)] shrink-0" />
              <span className="text-sm text-[var(--danger-text)] ">{error}</span>
            </div>
          )}

          {/* Bouton simuler */}
          <button onClick={handleSimulate} disabled={isSimulating || !canSimulate}
            className={`w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-colors duration-200
              ${(!canSimulate || isSimulating) ? 'bg-[var(--surface-2)]  text-[var(--text-secondary)] cursor-not-allowed'
                : mode === 'free' ? 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] hover:bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] text-[var(--warning-text)] shadow-lg  cursor-pointer'
                : 'bg-[var(--brand)] hover:bg-[var(--brand)] text-[var(--on-brand)] shadow-lg  cursor-pointer'}`}>
            {isSimulating ? <><Loader2 size={16} className="animate-spin" /> Calcul en cours...</> : <><Play size={16} /> Simuler</>}
          </button>
        </div>

        {/* ══ RÉSULTATS ════════════════════════════════════════════════════ */}
        <div>
          {!result ? (
            <div className="bg-[var(--surface-2)]  border border-dashed border-[var(--border)]  rounded-2xl p-16 text-center">
              <FlaskConical size={36} className="mx-auto text-[var(--text-secondary)]  mb-3" />
              <p className="text-sm text-[var(--text-secondary)]">{mode === 'free' ? 'Renseignez le salaire et cliquez Simuler' : 'Sélectionnez un employé et cliquez Simuler'}</p>
            </div>
          ) : (
            <div className="space-y-4">

              {/* NET À PAYER */}
              <div className="bg-[var(--surface-2)] dark:bg-[var(--text)] rounded-2xl p-5 text-[var(--on-brand)]">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-[10px] text-[var(--text-secondary)] uppercase tracking-widest mb-1">Net à payer</p>
                    <p className="text-3xl font-semibold font-mono tracking-tight">{fmt(result.netSalary)}<span className="text-base font-normal text-[var(--text-secondary)] ml-2">FCFA</span></p>
                  </div>
                  <button onClick={handleCopy} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${copied ? 'border-[var(--border)] text-[var(--action)] bg-[var(--brand-soft)]' : 'border-[var(--border)] text-[var(--text-secondary)] hover:border-[var(--border)]'}`}>
                    {copied ? <><Check size={12} /> Copié !</> : <><Copy size={12} /> Copier</>}
                  </button>
                </div>
                <p className="text-xs text-[var(--text-secondary)]">
                  {[result.employee.firstName, result.employee.lastName].filter(Boolean).join(' ') || 'Anonyme'}{' · '}{MONTHS[result.month-1]} {result.year}{' · '}{result.daysToPay}/{result.workDays} jours
                </p>
              </div>

              {/* DÉTAIL DU BULLETIN — même composant que les aperçus de paie */}
              <div className="loan-document-protected">
                <PayslipBreakdown result={result} defaultOpenEmployer />
              </div>

              {/* DÉTAIL ITS */}
              {result.irppDetails && !result.isBncWorker && result.irppDetails.fiscalParts && (
                <div className="bg-[var(--surface)]  border border-[var(--border)]  rounded-2xl overflow-hidden">
                  <button onClick={() => setShowItsDetail(d => !d)}
                    className="w-full flex items-center justify-between px-4 py-3 text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider cursor-pointer">
                    <span>Détail du calcul {isForfait ? 'forfait' : isLegacyMode ? 'IRPP' : 'ITS'}</span>
                    {showItsDetail ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </button>
                  {showItsDetail && (
                    <div className="px-4 pb-4 text-xs text-[var(--text-secondary)] space-y-1.5">
                      {!isForfait && <p>Base imposable (brut − CNSS) : <span className="font-mono font-semibold">{fmt(result.irppDetails.baseImposable)} F</span></p>}
                      {!isForfait && <p>{abattementLabel} : <span className="font-mono font-semibold">−{fmt(result.irppDetails.abattement)} F</span></p>}
                      {!isForfait && <p>Revenu net imposable : <span className="font-mono font-semibold">{fmt(result.irppDetails.revenuNetImposable)} F</span></p>}
                      <p>Parts fiscales : <span className="font-semibold">{result.irppDetails.fiscalParts}</span></p>
                      {!isForfait && result.irppDetails.revenuParPart != null && <p>Revenu annuel par part : <span className="font-mono font-semibold">{fmt(result.irppDetails.revenuParPart)} F</span></p>}
                      {Array.isArray(result.irppDetails.details) && result.irppDetails.details.map((d: any, i: number) => (
                        <p key={i} className="pl-2">{d.tranche} · {d.taux}% sur {fmt(d.base)} F = <span className="font-mono font-semibold">{fmt(d.montant)} F</span></p>
                      ))}
                      <p>Taux effectif : <span className="font-semibold">{result.irppDetails.effectiveRate}%</span></p>
                      <p className={`font-semibold ${isForfait || isLegacyMode ? 'text-[var(--warning-text)]' : 'text-[var(--success-text)]'}`}>
                        Mode : {isForfait ? `Forfait ${Math.round((result.irppDetails.forfaitRate ?? forfaitRate) * 100)}%` : isLegacyMode ? 'IRPP legacy (avant 2026)' : 'ITS 2026'}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Badge mode */}
              <div className={`text-center py-2 px-4 rounded-xl text-xs font-medium border
                ${result.simulationMode === 'FREE_SIMULATION' ? 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))]  text-[var(--warning-text)] border-[var(--border)] '
                  : result.simulationMode === 'MANUAL_OVERRIDE' ? 'bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  text-[var(--success-text)] border-[var(--border)]'
                  : 'bg-[var(--surface-2)]  text-[var(--text-secondary)] border-[var(--border)]'}`}>
                {result.simulationMode === 'FREE_SIMULATION' ? '🆓 Simulation libre · calcul 100% backend'
                  : result.simulationMode === 'MANUAL_OVERRIDE' ? '⚡ Valeurs manuelles · calcul 100% backend'
                  : '📊 Depuis pointage BDD · calcul 100% backend'}
              </div>

            </div>
          )}
        </div>
      </div>
      </div>
    </ModulePageFrame>
  );
}
