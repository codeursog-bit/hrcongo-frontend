'use client';
import { ProfileAvatar } from '@/components/ui/ProfileAvatar';
import { UserCollection } from '@/components/settings/UserCollection';
import { ModuleSelect } from '@/components/ui/ModuleSelect';

import React, { useState, useMemo, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft, UserPlus, Search, Filter, MoreVertical,
  Shield, Key, Eye, Ban, Trash2, CheckCircle2,
  Mail, Smartphone, Laptop, AlertTriangle, Lock,
  FileText, Check, X, RefreshCw, LogOut, Globe,
  ShieldAlert, Settings, ChevronDown, ChevronUp,
  Activity, Clock, Loader2, Save, Edit, Network, User
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '@/services/api';
import { useAlert } from '@/components/providers/AlertProvider';

import { FancySelect } from '@/components/ui/FancySelect';
import { approvalsApi, ApprovalFunctionDef, UserFunctionItem } from '@/services/approvals';
import ExternalFunctionsSection from '@/components/approvals/ExternalFunctionsSection';
import { KonzaLoader } from '@/components/ui/KonzaLoader';
import { SettingsFrame as ModulePageFrame } from '@/components/settings/SettingsFrame';

// --- Types ---

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  isActive: boolean;
  avatar?: string;
  lastLoginAt: string;
  canRecordAttendanceForAll?: boolean; // 🆕 permission "secrétaire" : pointage manuel pour tout le monde
}

interface Department {
  id: string;
  name: string;
}

const ROLE_CONFIG: Record<string, { label: string, color: string, bg: string }> = {
  SUPER_ADMIN: { label: 'Super Admin', color: 'text-[var(--action)]', bg: 'bg-[var(--brand-soft)]' },
  ADMIN: { label: 'Admin', color: 'text-[var(--action)]', bg: 'bg-[var(--brand-soft)]' },
  HR_MANAGER: { label: 'Manager RH', color: 'text-[var(--text-secondary)]', bg: 'bg-[var(--surface-2)]' },
  MANAGER: { label: 'Manager', color: 'text-[var(--action)]', bg: 'bg-[var(--brand-soft)]' },
  EMPLOYEE: { label: 'Employé', color: 'text-[var(--text-muted)]', bg: 'bg-[var(--surface-2)]' },
};

function UserManagementPage() {
  const router = useRouter();
  const alert = useAlert()
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentUserRole, setCurrentUserRole] = useState<string | null>(null);
  useEffect(() => {
    try {
      const stored = localStorage.getItem('user');
      if (stored) {
        const parsed = JSON.parse(stored);
        setCurrentUserId(parsed?.id || null);
        setCurrentUserRole(parsed?.role || null);
      }
    } catch {}
  }, []);

  // ✅ LOT A — fonctions de validation (avis) : seul l'admin les attribue.
  //    Si l'endpoint n'est pas disponible (backend pas déployé, droits…), la
  //    section reste simplement masquée : la page fonctionne comme avant.
  const [functionsCatalog, setFunctionsCatalog] = useState<ApprovalFunctionDef[]>([]);
  const [functionAssignments, setFunctionAssignments] = useState<Record<string, UserFunctionItem[]>>({});
  const [functionsAvailable, setFunctionsAvailable] = useState(false);
  const [editFunctions, setEditFunctions] = useState<Record<string, { enabled: boolean; canSign: boolean }>>({});
  const canManageFunctions = currentUserRole === 'ADMIN' || currentUserRole === 'SUPER_ADMIN';

  // -- State --
  const [users, setUsers] = useState<User[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');

  // Invite Modal State
  const [inviteModal, setInviteModal] = useState(false);
  const [isInviting, setIsInviting] = useState(false);
  const [inviteForm, setInviteForm] = useState({
    email: '',
    firstName: '',
    lastName: '',
    role: 'EMPLOYEE',
    password: '', // Mot de passe provisoire
    departmentId: '' // Optionnel, pour les managers
  });

  // Edit Modal State
  const [editModal, setEditModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editForm, setEditForm] = useState({
    role: '',
    isActive: true,
    canRecordAttendanceForAll: false // 🆕 permission "secrétaire" pointage manuel pour tout le monde
  });

  // -- Fetch --
  const fetchUsers = async () => {
    try {
        const [usersData, deptsData] = await Promise.all([
            api.get<User[]>('/users'),
            api.get<Department[]>('/departments')
        ]);
        setUsers(usersData);
        setDepartments(deptsData);
        try {
          const fnData = await approvalsApi.listCompanyFunctions();
          setFunctionsCatalog(fnData.catalog || []);
          setFunctionAssignments(fnData.assignments || {});
          setFunctionsAvailable(true);
        } catch {
          setFunctionsAvailable(false);
        }
    } catch (e) {
        console.error("Failed to fetch data", e);
    } finally {
        setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // -- Invite Actions --
  // 🆕 Après une invitation réussie, on garde la modale ouverte pour proposer le partage
  const [inviteSuccessInfo, setInviteSuccessInfo] = useState<{ firstName: string; lastName: string; email: string; password: string; phone?: string | null } | null>(null);
  const [copiedInviteMsg, setCopiedInviteMsg] = useState(false);

  const buildInviteMessage = (info: { firstName: string; lastName: string; email: string; password: string; phone?: string | null }) => {
    const loginUrl = typeof window !== 'undefined' ? `${window.location.origin}/auth/login` : '';
    return `Bonjour ${info.firstName} ${info.lastName},\n` +
      `Voici tes identifiants pour accéder à konza-rh :\n` +
      `Lien de connexion : ${loginUrl}\n` +
      `Email : ${info.email}\n` +
      (info.phone ? `Téléphone : ${info.phone} (tu peux aussi te connecter avec ce numéro)\n` : '') +
      `Mot de passe temporaire : ${info.password}\n` +
      `⚠️ Important : Lors de ta première connexion, l'application te demandera de modifier ton mot de passe. Ton nouveau mot de passe devra contenir au moins 8 caractères, incluant une majuscule, une minuscule et un chiffre.\n` +
      `N'hésite pas si tu as des questions.\n` +
      `Bonne prise en main !`;
  };

  const handleShareWhatsApp = (info: { firstName: string; lastName: string; email: string; password: string; phone?: string | null }) => {
    const text = encodeURIComponent(buildInviteMessage(info));
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };
  const handleShareSms = (info: { firstName: string; lastName: string; email: string; password: string; phone?: string | null }) => {
    const text = encodeURIComponent(buildInviteMessage(info));
    window.open(`sms:?body=${text}`, '_blank');
  };
  const handleCopyInviteMessage = async (info: { firstName: string; lastName: string; email: string; password: string; phone?: string | null }) => {
    try {
      await navigator.clipboard.writeText(buildInviteMessage(info));
      setCopiedInviteMsg(true);
      setTimeout(() => setCopiedInviteMsg(false), 2500);
    } catch {
      alert.error('Erreur', "Impossible de copier le message.");
    }
  };
  const closeInviteModal = () => {
    setInviteModal(false);
    setInviteSuccessInfo(null);
    setCopiedInviteMsg(false);
  };

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsInviting(true);
    try {
        // Nettoyage : si pas Manager, pas de departmentId
        const payload = { ...inviteForm };
        if (payload.role !== 'MANAGER') delete (payload as any).departmentId;

        // ✅ On récupère la réponse (newUser) pour savoir si un téléphone a été lié automatiquement
        const created = await api.post<{ phone?: string | null }>('/users/invite', payload);
        // 🆕 On garde la modale ouverte pour proposer le partage des identifiants
        setInviteSuccessInfo({ firstName: inviteForm.firstName, lastName: inviteForm.lastName, email: inviteForm.email, password: inviteForm.password, phone: created?.phone ?? null });
        setInviteForm({ email: '', firstName: '', lastName: '', role: 'EMPLOYEE', password: '', departmentId: '' });
        alert.success('Utilisateur invité ', 'Utilisateur invité avec succès !');
        fetchUsers(); // Refresh list
   } catch (err: any) {
  alert.error(
    'Erreur d\'invitation',
    err.message || "Impossible d'envoyer l'invitation."
  );
}finally {
        setIsInviting(false);
    }
  };

  // -- Edit Actions --
  const openEditModal = (user: User) => {
    setEditingUser(user);
    setEditForm({
        role: user.role,
        isActive: user.isActive,
        canRecordAttendanceForAll: user.canRecordAttendanceForAll || false
    });
    const initialFns: Record<string, { enabled: boolean; canSign: boolean }> = {};
    (functionAssignments[user.id] || []).forEach(f => { initialFns[f.code] = { enabled: true, canSign: f.canSign }; });
    setEditFunctions(initialFns);
    setEditModal(true);
  };

  const handleUpdate = async () => {
    if (!editingUser) return;
    setIsSaving(true);
    try {
        // ✅ On n'envoie au backend QUE les champs réellement modifiés.
        // Avant : role / isActive / canRecordAttendanceForAll partaient toujours ensemble ;
        // sur son propre compte le backend refuse ces champs (403) et l'attribution
        // des fonctions (DG, comptable…) juste après n'était jamais exécutée.
        const changedFields: Record<string, unknown> = {};
        if (editForm.role !== editingUser.role) changedFields.role = editForm.role;
        if (editForm.isActive !== editingUser.isActive) changedFields.isActive = editForm.isActive;
        if (editForm.canRecordAttendanceForAll !== (editingUser.canRecordAttendanceForAll || false)) {
          changedFields.canRecordAttendanceForAll = editForm.canRecordAttendanceForAll;
        }
        if (Object.keys(changedFields).length > 0) {
          await api.patch(`/users/${editingUser.id}`, changedFields);
        }

        // ✅ LOT A — enregistrement des fonctions (uniquement si modifiées)
        if (canManageFunctions && functionsAvailable) {
          const nextFns: UserFunctionItem[] = Object.entries(editFunctions)
            .filter(([, v]) => v.enabled)
            .map(([code, v]) => ({ code, canSign: v.canSign }));
          const prevFns = functionAssignments[editingUser.id] || [];
          const norm = (arr: UserFunctionItem[]) => JSON.stringify([...arr].sort((a, b) => a.code.localeCompare(b.code)));
          if (norm(nextFns) !== norm(prevFns)) {
            await approvalsApi.setUserFunctions(editingUser.id, nextFns);
          }
        }

        setEditModal(false);
        setEditingUser(null);
        alert.success('utilisateur', 'Utilisateur mis à jour !');
        fetchUsers();
    } catch (err: any) {
  alert.error(
    'Erreur de mise à jour',
    err.message || 'Impossible de mettre à jour l\'utilisateur.'
  );
}finally {
        setIsSaving(false);
    }
  };

  // 🆕 Suppression d'un utilisateur
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const handleDelete = async (user: User) => {
    if (!window.confirm(`Supprimer définitivement ${user.firstName} ${user.lastName} ?\n\nCette action est irréversible. Si vous voulez juste bloquer son accès temporairement, préférez "Désactiver" via Modifier.`)) {
      return;
    }
    setDeletingId(user.id);
    try {
      await api.delete(`/users/${user.id}`);
      alert.success('Utilisateur supprimé', `${user.firstName} ${user.lastName} a été supprimé.`);
      fetchUsers();
    } catch (err: any) {
      alert.error('Erreur de suppression', err.message || "Impossible de supprimer cet utilisateur.");
    } finally {
      setDeletingId(null);
    }
  };

  // -- Derived Data --
  const filteredUsers = useMemo(() => {
    return users.filter(u => {
      const matchesSearch = u.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            u.lastName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            u.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRole = roleFilter === 'All' || u.role === roleFilter;
      return matchesSearch && matchesRole;
    });
  }, [users, searchQuery, roleFilter]);

  if (isLoading) return <KonzaLoader variant="page" />;

  return (
    <div className="max-w-[1600px] mx-auto pb-20 space-y-8">

      {/* HEADER */}
      <div className="settings-page-header flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
           <button onClick={() => router.back()} className="p-2 bg-[var(--surface)] rounded-xl border border-[var(--border)] hover:bg-[var(--surface-2)] transition-colors">
             <ArrowLeft size={20} className="text-[var(--text-muted)]" />
           </button>
           <div>
              <h1 className="text-3xl font-semibold text-[var(--text)] tracking-tight">Gestion des Utilisateurs</h1>
              <p className="text-[var(--text-muted)]">Contrôle d'accès, rôles et sécurité.</p>
           </div>
        </div>

        <button
           onClick={() => setInviteModal(true)}
           className="px-5 py-3 rounded-xl bg-[var(--brand)] hover:bg-[var(--brand)] text-[var(--on-brand)] font-semibold shadow-lg   transition-colors flex items-center gap-2"
        >
           <UserPlus size={20} /> Inviter Utilisateur
        </button>
      </div>

      {/* STATS CARDS */}
      <div className="settings-metrics grid grid-cols-2 md:grid-cols-4 gap-4">
         <div className="bg-[var(--surface)] p-4 rounded-2xl border border-[var(--border)] shadow-sm">
            <p className="text-xs text-[var(--text-muted)] uppercase font-semibold">Total Utilisateurs</p>
            <p className="text-2xl font-semibold text-[var(--text)] mt-1">{users.length}</p>
         </div>
         <div className="bg-[var(--surface)] p-4 rounded-2xl border border-[var(--border)] shadow-sm">
            <p className="text-xs text-[var(--text-muted)] uppercase font-semibold">Administrateurs</p>
            <p className="text-2xl font-semibold text-[var(--success-text)]  mt-1">{users.filter(u => u.role === 'ADMIN').length}</p>
         </div>
         <div className="bg-[var(--surface)] p-4 rounded-2xl border border-[var(--border)] shadow-sm">
            <p className="text-xs text-[var(--text-muted)] uppercase font-semibold">Actifs</p>
            <p className="text-2xl font-semibold text-[var(--success-text)]  mt-1 flex items-center gap-2">
               <span className="w-2 h-2 rounded-full bg-[var(--brand)] "></span>
               {users.filter(u => u.isActive).length}
            </p>
         </div>
      </div>

      {/* FILTERS & LIST */}
      <div className="bg-[var(--surface)] rounded-2xl shadow-sm border border-[var(--border)] overflow-hidden">

         {/* Toolbar */}
         <div className="p-4 border-b border-[var(--border)] flex flex-col md:flex-row justify-between items-center gap-4 bg-[var(--surface-2)]">
            <div className="flex items-center gap-3 w-full md:w-auto">
               <div className="relative flex-1 md:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" size={16} />
                  <input
                     type="text"
                     placeholder="Rechercher..."
                     value={searchQuery}
                     onChange={(e) => setSearchQuery(e.target.value)}
                     className="w-full pl-9 pr-4 py-2 bg-[var(--surface)] border border-[var(--border)] rounded-xl text-sm focus:ring-2 focus:ring-[var(--focus)] outline-none"
                  />
               </div>
               <ModuleSelect
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="p-2 bg-[var(--surface)] border border-[var(--border)] rounded-xl text-sm font-medium"
               >
                  <option value="All">Tous les rôles</option>
                  {Object.keys(ROLE_CONFIG).filter(r => r !== 'SUPER_ADMIN').map(r => <option key={r} value={r}>{ROLE_CONFIG[r].label}</option>)}
               </ModuleSelect>
            </div>
         </div>

         {/* User Grid */}
         <UserCollection filterKey={`${searchQuery}|${roleFilter}`}>
            {filteredUsers.map(user => {
               const config = ROLE_CONFIG[user.role] || ROLE_CONFIG.EMPLOYEE;
               return (
               <div key={user.id} className="settings-user-row group bg-[var(--surface)] rounded-2xl p-5 border border-[var(--border)] hover:shadow-xl hover:border-[var(--border)]  transition-colors relative overflow-hidden">
                  <div className="flex justify-between items-start mb-4 relative z-10">
                     <div className="flex items-center gap-4">
                        <div className="relative">
                           <ProfileAvatar name={`${user.firstName || ''} ${user.lastName || ''}`} src={user.avatar || undefined} className={`w-14 h-14 rounded-full object-cover border-2 ${!user.isActive ? 'border-[var(--border)] grayscale' : 'border-[var(--surface)]'}`} />
                           <span className={`absolute bottom-0 right-0 w-4 h-4 border-2 border-[var(--surface)] rounded-full ${user.isActive ? 'bg-[var(--brand)]' : 'bg-[var(--text-muted)]'}`}></span>
                        </div>
                        <div>
                           <h3 className={`font-semibold text-lg ${!user.isActive ? 'text-[var(--text-muted)] line-through' : 'text-[var(--text)]'}`}>{user.firstName} {user.lastName}</h3>
                           <p className="text-sm text-[var(--text-muted)] truncate max-w-[150px]">{user.email}</p>
                        </div>
                     </div>

                     <div className="flex items-center gap-1">
                       <button
                          onClick={() => openEditModal(user)}
                          className="p-2 hover:bg-[var(--surface-2)] rounded-lg text-[var(--text-muted)] hover:text-[var(--success-text)] transition-colors"
                          title="Modifier le rôle/statut"
                       >
                          <Edit size={18} />
                       </button>
                       {user.id !== currentUserId && (
                         <button
                            onClick={() => handleDelete(user)}
                            disabled={deletingId === user.id}
                            className="p-2 hover:bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  rounded-lg text-[var(--text-muted)] hover:text-[var(--danger-text)] transition-colors disabled:opacity-50"
                            title="Supprimer définitivement"
                         >
                            {deletingId === user.id ? <Loader2 size={18} className="animate-spin" /> : <Trash2 size={18} />}
                         </button>
                       )}
                     </div>
                  </div>

                  <div className="space-y-4">
                     <div className="flex items-center justify-between flex-wrap gap-2">
                        <span className={`inline-block px-3 py-1 rounded-lg text-xs font-semibold ${config.bg} ${config.color}`}>
                            {config.label}
                        </span>
                        {user.canRecordAttendanceForAll && (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold text-[var(--success-text)] bg-[var(--brand-soft)] " title="Peut pointer pour tout le monde">
                                <Shield size={12} /> Secrétaire
                            </span>
                        )}
                        {(functionAssignments[user.id] || []).map(f => {
                            const def = functionsCatalog.find(c => c.code === f.code);
                            return (
                              <span key={f.code} className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold text-[var(--success-text)] bg-[var(--brand-soft)] " title={f.canSign ? 'Peut donner un avis et signer' : 'Peut donner un avis'}>
                                <Shield size={12} /> {def?.label || f.code}{f.canSign ? ' · signe' : ''}
                              </span>
                            );
                        })}
                        {!user.isActive && <span className="text-xs font-semibold text-[var(--danger-text)] flex items-center gap-1"><Ban size={12}/> Désactivé</span>}
                     </div>

                     <div className="flex items-center gap-2 text-xs text-[var(--text-muted)] bg-[var(--surface-2)] p-2 rounded-lg border border-[var(--border)]">
                        <Clock size={14} /> Dernier accès: {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleDateString() : 'Jamais'}
                     </div>
                  </div>
               </div>
            )})}
         </UserCollection>
      </div>

      {/* EDIT USER MODAL */}
      <AnimatePresence>
        {editModal && editingUser && (
            <motion.div
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center bg-[rgb(0_0_0_/.5)]  p-4"
            >
                <motion.div
                    initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
                    className="bg-[var(--surface)] rounded-2xl p-8 max-w-md w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[var(--border)]"
                >
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-semibold text-[var(--text)]">Modifier Utilisateur</h2>
                        <button onClick={() => setEditModal(false)} className="p-2 hover:bg-[var(--surface-2)] rounded-full"><X size={20} /></button>
                    </div>

                    <div className="flex items-center gap-4 mb-6 p-4 bg-[var(--surface-2)] rounded-2xl border border-[var(--border)]">
                        <div className="w-12 h-12 rounded-full bg-[var(--surface-2)] flex items-center justify-center font-semibold text-[var(--text-muted)]">
                            {editingUser.firstName[0]}{editingUser.lastName[0]}
                        </div>
                        <div>
                            <h3 className="font-semibold text-[var(--text)]">{editingUser.firstName} {editingUser.lastName}</h3>
                            <p className="text-xs text-[var(--text-muted)]">{editingUser.email}</p>
                        </div>
                    </div>

                    <div className="space-y-6">
                        <div>
                            <label className="block text-sm font-semibold mb-2 text-[var(--text)]">Rôle système</label>
                            <div className="grid grid-cols-1 gap-2">
                                {Object.entries(ROLE_CONFIG).filter(([key]) => key !== 'SUPER_ADMIN').map(([key, config]) => (
                                    <label
                                        key={key}
                                        className={`
                                            flex items-center p-3 rounded-xl border cursor-pointer transition-colors
                                            ${editForm.role === key
                                                ? 'border-[var(--border)] bg-[var(--brand-soft)]  ring-1 ring-[var(--focus)]'
                                                : 'border-[var(--border)] hover:bg-[var(--surface-2)]'}
                                        `}
                                    >
                                        <input
                                            type="radio"
                                            name="role"
                                            value={key}
                                            checked={editForm.role === key}
                                            onChange={(e) => setEditForm({...editForm, role: e.target.value})}
                                            className="hidden"
                                        />
                                        <div className={`w-4 h-4 rounded-full border mr-3 flex items-center justify-center ${editForm.role === key ? 'border-[var(--border)]' : 'border-[var(--text-muted)]'}`}>
                                            {editForm.role === key && <div className="w-2 h-2 rounded-full bg-[var(--brand)]"></div>}
                                        </div>
                                        <span className={`text-sm font-semibold ${editForm.role === key ? 'text-[var(--success-text)] ' : 'text-[var(--text-muted)]'}`}>
                                            {config.label}
                                        </span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-semibold mb-2 text-[var(--text)]">Permission supplémentaire</label>
                            <button
                                type="button"
                                onClick={() => setEditForm({...editForm, canRecordAttendanceForAll: !editForm.canRecordAttendanceForAll})}
                                className={`w-full flex items-center justify-between p-3 rounded-xl border transition-colors text-left ${editForm.canRecordAttendanceForAll ? 'border-[var(--border)] bg-[var(--brand-soft)]  ring-1 ring-[var(--focus)]' : 'border-[var(--border)] hover:bg-[var(--surface-2)]'}`}
                            >
                                <div className="pr-4">
                                    <p className={`text-sm font-semibold ${editForm.canRecordAttendanceForAll ? 'text-[var(--success-text)] ' : 'text-[var(--text)]'}`}>
                                        Pointage pour tout le monde (Secrétaire)
                                    </p>
                                    <p className="text-xs text-[var(--text-muted)] mt-0.5">
                                        Peut faire le pointage manuel de n'importe quel employé de l'entreprise, quel que soit son rôle (indépendant du département pour un Manager).
                                    </p>
                                </div>
                                <div className={`shrink-0 w-11 h-6 rounded-full flex items-center px-0.5 transition-colors ${editForm.canRecordAttendanceForAll ? 'bg-[var(--brand)] justify-end' : 'bg-[var(--border)] justify-start'}`}>
                                    <div className="w-5 h-5 rounded-full bg-[var(--surface)] shadow" />
                                </div>
                            </button>
                        </div>

                        {canManageFunctions && functionsAvailable && functionsCatalog.length > 0 && editingUser.role !== 'SUPER_ADMIN' && (
                        <div>
                            <label className="block text-sm font-semibold mb-1 text-[var(--text)]">Fonctions de validation (avis)</label>
                            <p className="text-xs text-[var(--text-muted)] mb-3">
                                Donne le droit de donner un avis sur les demandes, sans pouvoir approuver ou refuser (réservé à l'Admin et au Manager RH). La case « Peut signer » autorise l'enregistrement d'une signature personnelle.
                            </p>
                            <div className="space-y-2">
                                {functionsCatalog.map(fn => {
                                    const st = editFunctions[fn.code] || { enabled: false, canSign: false };
                                    return (
                                        <div key={fn.code} className={`rounded-xl border transition-colors ${st.enabled ? 'border-[var(--border)] bg-[var(--brand-soft)]  ring-1 ring-[var(--focus)]' : 'border-[var(--border)]'}`}>
                                            <button
                                                type="button"
                                                onClick={() => setEditFunctions(prev => ({ ...prev, [fn.code]: { enabled: !st.enabled, canSign: st.enabled ? false : st.canSign } }))}
                                                className="w-full flex items-center justify-between p-3 text-left"
                                            >
                                                <div className="pr-4">
                                                    <p className={`text-sm font-semibold ${st.enabled ? 'text-[var(--success-text)] ' : 'text-[var(--text)]'}`}>{fn.label}</p>
                                                    <p className="text-xs text-[var(--text-muted)] mt-0.5">{fn.description}</p>
                                                </div>
                                                <div className={`shrink-0 w-11 h-6 rounded-full flex items-center px-0.5 transition-colors ${st.enabled ? 'bg-[var(--brand)] justify-end' : 'bg-[var(--border)] justify-start'}`}>
                                                    <div className="w-5 h-5 rounded-full bg-[var(--surface)] shadow" />
                                                </div>
                                            </button>
                                            {st.enabled && (
                                                <label className="flex items-center gap-2 px-3 pb-3 cursor-pointer select-none">
                                                    <input
                                                        type="checkbox"
                                                        checked={st.canSign}
                                                        onChange={(e) => setEditFunctions(prev => ({ ...prev, [fn.code]: { enabled: true, canSign: e.target.checked } }))}
                                                        className="w-4 h-4 accent-emerald-500"
                                                    />
                                                    <span className="text-xs font-medium text-[var(--text)]">Peut signer (autorise l'upload de sa signature)</span>
                                                </label>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                        )}

                        {canManageFunctions && editingUser.role !== 'SUPER_ADMIN' && (
                            <ExternalFunctionsSection userId={editingUser.id} />
                        )}

                        <div>
                            <label className="block text-sm font-semibold mb-2 text-[var(--text)]">Statut du compte</label>
                            <div className="flex items-center gap-4">
                                <button
                                    type="button"
                                    onClick={() => setEditForm({...editForm, isActive: true})}
                                    className={`flex-1 py-3 rounded-xl font-semibold text-sm border transition-colors ${editForm.isActive ? 'bg-[var(--brand)] text-[var(--on-brand)] border-[var(--border)]' : 'bg-[var(--surface)] text-[var(--text-muted)] border-[var(--border)]'}`}
                                >
                                    Actif
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setEditForm({...editForm, isActive: false})}
                                    className={`flex-1 py-3 rounded-xl font-semibold text-sm border transition-colors ${!editForm.isActive ? 'bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] text-[var(--text)] border-[var(--border)]' : 'bg-[var(--surface)] text-[var(--text-muted)] border-[var(--border)]'}`}
                                >
                                    Désactivé
                                </button>
                            </div>
                        </div>

                        <div className="pt-4 flex gap-3">
                            <button onClick={() => setEditModal(false)} className="flex-1 py-3 border border-[var(--border)] rounded-xl font-semibold hover:bg-[var(--surface-2)]">Annuler</button>
                            <button onClick={handleUpdate} disabled={isSaving} className="flex-1 py-3 bg-[var(--brand)] hover:bg-[var(--brand)] text-[var(--on-brand)] font-semibold rounded-xl shadow-lg flex justify-center items-center gap-2">
                                {isSaving ? <Loader2 className="animate-spin" size={20}/> : <><Save size={18}/> Enregistrer</>}
                            </button>
                        </div>
                    </div>
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>

      {/* INVITE MODAL */}
      <AnimatePresence>
        {inviteModal && (
            <motion.div
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center bg-[rgb(0_0_0_/.5)]  p-4"
            >
                <motion.div
                    initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}
                    className="bg-[var(--surface)] rounded-2xl p-8 max-w-lg w-full shadow-2xl border border-[var(--border)]"
                >
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-semibold text-[var(--text)]">{inviteSuccessInfo ? 'Partager les identifiants' : 'Inviter un collaborateur'}</h2>
                        <button onClick={closeInviteModal} className="p-2 hover:bg-[var(--surface-2)] rounded-full"><X size={20} /></button>
                    </div>

                    {inviteSuccessInfo ? (
                        <div className="space-y-5">
                            <div className="flex items-center gap-3 p-4 bg-[var(--brand-soft)]  border border-[var(--border)]  rounded-xl">
                                <CheckCircle2 size={20} className="text-[var(--success-text)] shrink-0" />
                                <p className="text-sm text-[var(--text)]">
                                    <strong>{inviteSuccessInfo.firstName} {inviteSuccessInfo.lastName}</strong> a été invité(e) avec succès. Partage-lui maintenant ses identifiants.
                                </p>
                            </div>

                            <div className="p-4 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl">
                                <p className="text-xs font-semibold uppercase tracking-wide text-[var(--text-muted)] mb-2">Aperçu du message</p>
                                <p className="text-xs text-[var(--text-muted)] whitespace-pre-line leading-relaxed">{buildInviteMessage(inviteSuccessInfo)}</p>
                            </div>

                            <div className="space-y-2.5">
                                {/* Partage prioritaire : WhatsApp choisit le contact lui-même */}
                                <button
                                    onClick={() => handleShareWhatsApp(inviteSuccessInfo)}
                                    className="w-full flex items-center justify-center gap-2 py-3.5 bg-[#25D366] hover:bg-[#20bd5a] text-[var(--text)] font-semibold rounded-xl shadow-lg transition-colors"
                                >
                                    <Smartphone size={18} /> Partager sur WhatsApp
                                </button>
                                <div className="grid grid-cols-2 gap-2.5">
                                    <button
                                        onClick={() => handleShareSms(inviteSuccessInfo)}
                                        className="flex items-center justify-center gap-2 py-3 border border-[var(--border)] rounded-xl font-semibold text-sm text-[var(--text)] hover:bg-[var(--surface-2)] transition-colors"
                                    >
                                        <Mail size={16} /> SMS
                                    </button>
                                    <button
                                        onClick={() => handleCopyInviteMessage(inviteSuccessInfo)}
                                        className="flex items-center justify-center gap-2 py-3 border border-[var(--border)] rounded-xl font-semibold text-sm text-[var(--text)] hover:bg-[var(--surface-2)] transition-colors"
                                    >
                                        {copiedInviteMsg ? <><Check size={16} className="text-[var(--success-text)]" /> Copié !</> : <>Copier le message</>}
                                    </button>
                                </div>
                            </div>

                            <button onClick={closeInviteModal} className="w-full py-3 text-sm text-[var(--text-muted)] hover:text-[var(--text)] transition-colors">
                                Fermer sans partager
                            </button>
                        </div>
                    ) : (
                    <form onSubmit={handleInvite} className="space-y-5">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-semibold mb-1">Prénom</label>
                                <input required value={inviteForm.firstName} onChange={e => setInviteForm({...inviteForm, firstName: e.target.value})} className="w-full p-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl outline-none focus:ring-2 focus:ring-[var(--focus)]" />
                            </div>
                            <div>
                                <label className="block text-sm font-semibold mb-1">Nom</label>
                                <input required value={inviteForm.lastName} onChange={e => setInviteForm({...inviteForm, lastName: e.target.value})} className="w-full p-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl outline-none focus:ring-2 focus:ring-[var(--focus)]" />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-semibold mb-1">Email professionnel</label>
                            <input type="email" required value={inviteForm.email} onChange={e => setInviteForm({...inviteForm, email: e.target.value})} className="w-full p-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl outline-none focus:ring-2 focus:ring-[var(--focus)]" />
                        </div>

                        <div>
                            <FancySelect
                                label="Rôle"
                                value={inviteForm.role}
                                onChange={(v) => setInviteForm({...inviteForm, role: v})}
                                icon={User}
                                options={[
                                    { value: 'EMPLOYEE', label: 'Employé (Standard)' },
                                    { value: 'MANAGER', label: 'Manager (Accès équipe)' },
                                    { value: 'HR_MANAGER', label: 'RH (Gestion paie/congés)' },
                                    { value: 'ADMIN', label: 'Administrateur' }
                                ]}
                            />
                        </div>

                        {/* CHAMPS DÉPARTEMENT POUR MANAGER UNIQUEMENT */}
                        {inviteForm.role === 'MANAGER' && (
                            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                                <FancySelect
                                    label="Assigner un Département"
                                    value={inviteForm.departmentId}
                                    onChange={(v) => setInviteForm({...inviteForm, departmentId: v})}
                                    icon={Network}
                                    options={departments.map(d => ({ value: d.id, label: d.name }))}
                                    placeholder="Choisir département..."
                                />
                                <p className="text-xs text-[var(--text-muted)] mt-1">Le manager n'aura accès qu'aux employés de ce département.</p>
                            </motion.div>
                        )}

                        <div>
                            <label className="block text-sm font-semibold mb-1">Mot de passe provisoire</label>
                            <input type="text" required minLength={6} value={inviteForm.password} onChange={e => setInviteForm({...inviteForm, password: e.target.value})} className="w-full p-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl outline-none focus:ring-2 focus:ring-[var(--focus)] font-mono" placeholder="Ex: Welcome2025!" />
                            <p className="text-xs text-[var(--text-muted)] mt-1">Communiquez ce mot de passe à l'utilisateur.</p>
                        </div>

                        <div className="pt-4 flex gap-3">
                            <button type="button" onClick={closeInviteModal} className="flex-1 py-3 border border-[var(--border)] rounded-xl font-semibold hover:bg-[var(--surface-2)]">Annuler</button>
                            <button type="submit" disabled={isInviting} className="flex-1 py-3 bg-[var(--brand)] hover:bg-[var(--brand)] text-[var(--on-brand)] font-semibold rounded-xl shadow-lg flex justify-center items-center gap-2">
                                {isInviting ? <Loader2 className="animate-spin" size={20}/> : <><Mail size={18}/> Envoyer l'invitation</>}
                            </button>
                        </div>
                    </form>
                    )}
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}


export default function UserManagementPageWithFrame() {
  return (
    <ModulePageFrame kind="list">
      <UserManagementPage />
    </ModulePageFrame>
  );
}
