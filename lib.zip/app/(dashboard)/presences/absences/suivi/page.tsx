'use client';
import { AttendanceSelect } from '@/components/attendance/AttendanceSelect';
import { AttendanceModuleFrame as ModulePageFrame } from '@/components/attendance/AttendanceModuleFrame';
import { useModuleVisuals } from '@/components/requests/ModulePageFrame';
import { ModulePageSkeleton } from '@/components/requests/ModulePageFrame';
import { Button } from '@/components/design-system/primitives';

// ============================================================================
// 📁 app/(dashboard)/absences-employe/page.tsx
// ✅ PAGE UNIQUE ET CONSOLIDÉE — remplace conges/analyse, rapports/absences,
//    rapports/observatoire-conges et presences/absences/suivi (à supprimer).
//    Tout est ici : congé annuel, congé anticipé, maladie, maternité,
//    paternité, mariage, décès, naissance, non justifiée — plus aucune
//    séparation par scope, tout est chargé avec scope="all" (comportement
//    par défaut du backend, donc aucun paramètre à envoyer).
//    Rendu repris du prototype validé (donuts, cartes KPI, onglets par mois,
//    grille à badges colorés) — 100% branché sur /absence-tracking/*.
// ============================================================================

import React, { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useBasePath } from '@/hooks/useBasePath';
import {
  Users, AlertTriangle, TrendingUp, CalendarClock, ListChecks,
  Percent, ChevronLeft, ChevronRight, Stethoscope, FileCheck2, FileX2, Trophy,
} from 'lucide-react';
import {
  ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend as RLegend,
} from 'recharts';
import { api } from '@/services/api';
import SlideOver from '@/components/SlideOver';
import { colorFor, LEADERBOARD_LABELS, LEGEND_FAMILY_ORDER, FAMILY_LABEL, SHORT_CODE } from '@/components/absences/absenceColors';
import PresenceModuleSwitcher from '@/components/PresenceModuleSwitcher';
import AbsenceSubNav from '@/components/AbsenceSubNav'; 
import { KonzaLoader } from '@/components/ui/KonzaLoader';

const MONTHS = ['JAN', 'FÉV', 'MAR', 'AVR', 'MAI', 'JUIN', 'JUIL', 'AOÛ', 'SEP', 'OCT', 'NOV', 'DÉC'];
const MONTHS_FULL = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const MONTHS_FR = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
const WEEKDAY_ABBR = ['DIM', 'LUN', 'MAR', 'MER', 'JEU', 'VEN', 'SAM'];
const YEAR_PALETTE = ['var(--brand)', 'var(--green)', 'var(--mustard)', 'var(--text-secondary)', 'var(--surface-2)'];
const DEPT_PALETTE = ['var(--brand)', 'var(--green)', 'var(--mustard)', 'var(--text-secondary)'];

type Tab = 'dashboard' | 'grille' | 'journal' | 'comparatif';
type LeaderboardKey = 'maladie' | 'conventionnelle' | 'exceptionnelle' | 'injustifiee';



function AbsencesEmployeContent() {
  const now = new Date();
  const [tab, setTab] = useState<Tab>('dashboard');
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [userRole, setUserRole] = useState('');

  useEffect(() => {
    try {
      const stored = localStorage.getItem('user');
      if (stored) setUserRole(JSON.parse(stored).role || '');
    } catch {}
  }, []);

  function shiftMonth(delta: number) {
    let m = month + delta, y = year;
    if (m < 1) { m = 12; y -= 1; }
    if (m > 12) { m = 1; y += 1; }
    setMonth(m); setYear(y);
  }

  
  return (
    <div className="max-w-[1500px] mx-auto pb-24 space-y-6">
      <PresenceModuleSwitcher />
       <AbsenceSubNav userRole={userRole} />
      <div className="attendance-page-heading">
        <h1 className="text-xl font-semibold text-[var(--text)]">Absences employés</h1>
        <p className="text-sm text-[var(--text-muted)]">Congés, maladie, maternité, paternité, mariage, décès, naissance, non justifiée — tout au même endroit.</p>
      </div>

      {/* mois + année */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {MONTHS.map((m, i) => (
            <Button variant="ghost"
              key={m}
              onClick={() => setMonth(i + 1)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${month === i + 1 ? 'bg-[var(--brand)] border-[var(--border)] text-[var(--on-brand)]' : 'border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--border)]'}`}
            >
              {m}
            </Button>
          ))}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex bg-[var(--surface-2)] p-1 rounded-xl">
            {([
              ['dashboard', 'Tableau de bord'],
              ['grille', 'Grille mensuelle'],
              ['journal', 'Journal'],
              ['comparatif', 'Comparatif'],
            ] as [Tab, string][]).map(([key, label]) => (
              <Button variant="ghost" key={key} onClick={() => setTab(key)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${tab === key ? 'bg-[var(--brand)] text-[var(--on-brand)] shadow-sm' : 'text-[var(--text-muted)] hover:bg-[var(--surface-2)]'}`}>
                {label}
              </Button>
            ))}
          </div>
          <div className="flex items-center gap-1 bg-[var(--surface-2)] rounded-xl px-2 py-1.5">
            <Button variant="ghost" onClick={() => setYear(y => y - 1)} className="p-1 text-[var(--text-muted)]" aria-label="Période précédente"><ChevronLeft size={14} /></Button>
            <span className="text-xs font-semibold px-1">{year}</span>
            <Button variant="ghost" onClick={() => setYear(y => y + 1)} className="p-1 text-[var(--text-muted)]" aria-label="Période suivante"><ChevronRight size={14} /></Button>
          </div>
        </div>
      </div>

      {tab === 'dashboard' && <DashboardTab year={year} month={month} shiftMonth={shiftMonth} />}
      {tab === 'grille' && <GrilleTab year={year} month={month} shiftMonth={shiftMonth} />}
      {tab === 'journal' && <JournalTab year={year} month={month} />}
      {tab === 'comparatif' && <ComparatifTab anchorYear={year} />}
    </div>
  );
}

function qs(params: Record<string, string | number | undefined>) {
  const parts = Object.entries(params).filter(([, v]) => v !== undefined && v !== '').map(([k, v]) => `${k}=${v}`);
  return parts.length ? `?${parts.join('&')}` : '';
}

// ============================================================================
// ONGLET 1 — TABLEAU DE BORD (donuts + KPI + vue annuelle + top scores)
// ============================================================================
function DashboardTab({ year, month }: { year: number; month: number; shiftMonth: (d: number) => void }) {
 const {refonte:uiRefonte,motion:uiMotion}=useModuleVisuals();
  const [data, setData] = useState<any>(null);
  const [yearOverview, setYearOverview] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [leaderboardKey, setLeaderboardKey] = useState<LeaderboardKey>('maladie');
  const [detailEmployeeId, setDetailEmployeeId] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    Promise.all([
      api.get(`/absence-tracking/dashboard${qs({ year, month })}`),
      api.get(`/absence-tracking/yearly-overview${qs({ year })}`),
    ])
      .then(([d, y]) => { setData(d); setYearOverview(y); })
      .catch(e => { console.error('Erreur chargement tableau de bord absences', e); setData(null); })
      .finally(() => setIsLoading(false));
  }, [year, month]);

  if (isLoading) return <LoadingBlock />;
  if (!data) return <ErrorBlock />;

  const absentTodayTotal: number = Object.values(data.absentToday as Record<string, number>).reduce((a: number, b: number) => a + b, 0);
  const totalAbsenceDays = data.byType.reduce((s: number, t: any) => s + t.days, 0);
  const trackableDays = data.byType.filter((t: any) => t.trackable).reduce((s: number, t: any) => s + t.days, 0);

  const typeDonut = [...data.byType].sort((a: any, b: any) => b.days - a.days).map((t: any) => ({
    name: t.label, value: t.days, color: colorFor(t.colorKey).hex,
    pct: totalAbsenceDays ? Math.round((t.days / totalAbsenceDays) * 1000) / 10 : 0,
  }));
  const deptTotal = data.byDepartment.reduce((s: number, d: any) => s + d.days, 0) || 1;
  const deptDonut = [...data.byDepartment].sort((a: any, b: any) => b.days - a.days).map((d: any, i: number) => ({
    name: d.name, value: d.days, color: DEPT_PALETTE[i % DEPT_PALETTE.length],
    pct: Math.round((d.days / deptTotal) * 1000) / 10,
  }));
  const annualSeries = (yearOverview?.months ?? []).map((m: any) => ({ mois: MONTHS_FR[m.month - 1], total: m.totalDays, isCurrent: m.month === month }));

  const trackableTotal = data.byType.filter((t: any) => t.trackable).reduce((s: number, t: any) => s + t.days, 0) || 1;
  const trackableDonut = [...data.byType].filter((t: any) => t.trackable).sort((a: any, b: any) => b.days - a.days).map((t: any) => ({
    name: t.label, value: t.days, color: colorFor(t.colorKey).hex,
    pct: Math.round((t.days / trackableTotal) * 1000) / 10,
  }));
  const topMotif = trackableDonut[0];
  // Département le plus concerné — même filtre "hors congé statutaire/férié/présence"
  // que le donut, via la ventilation par famille déjà fournie par département.
  const EXCLUDED_FAMILIES = ['CONGE_STATUTAIRE', 'FERIE', 'PRESENCE'];
  const deptTrackable = data.byDepartment
    .map((d: any) => ({
      name: d.name,
      days: (d.byFamily ?? []).filter((f: any) => !EXCLUDED_FAMILIES.includes(f.family)).reduce((s: number, f: any) => s + f.days, 0),
    }))
    .filter((d: any) => d.days > 0)
    .sort((a: any, b: any) => b.days - a.days);
  const topDept = deptTrackable[0];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 attendance-metrics">
        <KpiCard icon={Users} label={`${MONTHS_FULL[month - 1]} ${year}`} value={String(data.employeeCount)} sub="employé(s) suivis" tone="sky" />
        <KpiCard icon={AlertTriangle} label="Absents aujourd'hui" value={String(absentTodayTotal)} sub={`sur ${data.employeeCount}`} tone="rose" />
        <KpiCard icon={TrendingUp} label="Jours d'absence" value={String(totalAbsenceDays)} sub="cumulés ce mois" tone="amber" />
        <KpiCard icon={Trophy} label="Le plus concerné" value={data.top20Month[0]?.name?.split(' ')[0] ?? '—'} sub={data.top20Month[0] ? `${data.top20Month[0].days} jour(s) d'absence` : '—'} tone="violet" />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 attendance-metrics">
        <KpiCard icon={ListChecks} label="Jours à surveiller" value={String(trackableDays)} sub="hors congé statutaire" tone="violet" small />
        <KpiCard icon={Percent} label="Taux d'absentéisme" value={`${data.absenteeismRatePercent}%`} sub="jours ouvrés × effectif" tone="rose" small />
        <KpiCard icon={CalendarClock} label="Jours ouvrés" value={String(data.workingDaysInMonth)} sub="dans le mois" tone="sky" small />
      </div>

      {/* absences à surveiller : uniquement les motifs qui comptent pour le suivi RH
          (maladie, maternité, paternité, mariage, décès, naissance, non justifiée,
          congé sans solde) — le congé annuel/anticipé (droit acquis) en est
          volontairement exclu, ce n'est pas un sujet de suivi RH */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
          <p className="text-sm font-semibold text-[var(--text)] mb-1">Absences à surveiller par catégorie — {MONTHS_FULL[month - 1]}</p>
          <p className="text-[11px] text-[var(--text-muted)] mb-4">Hors congé annuel/anticipé (droit acquis, pas un sujet RH)</p>
          {trackableDonut.length === 0 ? <EmptyLine /> : (
            <div className="flex items-center gap-5">
              <div className="w-[130px] h-[130px] relative shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={trackableDonut} dataKey="value" nameKey="name" innerRadius={38} outerRadius={62} paddingAngle={uiRefonte ? 5 : 2} stroke="none" cornerRadius={uiRefonte ? 8 : 0} isAnimationActive={uiRefonte ? uiMotion : undefined} animationDuration={uiRefonte ? 700 : undefined}>
                      {trackableDonut.map((d, i) => <Cell key={i} fill={d.color} />)}
                    </Pie>
                    <Tooltip formatter={(v: any, n: any) => [`${v} j`, n]} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-base font-semibold text-[var(--text)]">{trackableTotal}</span>
                  <span className="text-[8.5px] text-[var(--text-muted)] text-center max-w-[55px]">jours à surveiller</span>
                </div>
              </div>
              <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5">
                {trackableDonut.map((d, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: d.color }} />
                    <span className="text-[var(--text-muted)] flex-1 truncate">{d.name}</span>
                    <span className="font-semibold text-[var(--text)]">{d.pct}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-4">
          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4 flex-1">
            <p className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-2">Motif dominant</p>
            {topMotif ? (
              <>
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ background: topMotif.color }} />
                  <span className="text-sm font-semibold text-[var(--text)] truncate">{topMotif.name}</span>
                </div>
                <p className="text-xs text-[var(--text-muted)]">{topMotif.value} j · {topMotif.pct}% des absences suivies</p>
              </>
            ) : <EmptyLine />}
          </div>
          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4 flex-1">
            <p className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-2">Département le plus concerné</p>
            {topDept ? (
              <>
                <p className="text-sm font-semibold text-[var(--text)] truncate">{topDept.name}</p>
                <p className="text-xs text-[var(--text-muted)]">{topDept.days} j à surveiller ce mois</p>
              </>
            ) : <EmptyLine />}
          </div>
        </div>
      </div>

      {/* deux donuts, comme la maquette */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DonutCard title={`Répartition des absences par type — ${MONTHS_FULL[month - 1]}`} data={typeDonut} centerLabel="jours d'absence" centerValue={totalAbsenceDays} />
        <DonutCard title={`Répartition par département — ${MONTHS_FULL[month - 1]}`} data={deptDonut} centerLabel="jours cumulés" centerValue={deptTotal} />
      </div>

      {/* classement par motif */}
      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2 attendance-filters">
          <p className="text-sm font-semibold text-[var(--text)]">Classement par motif — qui, quel département</p>
          <AttendanceSelect value={leaderboardKey} onChange={e => setLeaderboardKey(e.target.value as LeaderboardKey)} className="text-xs px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)]">
            {Object.entries(LEADERBOARD_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
          </AttendanceSelect>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <p className="text-[10px] font-semibold text-[var(--text-muted)]   mb-2">Top employés</p>
            {data.leaderboards[leaderboardKey].length === 0 ? <EmptyLine /> : data.leaderboards[leaderboardKey].map((e: any, i: number) => (
              <Button variant="ghost" key={e.employeeId} onClick={() => setDetailEmployeeId(e.employeeId)} className="w-full flex items-center gap-3 py-2 border-b border-[var(--border)] last:border-0 text-left hover:bg-[var(--surface-2)]/30 rounded-lg px-1">
                <RankBadge i={i} />
                <span className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[var(--text)] truncate">{e.name}</p>
                  {e.departmentName && <p className="text-[11px] text-[var(--text-muted)]">{e.departmentName}</p>}
                </span>
                <span className="text-sm font-semibold text-[var(--text)]">{e.days} j</span>
              </Button>
            ))}
          </div>
          <div>
            <p className="text-[10px] font-semibold text-[var(--text-muted)]   mb-2">Top départements</p>
            {data.departmentLeaderboards[leaderboardKey].length === 0 ? <EmptyLine /> : data.departmentLeaderboards[leaderboardKey].map((d: any) => {
              const max = data.departmentLeaderboards[leaderboardKey][0]?.days || 1;
              return (
                <div key={d.departmentId} className="py-2">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="font-medium text-[var(--text)]">{d.name}</span>
                    <span className="font-semibold text-[var(--text)]">{d.days} j</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-[var(--surface-2)] overflow-hidden">
                    <div className="h-full rounded-full bg-[var(--mustard)]" style={{ width: `${(d.days / max) * 100}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* vue annuelle + top scores, comme la maquette */}
      <div className="grid grid-cols-1 lg:grid-cols-[1.6fr_1fr] gap-6">
        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
          <p className="text-sm font-semibold text-[var(--text)] mb-4">Vue annuelle des jours d&apos;absence — tous les employés</p>
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={annualSeries} barSize={18}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" opacity={0.15} />
              <XAxis dataKey="mois" fontSize={11} />
              <YAxis fontSize={11} allowDecimals={false} />
              <Tooltip formatter={(v: any) => [`${v} j`, 'Absences']} />
              <Bar dataKey="total" radius={uiRefonte ? [10,10,10,10] : [5, 5, 0, 0]} maxBarSize={uiRefonte ? 16 : undefined} background={uiRefonte ? {fill:"var(--surface-2)",radius:10} : undefined} isAnimationActive={uiRefonte ? uiMotion : undefined} animationDuration={uiRefonte ? 700 : undefined}>
                {annualSeries.map((d: any, i: number) => <Cell key={i} fill={d.isCurrent ? 'var(--brand)' : 'var(--brand-soft)'} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold text-[var(--text)]">Top scores d&apos;absences</p>
            <span className="text-xs text-[var(--text-muted)]">{MONTHS_FULL[month - 1]}</span>
          </div>
          <div className="space-y-0.5 max-h-[260px] overflow-y-auto">
            {data.top20Month.length === 0 ? <EmptyLine /> : data.top20Month.map((e: any, i: number) => (
              <Button variant="ghost" key={e.employeeId} onClick={() => setDetailEmployeeId(e.employeeId)} className="w-full flex items-center gap-3 py-2 border-b border-[var(--border)] last:border-0 text-left hover:bg-[var(--surface-2)]/30 rounded-lg px-1">
                <RankBadge i={i} />
                <span className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[var(--text)] truncate">{e.name}</p>
                  {e.departmentName && <p className="text-[11px] text-[var(--text-muted)]">{e.departmentName}</p>}
                </span>
                <span className={`text-sm font-semibold ${e.days > 6 ? 'text-[var(--danger-text)]' : e.days > 2 ? 'text-[var(--warning-text)]' : 'text-[var(--text-muted)]'}`}>{e.days}j</span>
              </Button>
            ))}
          </div>
        </div>
      </div>

      <EmployeeDetailSlideOver employeeId={detailEmployeeId} year={year} month={month} onClose={() => setDetailEmployeeId(null)} />
    </div>
  );
}

// ============================================================================
// ONGLET 2 — GRILLE MENSUELLE (badges colorés, comme la maquette)
// ============================================================================
function GrilleTab({ year, month }: { year: number; month: number; shiftMonth: (d: number) => void }) {
  const today = useMemo(() => new Date(), []);
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [deptFilter, setDeptFilter] = useState('');
  const [detailEmployeeId, setDetailEmployeeId] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    api.get(`/absence-tracking/grid${qs({ year, month })}`)
      .then(setData)
      .catch(e => { console.error('Erreur chargement grille absences', e); setData(null); })
      .finally(() => setIsLoading(false));
  }, [year, month]);

  const departments = useMemo(() => Array.from(new Set((data?.employees ?? []).map((e: any) => e.departmentName).filter(Boolean))).sort() as string[], [data]);
  const filteredEmployees = useMemo(() => !deptFilter ? (data?.employees ?? []) : (data?.employees ?? []).filter((e: any) => e.departmentName === deptFilter), [data, deptFilter]);

  if (isLoading) return <LoadingBlock />;
  if (!data) return <ErrorBlock />;

  const days = Array.from({ length: data.daysInMonth }, (_, i) => i + 1);
  const holidayByDay = new Map(data.holidays.map((h: any) => [h.day, h.name]));
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() + 1 === month;
  const currentDay = isCurrentMonth ? today.getDate() : null;
  // 🆕 Jours travaillés de l'entreprise (config paie) fournis par le backend — plus de samedi/dimanche en dur
  const workDays: number[] = Array.isArray(data.workDays) && data.workDays.length ? data.workDays : [1, 2, 3, 4, 5];
  const workingDaysCount = days.filter(d => {
    const wd = new Date(year, month - 1, d).getDay();
    return workDays.includes(wd) && !holidayByDay.has(String(d).padStart(2, '0'));
  }).length;

  // 🆕 Légende : uniquement les motifs réellement visibles dans la grille, groupés par famille
  const usedCodes = new Set<string>();
  filteredEmployees.forEach((e: any) => Object.values(e.cells ?? {}).forEach((c: any) => usedCodes.add(c.code)));
  const legendGroups = LEGEND_FAMILY_ORDER
    .map(fam => ({ family: fam, items: (data.legend ?? []).filter((l: any) => l.family === fam && usedCodes.has(l.code)) }))
    .filter(g => g.items.length > 0);
  const cellText = (code?: string) => (!code ? '' : code in SHORT_CODE ? SHORT_CODE[code] : String(code).slice(0, 3));
  const getDayName = (d: number) => new Date(year, month - 1, d).toLocaleDateString('fr-FR', { weekday: 'short' }).slice(0, 3).toUpperCase();

  return (
    <div className="space-y-4">
      {/* bandeau "aujourd'hui", identique au module Présences */}
      {currentDay && (
        <div className="bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  border border-[var(--border)]  rounded-xl p-4 flex items-center gap-3">
          <div className="w-2 h-2 bg-[var(--brand)] rounded-full " />
          <div className="flex-1">
            <p className="text-sm text-[var(--success-text)] ">
               <strong>Aujourd&apos;hui :</strong> {currentDay} {MONTHS_FULL[month - 1]} {year}
            </p>
            <p className="text-xs text-[var(--success-text)]  mt-1">
              Jours ouvrables : {workingDaysCount} ce mois-ci
            </p>
          </div>
        </div>
      )}

      {/* légende — uniquement les motifs présents ce mois-ci, groupés par famille, avec le sigle affiché dans les cases */}
      <div className="bg-[var(--surface)] rounded-2xl p-4 border border-[var(--border)]">
        <h4 className="text-sm font-semibold text-[var(--text-muted)] mb-3">
          Légende <span className="font-normal text-xs">— motifs présents ce mois-ci</span>
        </h4>
        <div className="flex flex-wrap gap-x-8 gap-y-4">
          {legendGroups.map(g => (
            <div key={g.family}>
              <p className="text-[10px] font-semibold   text-[var(--text-muted)] mb-1.5">{FAMILY_LABEL[g.family] ?? g.family}</p>
              <div className="flex flex-wrap gap-x-4 gap-y-2">
                {g.items.map((l: any) => {
                  const c = colorFor(l.colorKey);
                  return (
                    <div key={l.code} className="flex items-center gap-2">
                      <div className="min-w-[2rem] h-6 px-1 rounded flex items-center justify-center text-[9px] font-semibold leading-none" style={{ background: c.hex, color: c.fg }}>
                        {cellText(l.code)}
                      </div>
                      <span className="text-xs text-[var(--text-muted)]">{l.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
          <div>
            <p className="text-[10px] font-semibold   text-[var(--text-muted)] mb-1.5">Calendrier</p>
            <div className="flex items-center gap-2">
              <div className="min-w-[2rem] h-6 rounded bg-[var(--border)]" />
              <span className="text-xs text-[var(--text-muted)]">Jour de repos ou férié</span>
            </div>
          </div>
        </div>
      </div>

      {/* grille */}
      <div className="bg-[var(--surface)] rounded-2xl shadow-sm border border-[var(--border)] overflow-hidden min-h-[600px]">
        <div className="p-4 border-b border-[var(--border)] flex items-center justify-between flex-wrap gap-2">
          <h3 className="font-semibold text-[var(--text)]">
            Grille mensuelle
            <span className="text-sm font-normal text-[var(--text-muted)] ml-2">
              ({workingDaysCount} jours ouvrables / {data.daysInMonth} jours au total)
            </span>
          </h3>
          {departments.length > 0 && (
            <AttendanceSelect value={deptFilter} onChange={e => setDeptFilter(e.target.value)} className="text-xs px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)]">
              <option value="">Tous les départements</option>
              {departments.map(d => <option key={d} value={d}>{d}</option>)}
            </AttendanceSelect>
          )}
        </div>

        {filteredEmployees.length === 0 ? (
          <div className="flex items-center justify-center py-32 text-[var(--text-muted)]">
            <p className="text-sm">Aucun employé à afficher.</p>
          </div>
        ) : (
          <div className="overflow-x-auto attendance-table-scroll" style={{ scrollbarWidth: 'thin', scrollbarColor: 'var(--brand) transparent' }} tabIndex={0} role="region" aria-label="Tableau défilant horizontalement">
            <div className="inline-block min-w-full align-middle">
              {/* en-tête jours */}
              <div className="border-b border-[var(--border)] flex">
                <div className="sticky left-0 z-20 w-48 shrink-0 bg-[var(--surface-2)] p-3 font-semibold text-xs  border-r text-[var(--text-muted)]">
                  Employé
                </div>
                {days.map(d => {
                  const isToday = d === currentDay;
                  const wd = new Date(year, month - 1, d).getDay();
                  const isWorking = workDays.includes(wd);
                  const holidayName = holidayByDay.get(String(d).padStart(2, '0')) as string | undefined;
                  return (
                    <div key={d} title={holidayName ?? ''} className={`w-10 shrink-0 text-center p-2 border-r ${
                      isToday ? 'bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] '
                      : !isWorking || holidayName ? 'bg-[var(--border)]'
                      : 'bg-[var(--surface-2)]'
                    }`}>
                      <div className={`text-[10px] font-semibold ${isToday ? 'text-[var(--success-text)] ' : !isWorking || holidayName ? 'text-[var(--text-muted)]' : 'text-[var(--text-muted)]'}`}>
                        {getDayName(d)}
                      </div>
                      <div className={`text-xs font-semibold ${isToday ? 'text-[var(--success-text)] ' : !isWorking || holidayName ? 'text-[var(--text-muted)]' : 'text-[var(--text-muted)]'}`}>
                        {d}
                      </div>
                      {isToday && <div className="w-1.5 h-1.5 bg-[var(--brand)] rounded-full mx-auto mt-0.5" />}
                    </div>
                  );
                })}
              </div>

              {/* lignes employés */}
              <div className="divide-y divide-[var(--border)]">
                {filteredEmployees.map((emp: any) => (
                  <div key={emp.id} className="flex hover:bg-[var(--surface-2)] transition-colors">
                    <Button variant="ghost" onClick={() => setDetailEmployeeId(emp.id)} className="sticky left-0 z-10 w-48 shrink-0 bg-[var(--surface)] p-3 border-r flex items-center gap-3 text-left hover:text-[var(--success-text)]">
                      <div className="w-8 h-8 rounded-full bg-[var(--border)] flex items-center justify-center text-xs font-semibold text-[var(--text-muted)] shrink-0">
                        {emp.name?.[0] ?? '?'}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold truncate text-[var(--text)]">{emp.name}</p>
                        <p className="text-[10px] text-[var(--text-muted)] truncate">{emp.departmentName || '—'}</p>
                      </div>
                    </Button>
                    {days.map(d => {
                      const dayStr = String(d).padStart(2, '0');
                      const cell = emp.cells[dayStr];
                      const c = cell ? colorFor(cell.colorKey) : null;
                      const isToday = d === currentDay;
                      const wd = new Date(year, month - 1, d).getDay();
                      const isWorking = workDays.includes(wd);
                      const holidayName = holidayByDay.get(dayStr) as string | undefined;
                      return (
                        <div
                          key={d}
                          title={cell?.label ?? (holidayName || (!isWorking ? 'Jour non ouvrable' : ''))}
                          className={`w-10 shrink-0 min-h-[32px] border-b border-r border-[var(--border)] flex items-center justify-center text-[9px] font-semibold leading-none ${isToday ? 'ring-2 ring-[var(--focus)] ring-inset' : ''} ${!cell && (!isWorking || holidayName) ? 'bg-[var(--border)]' : ''}`}
                          style={cell ? { background: c!.hex, color: c!.fg } : undefined}
                        >
                          {cell ? cellText(cell.code) : null}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <EmployeeDetailSlideOver employeeId={detailEmployeeId} year={year} month={month} onClose={() => setDetailEmployeeId(null)} />
    </div>
  );
}

// ============================================================================
// ONGLET 3 — JOURNAL DÉTAILLÉ
// ============================================================================
function JournalTab({ year, month }: { year: number; month: number }) {
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [familyFilter, setFamilyFilter] = useState('');
  const [paidFilter, setPaidFilter] = useState('');

  useEffect(() => {
    setIsLoading(true);
    api.get(`/absence-tracking/month-journal${qs({ year, month })}`)
      .then(setData)
      .catch(e => { console.error('Erreur chargement journal absences', e); setData(null); })
      .finally(() => setIsLoading(false));
  }, [year, month]);

  const families = useMemo(() => Array.from(new Set((data?.journal ?? []).map((j: any) => j.familyLabel))) as string[], [data]);
  const filtered = useMemo(() => (data?.journal ?? []).filter((j: any) =>
    (!familyFilter || j.familyLabel === familyFilter) &&
    (!paidFilter || (paidFilter === 'paid' ? j.paid : !j.paid)),
  ), [data, familyFilter, paidFilter]);

  if (isLoading) return <LoadingBlock />;
  if (!data) return <ErrorBlock />;

  return (
    <div className="space-y-6">
      <div className="bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  border border-[var(--border)]  rounded-2xl p-4">
        <p className="text-sm text-[var(--success-text)] ">{data.summary}</p>
      </div>

      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
        <div className="p-4 flex items-center justify-between border-b border-[var(--border)] flex-wrap gap-2">
          <p className="text-sm font-semibold text-[var(--text)]">Journal — {MONTHS_FULL[month - 1]} {year}</p>
          <div className="flex gap-2 attendance-filters">
            <AttendanceSelect value={familyFilter} onChange={e => setFamilyFilter(e.target.value)} className="text-xs px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)]">
              <option value="">Toutes catégories</option>
              {families.map(f => <option key={f} value={f}>{f}</option>)}
            </AttendanceSelect>
            <AttendanceSelect value={paidFilter} onChange={e => setPaidFilter(e.target.value)} className="text-xs px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)]">
              <option value="">Payé et non payé</option>
              <option value="paid">Payé</option>
              <option value="unpaid">Non payé</option>
            </AttendanceSelect>
          </div>
        </div>
        <div className="overflow-x-auto attendance-table-scroll" tabIndex={0} role="region" aria-label="Tableau défilant horizontalement">
          <table className="w-full text-sm attendance-table">
            <thead className="bg-[var(--surface-2)]">
              <tr>{['Employé', 'Motif', 'Catégorie', 'Période', 'Durée', 'Paie', 'Détail'].map(h => <th key={h} className="px-3 py-2 text-left text-[10px] font-semibold text-[var(--text-muted)]  whitespace-nowrap">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-10 text-[var(--text-muted)]">Aucune absence pour ce filtre.</td></tr>
              ) : filtered.map((j: any, i: number) => (
                <tr key={i} className="hover:bg-[var(--surface-2)]/40">
                  <td className="px-3 py-2.5">
                    <p className="font-semibold text-[var(--text)]">{j.employeeName}</p>
                    {j.departmentName && <p className="text-[11px] text-[var(--text-muted)]">{j.departmentName}</p>}
                  </td>
                  <td className="px-3 py-2.5 text-[var(--text-muted)]">{j.label}</td>
                  <td className="px-3 py-2.5">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-[var(--surface-2)] text-[var(--text-muted)]">{j.familyLabel}</span>
                  </td>
                  <td className="px-3 py-2.5 text-[var(--text-muted)] whitespace-nowrap text-xs">
                    {new Date(j.startDate).toLocaleDateString('fr-FR')} → {new Date(j.endDate).toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-3 py-2.5 font-semibold text-[var(--text)]">
                    {j.days} j
                    {j.uncoveredDays > 0 && (
                      <span
                        className="block text-[10px] font-semibold text-[var(--warning-text)]  whitespace-nowrap"
                        title="Jours demandés au-delà du droit conventionnel : non payés, comptés absents seulement si l'employé ne pointe pas."
                      >
                        +{j.uncoveredDays} j hors droit
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2.5">
                    {j.family === 'CONGE_STATUTAIRE' && !j.trackable ? (
                      // ✅ Congé annuel/anticipé = droit acquis, toujours payé par définition —
                      // afficher un badge "Payé" ici serait trivial et sans intérêt. Seul le cas
                      // "congé payé travaillé" (CPT, visible dans la grille) a une info à donner.
                      <span className="text-[11px] text-[var(--text-muted)]">Droit acquis</span>
                    ) : j.paid ? (
                      <span className="flex items-center gap-1 text-[var(--success-text)] text-xs font-semibold"><FileCheck2 size={13} /> Payé</span>
                    ) : (
                      <span className="flex items-center gap-1 text-[var(--danger-text)] text-xs font-semibold"><FileX2 size={13} /> Non payé</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-[var(--text-muted)] text-xs max-w-[220px] truncate" title={j.reason ?? ''}>{j.reason ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// ONGLET 4 — COMPARATIF PLURIANNUEL
// ============================================================================
function ComparatifTab({ anchorYear }: { anchorYear: number }) {
 const {refonte:uiRefonte,motion:uiMotion}=useModuleVisuals();
  const candidateYears = useMemo(() => [anchorYear, anchorYear - 1, anchorYear - 2, anchorYear - 3, anchorYear - 4], [anchorYear]);
  const [selectedYears, setSelectedYears] = useState<number[]>([anchorYear, anchorYear - 1, anchorYear - 2]);
  const [compareData, setCompareData] = useState<any>(null);
  const [monthlyByYear, setMonthlyByYear] = useState<Record<number, any[]>>({});
  const [isLoading, setIsLoading] = useState(true);

  const sortedAsc = useMemo(() => [...selectedYears].sort((a, b) => a - b), [selectedYears]);
  const sortedDesc = useMemo(() => [...selectedYears].sort((a, b) => b - a), [selectedYears]);

  function toggleYear(y: number) {
    setSelectedYears(prev => {
      if (prev.includes(y)) { if (prev.length <= 1) return prev; return prev.filter(x => x !== y); }
      return [...prev, y];
    });
  }

  useEffect(() => {
    if (sortedAsc.length < 2) return;
    setIsLoading(true);
    Promise.all([
      api.get(`/absence-tracking/compare${qs({ years: sortedAsc.join(',') })}`),
      Promise.all(sortedAsc.map(y => api.get(`/absence-tracking/yearly-overview${qs({ year: y })}`))),
    ])
      .then(([cmp, yearlies]: [any, any[]]) => {
        setCompareData(cmp);
        const map: Record<number, any[]> = {};
        yearlies.forEach((yy, i) => { map[sortedAsc[i]] = yy.months; });
        setMonthlyByYear(map);
      })
      .catch(e => { console.error('Erreur chargement comparatif absences', e); setCompareData(null); })
      .finally(() => setIsLoading(false));
  }, [sortedAsc.join(',')]);

  const yearColor = (y: number) => YEAR_PALETTE[sortedDesc.indexOf(y) % YEAR_PALETTE.length];

  const monthlyComparison = useMemo(() => MONTHS_FR.map((label, idx) => {
    const row: any = { mois: label };
    sortedAsc.forEach(y => { row[String(y)] = monthlyByYear[y]?.[idx]?.totalDays ?? 0; });
    return row;
  }), [monthlyByYear, sortedAsc.join(',')]);

  const familyRows = useMemo(() => {
    if (!compareData) return [];
    const families = new Set<string>();
    compareData.years.forEach((y: any) => Object.keys(y.byFamily).forEach(f => families.add(f)));
    return Array.from(families).map(fam => {
      const values: Record<number, number> = {};
      compareData.years.forEach((y: any) => { values[y.year] = y.byFamily[fam] ?? 0; });
      return { label: fam, values };
    });
  }, [compareData]);

  const deptRows = useMemo(() => {
    if (!compareData) return [];
    const depts = new Set<string>();
    compareData.years.forEach((y: any) => Object.keys(y.byDepartment).forEach(d => depts.add(d)));
    return Array.from(depts).map(dep => {
      const values: Record<number, number> = {};
      compareData.years.forEach((y: any) => { values[y.year] = y.byDepartment[dep] ?? 0; });
      return { label: dep, values };
    });
  }, [compareData]);

  return (
    <div className="space-y-6">
      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4">
        <p className="text-sm font-semibold text-[var(--text)] mb-3">Comparer plusieurs années</p>
        <div className="flex flex-wrap gap-2">
          {candidateYears.map(y => {
            const active = selectedYears.includes(y);
            return (
              <Button variant="ghost" key={y} onClick={() => toggleYear(y)} className={`px-4 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${active ? 'bg-[var(--brand)] text-[var(--on-brand)] border-transparent' : 'text-[var(--text-muted)] border-[var(--border)]'}`} style={active ? { background: yearColor(y) } : {}}>
                {y}
              </Button>
            );
          })}
        </div>
      </div>

      {sortedAsc.length < 2 ? (
        <div className="text-center py-10 text-[var(--text-muted)] text-sm">Sélectionne au moins 2 années pour comparer.</div>
      ) : isLoading || !compareData ? <LoadingBlock /> : (
        <>
          <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${compareData.years.length}, minmax(0, 1fr))` }}>
            {compareData.years.map((y: any) => {
              const t = compareData.trend.find((d: any) => d.year === y.year);
              return (
                <div key={y.year} className="bg-[var(--surface)] rounded-2xl border p-4" style={{ borderColor: `${yearColor(y.year)}55` }}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-semibold  tracking-wide" style={{ color: yearColor(y.year) }}>{y.year}</span>
                    {t?.deltaPercent != null && (
                      <span className={`text-[10px] font-semibold ${t.deltaDays > 0 ? 'text-[var(--danger-text)]' : t.deltaDays < 0 ? 'text-[var(--success-text)]' : 'text-[var(--text-muted)]'}`}>
                        {t.deltaDays === 0 ? '=' : `${t.deltaDays > 0 ? '▲' : '▼'} ${Math.abs(t.deltaPercent)}%`}
                      </span>
                    )}
                  </div>
                  <p className="text-2xl font-semibold text-[var(--text)]">{y.totalDays} <span className="text-sm font-medium text-[var(--text-muted)]">jours</span></p>
                  <p className="text-xs text-[var(--text-muted)] mt-1">{y.employeeCount} employés · {y.avgDaysPerEmployee} j/employé</p>
                  <p className="text-xs text-[var(--warning-text)] mt-1">{y.trackableDays} j à surveiller</p>
                </div>
              );
            })}
          </div>

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <p className="text-sm font-semibold text-[var(--text)] mb-4">Évolution mensuelle — comparaison</p>
            <ResponsiveContainer width="100%" height={260}>
              {uiRefonte ? (<AreaChart data={monthlyComparison}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="mois" fontSize={12} />
                <YAxis fontSize={12} allowDecimals={false} />
                <Tooltip />
                <RLegend />
                {sortedAsc.map(y => <Area key={y} type="monotone" dataKey={String(y)} name={String(y)} stroke={yearColor(y)} strokeWidth={2.5} dot={false}  fill="var(--loan-gradient-1)" fillOpacity={1} isAnimationActive={uiMotion} animationDuration={700}/>)}
              </AreaChart>) : (<LineChart data={monthlyComparison}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="mois" fontSize={12} />
                <YAxis fontSize={12} allowDecimals={false} />
                <Tooltip />
                <RLegend />
                {sortedAsc.map(y => <Line key={y} type="monotone" dataKey={String(y)} name={String(y)} stroke={yearColor(y)} strokeWidth={2.5} dot={{ r: 2.5 }} />)}
              </LineChart>)}
            </ResponsiveContainer>
          </div>

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <p className="text-sm font-semibold text-[var(--text)] mb-4">Par département — comparaison</p>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={deptRows.map(r => ({ department: r.label, ...Object.fromEntries(sortedAsc.map(y => [String(y), r.values[y] ?? 0])) }))} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} vertical={false} />
                <XAxis dataKey="department" fontSize={11} />
                <YAxis fontSize={11} allowDecimals={false} />
                <Tooltip />
                <RLegend />
                {sortedAsc.map(y => <Bar key={y} dataKey={String(y)} name={String(y)} fill={yearColor(y)} radius={uiRefonte ? [10,10,10,10] : [4, 4, 0, 0]} maxBarSize={uiRefonte ? 16 : undefined} background={uiRefonte ? {fill:"var(--surface-2)",radius:10} : undefined} isAnimationActive={uiRefonte ? uiMotion : undefined} animationDuration={uiRefonte ? 700 : undefined} />)}
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-4 pt-3 border-t border-[var(--border)]">
              <CompareTable rows={deptRows} years={sortedDesc} label="Département" />
            </div>
          </div>

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <p className="text-sm font-semibold text-[var(--text)] mb-4">Par catégorie de motif — comparaison précise</p>
            <CompareTable rows={familyRows} years={sortedDesc} label="Catégorie" />
          </div>
        </>
      )}
    </div>
  );
}

function CompareTable({ rows, years, label }: { rows: { label: string; values: Record<number, number> }[]; years: number[]; label: string }) {
  const newest = years[0], oldest = years[years.length - 1];
  return (
    <div className="overflow-x-auto attendance-table-scroll" tabIndex={0} role="region" aria-label="Tableau défilant horizontalement">
      <table className="w-full text-sm attendance-table">
        <thead>
          <tr className="border-b border-[var(--border)]">
            <th className="text-left px-2 py-2 text-[10px] font-semibold text-[var(--text-muted)] ">{label}</th>
            {years.map(y => <th key={y} className="text-right px-2 py-2 text-[10px] font-semibold text-[var(--text-muted)] ">{y}</th>)}
            {years.length > 1 && <th className="text-right px-2 py-2 text-[10px] font-semibold text-[var(--text-muted)] ">Var. {oldest}→{newest}</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map(r => {
            const oldVal = r.values[oldest] ?? 0, newVal = r.values[newest] ?? 0;
            const delta = newVal - oldVal;
            const pct = oldVal ? Math.round((delta / oldVal) * 1000) / 10 : (newVal > 0 ? 100 : 0);
            return (
              <tr key={r.label} className="border-b border-[var(--border)]">
                <td className="px-2 py-2 font-medium text-[var(--text)] whitespace-nowrap">{r.label}</td>
                {years.map(y => <td key={y} className="text-right px-2 py-2 text-[var(--text-muted)]">{r.values[y] ?? 0} j</td>)}
                {years.length > 1 && (
                  <td className={`text-right px-2 py-2 font-semibold ${delta > 0 ? 'text-[var(--danger-text)]' : delta < 0 ? 'text-[var(--success-text)]' : 'text-[var(--text-muted)]'}`}>
                    {delta === 0 ? '=' : `${delta > 0 ? '+' : ''}${pct}%`}
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ============================================================================
// PANNEAU DÉTAIL EMPLOYÉ
// ============================================================================
function EmployeeDetailSlideOver({ employeeId, year, month, onClose }: { employeeId: string | null; year: number; month: number; onClose: () => void }) {
 const {refonte:uiRefonte,motion:uiMotion}=useModuleVisuals();
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!employeeId) { setData(null); return; }
    setIsLoading(true);
    api.get(`/absence-tracking/employee/${employeeId}${qs({ year, month })}`)
      .then(setData)
      .catch(e => { console.error('Erreur chargement détail employé', e); setData(null); })
      .finally(() => setIsLoading(false));
  }, [employeeId, year, month]);

  return (
    <SlideOver open={!!employeeId} onClose={onClose} title={data?.employee?.name ?? '…'} subtitle={data?.employee?.departmentName}>
      {isLoading || !data ? <LoadingBlock /> : (
        <div className="space-y-5">
          {(data.recurrence.alertSickRecurrence || data.recurrence.alertSickDays || data.recurrence.alertTrackableDays) && (
            <div className="bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  border border-[var(--border)]  rounded-xl p-3 space-y-1">
              {data.recurrence.alertSickRecurrence && <p className="text-xs text-[var(--danger-text)]  flex items-center gap-1.5"><Stethoscope size={13} /> {data.recurrence.sickEpisodesRolling90d} épisodes de maladie distincts sur 90 jours</p>}
              {data.recurrence.alertSickDays && <p className="text-xs text-[var(--danger-text)] ">{data.recurrence.sickDaysYear} jours de maladie sur l&apos;année</p>}
              {data.recurrence.alertTrackableDays && <p className="text-xs text-[var(--danger-text)] ">{data.recurrence.trackableDaysYear} jours d&apos;absence à surveiller sur l&apos;année</p>}
            </div>
          )}

          <div>
            <p className="text-xs font-semibold text-[var(--text-muted)]  tracking-wide mb-2">Répartition — {MONTHS_FULL[month - 1]}</p>
            {data.pieByType.length === 0 ? <EmptyLine /> : (
              <div className="space-y-2">
                {data.pieByType.map((t: any) => {
                  const c = colorFor(t.colorKey);
                  return (
                    <div key={t.code} className="flex items-center gap-2 text-sm">
                      <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: c.hex }} />
                      <span className="flex-1 text-[var(--text)]">{t.label}</span>
                      <span className="font-semibold text-[var(--text)]">{t.days} j</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div>
            <p className="text-xs font-semibold text-[var(--text-muted)]  tracking-wide mb-2">Vue annuelle {year}</p>
            <ResponsiveContainer width="100%" height={140}>
              <BarChart data={data.yearOverview.map((m: any) => ({ mois: MONTHS_FR[m.month - 1], jours: m.totalDays }))}>
                <XAxis dataKey="mois" fontSize={10} />
                <YAxis fontSize={10} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="jours" fill="var(--loan-chart-2)" radius={uiRefonte ? [10,10,10,10] : [3, 3, 0, 0]} maxBarSize={uiRefonte ? 16 : undefined} background={uiRefonte ? {fill:"var(--surface-2)",radius:10} : undefined} isAnimationActive={uiRefonte ? uiMotion : undefined} animationDuration={uiRefonte ? 700 : undefined} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </SlideOver>
  );
}

// ============================================================================
// PETITS UTILITAIRES D'AFFICHAGE
// ============================================================================
function DonutCard({ title, data, centerLabel, centerValue }: { title: string; data: { name: string; value: number; color: string; pct: number }[]; centerLabel: string; centerValue: number }) {
 const {refonte:uiRefonte,motion:uiMotion}=useModuleVisuals();
  return (
    <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
      <p className="text-sm font-semibold text-[var(--text)] mb-4">{title}</p>
      {data.length === 0 ? <EmptyLine /> : (
        <div className="flex items-center gap-5">
          <div className="w-[150px] h-[150px] relative shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={data} dataKey="value" nameKey="name" innerRadius={45} outerRadius={70} paddingAngle={uiRefonte ? 5 : 2} stroke="none" cornerRadius={uiRefonte ? 8 : 0} isAnimationActive={uiRefonte ? uiMotion : undefined} animationDuration={uiRefonte ? 700 : undefined}>
                  {data.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
                <Tooltip formatter={(v: any, n: any) => [`${v} j`, n]} />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-lg font-semibold text-[var(--text)]">{centerValue}</span>
              <span className="text-[9px] text-[var(--text-muted)] text-center max-w-[60px]">{centerLabel}</span>
            </div>
          </div>
          <div className="flex-1 min-w-0 space-y-1.5">
            {data.map((d, i) => (
              <div key={i} className="flex items-center gap-2 text-xs">
                <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: d.color }} />
                <span className="text-[var(--text-muted)] flex-1 truncate">{d.name}</span>
                <span className="font-semibold text-[var(--text)]">{d.pct}%</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function RankBadge({ i }: { i: number }) {
  return (
    <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-[11px] font-semibold shrink-0 ${i === 0 ? 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))]  text-[var(--warning-text)] ' : 'bg-[var(--surface-2)] text-[var(--text-muted)]'}`}>
      {i + 1}
    </span>
  );
}

function KpiCard({ icon: Icon, label, value, sub, tone, small }: { icon: any; label: string; value: string; sub?: string; tone: 'sky' | 'rose' | 'amber' | 'violet'; small?: boolean }) {
  const cls: Record<string, string> = {
    sky: 'bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] text-[var(--success-text)]  ',
    rose: 'bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] text-[var(--danger-text)]  ',
    amber: 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] text-[var(--warning-text)]  ',
    violet: 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] text-[var(--warning-text)]  ',
  };
  return (
    <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${cls[tone]}`}><Icon size={18} /></div>
      <p className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-1">{label}</p>
      <p className={`${small ? 'text-base' : 'text-lg'} font-semibold text-[var(--text)] truncate`}>{value}</p>
      {sub && <p className="text-[11px] text-[var(--text-muted)] mt-0.5">{sub}</p>}
    </div>
  );
}

function LoadingBlock() {
  return <ModulePageSkeleton label="Chargement des absences" />;
}
function ErrorBlock() {
  return <div className="text-center py-20 text-[var(--text-muted)] text-sm">Impossible de charger ces données pour le moment.</div>;
}
function EmptyLine() {
  return <p className="text-xs text-[var(--text-muted)] py-2">Aucune donnée pour cette période.</p>;
}

// 🔒 « Suivi des absences » : réservé à l'admin / RH. Un employé (ou manager) est renvoyé vers
// « Mes absences », même s'il tape l'adresse à la main. (Le serveur refuse aussi : 403.)
const TRACKING_ROLES = ['ADMIN', 'SUPER_ADMIN', 'HR_MANAGER'];

export default function AbsencesEmployePage() {
  const router = useRouter();
  const { bp } = useBasePath();
  const [allowed, setAllowed] = useState<boolean | null>(null);

  useEffect(() => {
    let role = '';
    try {
      const stored = localStorage.getItem('user');
      if (stored) role = JSON.parse(stored).role || '';
    } catch {}
    const ok = TRACKING_ROLES.includes(role);
    setAllowed(ok);
    if (!ok) router.replace(bp('/presences/absences/mon-espace'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (allowed !== true) {
    return <div className="p-10 text-center text-sm text-[var(--text-muted)]">Chargement…</div>;
  }
  return <ModulePageFrame kind="dashboard"><AbsencesEmployeContent /></ModulePageFrame>;
}