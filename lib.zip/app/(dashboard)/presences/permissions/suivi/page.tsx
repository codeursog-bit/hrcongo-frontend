'use client';
import { AttendanceSelect } from '@/components/attendance/AttendanceSelect';
import { AttendanceModuleFrame as ModulePageFrame } from '@/components/attendance/AttendanceModuleFrame';
import { ModulePageSkeleton } from '@/components/requests/ModulePageFrame';

// ============================================================================
// 📁 app/(dashboard)/presences/permissions/suivi/page.tsx
// ✅ Page "Suivi des permissions" — employés avec au moins un ticket autorisé
//    sur la période sélectionnée, filtres mois/année/département/type, KPI,
//    clic → fiche employé. Même modèle que /loans/suivi-dettes.
// ============================================================================

import React, { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { Filter, Users2, ChevronRight, Ticket, CheckCircle2, Clock } from 'lucide-react';
import { api } from '@/services/api';
import { useBasePath } from '@/hooks/useBasePath';
import PresenceModuleSwitcher from '@/components/PresenceModuleSwitcher';
import PermissionsSubNav from '@/components/PermissionsSubNav';
import { KonzaLoader } from '@/components/ui/KonzaLoader';

const MONTHS_FR = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const TYPE_LABEL: Record<string, string> = { URGENCE: 'Urgence', MISSION: 'Mission', AUTRE: 'Autre' };

export default function PermissionsSuiviPage() {
 const [uiLoadError,setUiLoadError]=useState('');
  const { bp } = useBasePath();
  const [tickets, setTickets] = useState<any[]>([]);
  const [userRole, setUserRole] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const now = new Date();
  const [month, setMonth] = useState<number | ''>(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [deptFilter, setDeptFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  useEffect(() => {
    try { const stored = localStorage.getItem('user'); if (stored) setUserRole(JSON.parse(stored).role || ''); } catch {}
    (async () => {
      try { setTickets((await api.get('/permission-tickets')) || []); }
      catch (e) { console.error('Erreur chargement suivi permissions', e); setUiLoadError('Le chargement a échoué. Réessayez dans un instant.'); }
      finally { setIsLoading(false); }
    })();
  }, []);

  const availableYears = useMemo(() => {
    const set = new Set<number>([now.getFullYear()]);
    tickets.forEach(t => set.add(new Date(t.createdAt).getFullYear()));
    return Array.from(set).sort((a, b) => b - a);
  }, [tickets, now]);

  const departments = useMemo(() => Array.from(new Set(tickets.map(t => t.employee?.department?.name).filter(Boolean))).sort(), [tickets]);

  const inPeriod = useMemo(() => tickets.filter(t => {
    const d = new Date(t.createdAt);
    if (d.getFullYear() !== year) return false;
    if (month !== '' && d.getMonth() + 1 !== month) return false;
    return (!typeFilter || t.type === typeFilter) && (!deptFilter || t.employee?.department?.name === deptFilter);
  }), [tickets, month, year, typeFilter, deptFilter]);

  const byEmployee = useMemo(() => {
    const map = new Map<string, { employeeId: string; employee: any; total: number; approved: number; pending: number; rejected: number }>();
    inPeriod.forEach(t => {
      const key = t.employeeId;
      if (!map.has(key)) map.set(key, { employeeId: key, employee: t.employee, total: 0, approved: 0, pending: 0, rejected: 0 });
      const e = map.get(key)!;
      e.total += 1;
      if (t.status === 'APPROVED') e.approved += 1;
      else if (t.status === 'PENDING') e.pending += 1;
      else if (t.status === 'REJECTED') e.rejected += 1;
    });
    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [inPeriod]);

  const kpis = useMemo(() => ({
    employees: byEmployee.length,
    total: inPeriod.length,
    approved: inPeriod.filter(t => t.status === 'APPROVED').length,
    pending: inPeriod.filter(t => t.status === 'PENDING').length,
  }), [byEmployee, inPeriod]);

  if (isLoading) return <ModulePageSkeleton label="Chargement des permissions" />;

  return (
    <ModulePageFrame kind="list" error={uiLoadError}><div className="max-w-[1500px] mx-auto pb-24 space-y-6">
      <PresenceModuleSwitcher />
      <PermissionsSubNav userRole={userRole} />

      <div className="attendance-page-heading">
        <h1 className="text-xl font-semibold text-[var(--text)]">Suivi des permissions</h1>
        <p className="text-sm text-[var(--text-muted)]">Employés ayant demandé une sortie sur la période sélectionnée.</p>
      </div>

      {/* ══════════════════ FILTRES ══════════════════ */}
      <div className="flex flex-wrap gap-2 attendance-filters">
        <AttendanceSelect value={month} onChange={e => setMonth(e.target.value === '' ? '' : Number(e.target.value))} className="text-xs px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)]">
          <option value="">Toute l'année</option>
          {MONTHS_FR.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
        </AttendanceSelect>
        <AttendanceSelect value={year} onChange={e => setYear(Number(e.target.value))} className="text-xs px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)]">
          {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
        </AttendanceSelect>
        <FilterSelect icon={Filter} value={typeFilter} onChange={setTypeFilter} placeholder="Tous les types" options={Object.entries(TYPE_LABEL)} />
        {departments.length > 0 && <FilterSelect icon={Users2} value={deptFilter} onChange={setDeptFilter} placeholder="Tous les départements" options={departments.map(d => [d, d] as [string, string])} />}
      </div>

      {/* ══════════════════ KPI ══════════════════ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 attendance-metrics">
        <KpiCard icon={Users2} label="Employés concernés" value={String(kpis.employees)} tone="slate" />
        <KpiCard icon={Ticket} label="Total tickets (période)" value={String(kpis.total)} tone="sky" />
        <KpiCard icon={CheckCircle2} label="Autorisés" value={String(kpis.approved)} tone="emerald" />
        <KpiCard icon={Clock} label="En attente" value={String(kpis.pending)} tone="amber" />
      </div>

      {/* ══════════════════ LISTE PAR EMPLOYÉ ══════════════════ */}
      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
        <div className="overflow-x-auto attendance-table-scroll" tabIndex={0} role="region" aria-label="Tableau défilant horizontalement">
          <table className="w-full text-sm attendance-table">
            <thead className="bg-[var(--surface-2)]">
              <tr>{['Employé', 'Département', 'Total tickets', 'Autorisés', 'En attente', 'Refusés', ''].map(h => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-[var(--text-muted)]  whitespace-nowrap">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {byEmployee.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-14 text-[var(--text-muted)]">Aucun ticket pour cette période/ce filtre.</td></tr>
              ) : byEmployee.map(e => (
                <tr key={e.employeeId} className="hover:bg-[var(--surface-2)]/40">
                  <td className="px-4 py-3">
                    <Link href={bp(`/presences/permissions/suivi/${e.employeeId}`)} className="font-semibold text-[var(--text)] hover:text-[var(--success-text)] hover:underline">
                      {e.employee?.firstName} {e.employee?.lastName}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-[var(--text-muted)]">{e.employee?.department?.name || '—'}</td>
                  <td className="px-4 py-3 font-semibold text-[var(--text)]">{e.total}</td>
                  <td className="px-4 py-3 text-[var(--success-text)] font-semibold">{e.approved}</td>
                  <td className="px-4 py-3 text-[var(--warning-text)]">{e.pending}</td>
                  <td className="px-4 py-3 text-[var(--danger-text)]">{e.rejected}</td>
                  <td className="px-4 py-3 text-right">
                    <Link href={bp(`/presences/permissions/suivi/${e.employeeId}`)} className="text-[var(--success-text)] hover:underline text-xs font-semibold flex items-center gap-0.5 justify-end">
                      Voir la fiche <ChevronRight size={12} />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div></ModulePageFrame>
  );
}

function KpiCard({ icon: Icon, label, value, tone }: { icon: any; label: string; value: string; tone: 'slate' | 'emerald' | 'amber' | 'sky' }) {
  const cls: Record<string, string> = {
    slate: 'bg-[var(--surface-2)] text-[var(--text-muted)]',
    emerald: 'bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] text-[var(--success-text)]  ',
    amber: 'bg-[color-mix(in_srgb,var(--mustard)_14%,var(--surface))] text-[var(--warning-text)]  ',
    sky: 'bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] text-[var(--success-text)]  ',
  };
  return (
    <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${cls[tone]}`}><Icon size={18} /></div>
      <p className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-1">{label}</p>
      <p className="text-lg font-semibold text-[var(--text)] truncate">{value}</p>
    </div>
  );
}

function FilterSelect({ icon: IconEl, value, onChange, placeholder, options }: { icon: any; value: string; onChange: (v: string) => void; placeholder: string; options: [string, string][] }) {
  return (
    <div className="relative">
      <IconEl size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
      <AttendanceSelect value={value} onChange={e => onChange(e.target.value)} className="pl-7 pr-3 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-xs">
        <option value="">{placeholder}</option>
        {options.map(([val, label]) => <option key={val} value={val}>{label}</option>)}
      </AttendanceSelect>
    </div>
  );
}