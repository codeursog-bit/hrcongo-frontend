'use client';
import PresenceSubNav from '@/components/PresenceSubNav';
import { AttendanceSelect } from '@/components/attendance/AttendanceSelect';

// ============================================================================
// 📁 app/(dashboard)/presences/shifts/page.tsx
// ============================================================================

import { AttendanceModuleFrame } from '@/components/attendance/AttendanceModuleFrame';
import { AttendanceDialog } from '@/components/attendance/AttendanceDialog';
import React, { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  Moon, Sun, Clock, Plus, Edit2, Trash2, Users,
  ArrowLeft, Loader2, Check, X, AlertCircle, Calendar,
  Search, RefreshCw, AlertTriangle, Eye,
  Download, Building2, Sunset, Info, UserCheck, UserX, Repeat, Stethoscope, Factory, ShieldCheck,
} from 'lucide-react';
import { api } from '@/services/api';
import { KonzaLoader } from '@/components/ui/KonzaLoader';

// ─── Types ────────────────────────────────────────────────────────────────────
interface WorkShift {
  id: string;
  name: string;
  startHour: number;
  startMinute: number;
  endHour: number;
  endMinute: number;
  durationHours: number;
  crossesMidnight: boolean;
  isNightShift: boolean;
  nightPremiumRate: number;
  color: string;
  isDefault: boolean;
  isActive: boolean;
}

interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  position: string;
  photoUrl?: string;
  department?: { name: string };
}

interface ShiftAssignment {
  id: string;
  employeeId: string;
  shiftId: string;
  specificDate?: string;
  dayOfWeek?: number;
  validFrom?: string;
  validUntil?: string;
  notes?: string;
  shift: WorkShift;
  employee: Employee;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmtHHMM(h: number, m: number) {
  return `${String(h).padStart(2, '0')}h${String(m).padStart(2, '0')}`;
}

function calcDuration(sh: number, sm: number, eh: number, em: number): number {
  const start = sh * 60 + sm;
  let end = eh * 60 + em;
  if (end <= start) end += 24 * 60;
  return parseFloat(((end - start) / 60).toFixed(2));
}

function ShiftIcon({ shift }: { shift: WorkShift }) {
  if (shift.isNightShift || shift.crossesMidnight) return <Moon size={14} />;
  if (shift.startHour < 12) return <Sun size={14} />;
  if (shift.startHour < 18) return <Sunset size={14} />;
  return <Moon size={14} />;
}

const DAY_NAMES_FULL = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
const DAY_NAMES = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
const SHIFT_COLORS = ['#0EA5E9', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'];
const PRESETS = [
  { name: 'Matin', sh: 7, eh: 15, color: '#F59E0B', night: false },
  { name: 'Soir', sh: 15, eh: 23, color: '#8B5CF6', night: false },
  { name: 'Nuit', sh: 23, eh: 7, color: '#0EA5E9', night: true },
  { name: 'Garde', sh: 20, eh: 8, color: '#EF4444', night: true },
];

function ShiftBadge({ shift, small }: { shift: WorkShift; small?: boolean }) {
  const size = small ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-lg font-semibold ${size}`}
      style={{ backgroundColor: 'var(--brand-soft)', color: 'var(--action)' }}
    >
      <ShiftIcon shift={shift} />
      {shift.name}
      <span className="opacity-70">· {fmtHHMM(shift.startHour, shift.startMinute)}–{fmtHHMM(shift.endHour, shift.endMinute)}</span>
    </span>
  );
}

// ─── Modal Shift ──────────────────────────────────────────────────────────────
function ShiftModal({ initial, onSave, onCancel, saving }: {
  initial?: Partial<WorkShift>;
  onSave: (d: any) => void;
  onCancel: () => void;
  saving: boolean;
}) {
  const [name, setName] = useState(initial?.name ?? '');
  const [sh, setSh] = useState(initial?.startHour ?? 8);
  const [sm, setSm] = useState(initial?.startMinute ?? 0);
  const [eh, setEh] = useState(initial?.endHour ?? 16);
  const [em, setEm] = useState(initial?.endMinute ?? 0);
  const [night, setNight] = useState(initial?.isNightShift ?? false);
  const [premium, setPremium] = useState(initial?.nightPremiumRate ?? 0);
  const [color, setColor] = useState(initial?.color ?? '#0EA5E9');
  const [isDefault, setDefault] = useState(initial?.isDefault ?? false);

  const duration = calcDuration(sh, sm, eh, em);
  const crosses = (eh * 60 + em) <= (sh * 60 + sm);

  return (
    <AttendanceDialog title="Shift" onClose={onCancel} busy={saving}>

      <div className="relative w-full sm:max-w-lg bg-[var(--surface)] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden">
        <div className="flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-10 h-1 bg-[var(--border)] rounded-full" />
        </div>
        <div className="px-6 py-4 border-b border-[var(--border)] flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-[var(--text)]">
              {initial?.id ? 'Modifier' : 'Nouveau shift'}
            </h3>
            <p className="text-xs text-[var(--text-muted)] mt-0.5">
              Durée : <strong className="text-[var(--success-text)]">{duration}h</strong>
              {crosses && <span className="ml-1 text-[var(--warning-text)]">(traverse minuit)</span>}
            </p>
          </div>
          <button onClick={onCancel} className="p-2 rounded-xl hover:bg-[var(--surface-2)]" aria-label="Fermer">
            <X size={18} className="text-[var(--text-muted)]" />
          </button>
        </div>
        <div className="p-6 max-h-[72vh] overflow-y-auto space-y-5">
          {!initial?.id && (
            <div>
              <p className="text-xs font-semibold text-[var(--text-muted)]  mb-2">Démarrage rapide</p>
              <div className="grid grid-cols-4 gap-2">
                {PRESETS.map(p => (
                  <button key={p.name} onClick={() => { setName(p.name); setSh(p.sh); setSm(0); setEh(p.eh); setEm(0); setNight(p.night); setColor(p.color); }}
                    className="flex flex-col items-center gap-1 p-2.5 rounded-xl border-2 border-[var(--border)] hover:border-[var(--border)] text-xs font-semibold text-[var(--text-muted)] transition-colors"
                    style={{ borderColor: name === p.name ? p.color : undefined }}>
                    <span>{p.night ? <Moon size={16} /> : p.sh < 12 ? <Sun size={16} /> : <Sunset size={16} />}</span>
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
          )}
          <div>
            <label className="block text-sm font-semibold text-[var(--text-muted)] mb-1.5">Nom <span className="text-[var(--danger-text)]">*</span></label>
            <input type="text" value={name} onChange={e => setName(e.target.value)}
              placeholder="Ex : Matin, Nuit, Garde pharmacie..."
              className="w-full px-4 py-2.5 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)] focus:ring-2 focus:ring-[var(--focus)]" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Début', h: sh, m: sm, setH: setSh, setM: setSm },
              { label: 'Fin', h: eh, m: em, setH: setEh, setM: setEm },
            ].map(({ label, h, m, setH, setM }) => (
              <div key={label}>
                <label className="block text-sm font-semibold text-[var(--text-muted)] mb-1.5">{label}</label>
                <div className="flex gap-2 attendance-filters">
                  <AttendanceSelect value={h} onChange={e => setH(+e.target.value)}
                    className="flex-1 px-3 py-2.5 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]">
                    {Array.from({ length: 24 }, (_, i) => <option key={i} value={i}>{String(i).padStart(2, '0')}h</option>)}
                  </AttendanceSelect>
                  <AttendanceSelect value={m} onChange={e => setM(+e.target.value)}
                    className="w-20 px-2 py-2.5 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]">
                    {[0, 15, 30, 45].map(v => <option key={v} value={v}>{String(v).padStart(2, '0')}</option>)}
                  </AttendanceSelect>
                </div>
              </div>
            ))}
          </div>
          <label className="flex items-center gap-3 cursor-pointer">
            <button type="button" onClick={() => setNight(!night)}
              className={`w-11 h-6 rounded-full transition-colors ${night ? 'bg-[var(--brand)]' : 'bg-[var(--border)]'}`}>
              <div className={`w-5 h-5 bg-[var(--surface)] rounded-full shadow transition-transform mt-0.5 ${night ? 'translate-x-5 ml-0.5' : 'translate-x-0.5'}`} />
            </button>
            <div>
              <p className="text-sm font-semibold text-[var(--text)] flex items-center gap-1.5"><Moon size={14} className="text-[var(--success-text)]" /> Shift de nuit</p>
              <p className="text-xs text-[var(--text-muted)]">Ouvre droit à la prime de nuit</p>
            </div>
          </label>
          {night && (
            <div>
              <label className="block text-xs font-semibold text-[var(--text-muted)] mb-1">Prime de nuit (%)</label>
              <input type="number" min={0} max={100} step={5} value={premium} onChange={e => setPremium(+e.target.value)}
                className="w-full px-4 py-2 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]" />
            </div>
          )}
          <label className="flex items-center gap-3 cursor-pointer">
            <button type="button" onClick={() => setDefault(!isDefault)}
              className={`w-11 h-6 rounded-full transition-colors ${isDefault ? 'bg-[var(--brand)]' : 'bg-[var(--border)]'}`}>
              <div className={`w-5 h-5 bg-[var(--surface)] rounded-full shadow transition-transform mt-0.5 ${isDefault ? 'translate-x-5 ml-0.5' : 'translate-x-0.5'}`} />
            </button>
            <div>
              <p className="text-sm font-semibold text-[var(--text)]">Shift par défaut</p>
              <p className="text-xs text-[var(--text-muted)]">Appliqué aux employés sans planning spécifique</p>
            </div>
          </label>
          <div>
            <p className="text-xs font-semibold text-[var(--text-muted)]  mb-2">Couleur</p>
            <div className="flex gap-2 flex-wrap">
              {SHIFT_COLORS.map(c => (
                <button key={c} onClick={() => setColor(c)}
                  className={`w-8 h-8 rounded-xl transition-colors ${color === c ? 'ring-2 ring-offset-2 ring-current scale-110' : 'opacity-60 hover:opacity-100'}`}
                  style={{ backgroundColor: c, color: c }} />
              ))}
            </div>
          </div>
        </div>
        <div className="px-6 py-4 border-t border-[var(--border)] flex gap-3">
          <button onClick={onCancel} className="flex-1 px-4 py-3 bg-[var(--surface-2)] text-[var(--text-muted)] rounded-xl text-sm font-semibold">Annuler</button>
          <button
            onClick={() => onSave({ name: name.trim(), startHour: sh, startMinute: sm, endHour: eh, endMinute: em, isNightShift: night || crosses, nightPremiumRate: premium, color, isDefault, durationHours: duration, crossesMidnight: crosses })}
            disabled={!name.trim() || saving}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-3    disabled:opacity-50 bg-[var(--brand)] text-[var(--on-brand)] rounded-xl text-sm font-semibold shadow-lg ">
            {saving ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
            {initial?.id ? 'Mettre à jour' : 'Créer'}
          </button>
        </div>
      </div>
    </AttendanceDialog>
  );
}

// ─── Modal Assignation ────────────────────────────────────────────────────────
function AssignModal({ shifts, employees, onAssign, onClose, saving }: {
  shifts: WorkShift[];
  employees: Employee[];
  onAssign: (d: any) => void;
  onClose: () => void;
  saving: boolean;
}) {
  const [shiftId, setShiftId] = useState('');
  const [empId, setEmpId] = useState('');
  const [type, setType] = useState<'date' | 'recurring'>('date');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [validFrom, setValidFrom] = useState('');
  const [validUntil, setValidUntil] = useState('');
  const [notes, setNotes] = useState('');
  const [search, setSearch] = useState('');

  const filtered = employees.filter(e =>
    `${e.firstName} ${e.lastName} ${e.department?.name ?? ''}`.toLowerCase().includes(search.toLowerCase())
  );

  const toggleDay = (day: number) => {
    setSelectedDays(prev =>
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  const canSubmit = !!empId && !!shiftId && (
    type === 'date' || (type === 'recurring' && selectedDays.length > 0)
  );

  const handleAssign = () => {
    if (type === 'date') {
      onAssign({ shiftId, employeeId: empId, specificDate: date, notes: notes || undefined });
    } else {
      onAssign({
        shiftId,
        employeeId: empId,
        days: selectedDays,
        validFrom: validFrom || undefined,
        validUntil: validUntil || undefined,
        notes: notes || undefined,
      });
    }
  };

  return (
    <AttendanceDialog title="Planning" onClose={onClose} busy={saving}>

      <div className="relative w-full sm:max-w-lg bg-[var(--surface)] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden">
        <div className="flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-10 h-1 bg-[var(--border)] rounded-full" />
        </div>
        <div className="px-6 py-4 border-b border-[var(--border)] flex items-center justify-between">
          <h3 className="text-lg font-semibold text-[var(--text)]">Assigner un planning</h3>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-[var(--surface-2)]" aria-label="Fermer">
            <X size={18} className="text-[var(--text-muted)]" />
          </button>
        </div>

        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-5">

          {/* Shift */}
          <div>
            <label className="block text-sm font-semibold text-[var(--text-muted)] mb-2">
              Shift <span className="text-[var(--danger-text)]">*</span>
            </label>
            <div className="space-y-1.5">
              {shifts.map(s => (
                <button key={s.id} onClick={() => setShiftId(s.id)}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl border-2 text-left transition-colors ${shiftId === s.id ? 'border-[var(--border)] bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] ' : 'border-[var(--border)] hover:border-[var(--text-muted)]'}`}>
                  <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }} />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-[var(--text)] flex items-center gap-1.5">
                      <ShiftIcon shift={s} />
                      {s.name}
                      {s.isDefault && <span className="ml-1 px-1.5 py-0.5 bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  text-[var(--success-text)]  rounded text-[10px] font-semibold">Défaut</span>}
                    </p>
                    <p className="text-xs text-[var(--text-muted)]">{fmtHHMM(s.startHour, s.startMinute)} → {fmtHHMM(s.endHour, s.endMinute)} · {s.durationHours}h{s.nightPremiumRate > 0 ? ` · +${s.nightPremiumRate}%` : ''}</p>
                  </div>
                  {shiftId === s.id && <Check size={14} className="text-[var(--success-text)] flex-shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* Type */}
          <div>
            <label className="block text-sm font-semibold text-[var(--text-muted)] mb-2">Type</label>
            <div className="flex bg-[var(--surface-2)] rounded-xl p-1 gap-1">
              {(['date', 'recurring'] as const).map(t => (
                <button key={t} onClick={() => setType(t)}
                  className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-colors ${type === t ? 'bg-[var(--surface)] text-[var(--text)] shadow-sm' : 'text-[var(--text-muted)]'}`}>
                  {t === 'date' ? <><Calendar size={16} /> Date précise</> : <><Repeat size={16} /> Récurrent</>}
                </button>
              ))}
            </div>
          </div>

          {/* Contenu selon type */}
          {type === 'date' ? (
            <div>
              <label className="block text-xs font-semibold text-[var(--text-muted)] mb-1.5">Date</label>
              <input type="date" value={date} onChange={e => setDate(e.target.value)}
                className="w-full px-4 py-2.5 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]" />
            </div>
          ) : (
            <div className="space-y-4">
              {/* Jours multi-sélection */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-[var(--text-muted)]">
                    Jours <span className="text-[var(--danger-text)]">*</span>
                  </label>
                  {selectedDays.length > 0 && (
                    <span className="text-[10px] font-semibold text-[var(--success-text)]">
                      {selectedDays.length} jour{selectedDays.length > 1 ? 's' : ''} sélectionné{selectedDays.length > 1 ? 's' : ''}
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-7 gap-1.5">
                  {DAY_NAMES.map((d, i) => {
                    const isSelected = selectedDays.includes(i);
                    return (
                      <button
                        key={i}
                        onClick={() => toggleDay(i)}
                        className={`flex flex-col items-center py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                          isSelected
                            ? 'bg-[var(--brand)] text-[var(--on-brand)] shadow-md  scale-105'
                            : 'bg-[var(--surface-2)] text-[var(--text-muted)] hover:bg-[var(--border)]'
                        }`}
                      >
                        {d}
                        <span className={`w-1 h-1 rounded-full mt-1 ${isSelected ? 'bg-[var(--surface)]' : 'bg-transparent'}`} />
                      </button>
                    );
                  })}
                </div>
                {/* Raccourcis */}
                <div className="flex flex-wrap gap-2 mt-2">
                  {[
                    { label: 'Lun–Ven', days: [1, 2, 3, 4, 5] },
                    { label: 'Lun·Mer·Ven', days: [1, 3, 5] },
                    { label: 'Mar·Jeu', days: [2, 4] },
                    { label: 'Week-end', days: [6, 0] },
                  ].map(({ label, days }) => (
                    <button key={label} onClick={() => setSelectedDays(days)}
                      className="text-[10px] font-semibold px-2.5 py-1 rounded-lg bg-[var(--surface-2)] text-[var(--text-muted)] hover:bg-[var(--border)] transition-colors">
                      {label}
                    </button>
                  ))}
                  {selectedDays.length > 0 && (
                    <button onClick={() => setSelectedDays([])}
                      className="text-[10px] font-semibold px-2.5 py-1 rounded-lg bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  text-[var(--danger-text)] hover:bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] transition-colors ml-auto">
                      Effacer
                    </button>
                  )}
                </div>
              </div>

              {/* Période */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[var(--text-muted)] mb-1">
                    Du <span className="text-[var(--text-muted)] font-normal">(optionnel)</span>
                  </label>
                  <input type="date" value={validFrom} onChange={e => setValidFrom(e.target.value)}
                    className="w-full px-3 py-2 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[var(--text-muted)] mb-1">
                    Au <span className="text-[var(--text-muted)] font-normal">(optionnel)</span>
                  </label>
                  <input type="date" value={validUntil} onChange={e => setValidUntil(e.target.value)}
                    className="w-full px-3 py-2 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]" />
                </div>
              </div>
            </div>
          )}

          {/* Employé */}
          <div>
            <label className="block text-sm font-semibold text-[var(--text-muted)] mb-2">
              Employé <span className="text-[var(--danger-text)]">*</span>
            </label>
            <div className="relative mb-2">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
              <input type="text" placeholder="Rechercher..." value={search} onChange={e => setSearch(e.target.value)}
                className="w-full pl-8 pr-4 py-2 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]" />
            </div>
            <div className="max-h-40 overflow-y-auto space-y-1.5">
              {filtered.length === 0 ? (
                <p className="text-center text-sm text-[var(--text-muted)] py-4">Aucun employé trouvé</p>
              ) : filtered.map(emp => (
                <button key={emp.id} onClick={() => setEmpId(emp.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border-2 text-left transition-colors ${empId === emp.id ? 'border-[var(--border)] bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] ' : 'border-[var(--border)] hover:border-[var(--text-muted)]'}`}>
                  {emp.photoUrl
                    ? <img src={emp.photoUrl} className="w-8 h-8 rounded-lg object-cover" alt="" />
                    : <div className="w-8 h-8 rounded-lg    flex items-center justify-center text-xs font-semibold bg-[var(--brand)] text-[var(--on-brand)]">{emp.firstName[0]}{emp.lastName[0]}</div>
                  }
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-[var(--text)] truncate">{emp.firstName} {emp.lastName}</p>
                    <p className="text-xs text-[var(--text-muted)] truncate">{emp.department?.name}</p>
                  </div>
                  {empId === emp.id && <Check size={14} className="text-[var(--success-text)] flex-shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-[var(--text-muted)] mb-1.5">
              Notes <span className="text-[var(--text-muted)] font-normal">(optionnel)</span>
            </label>
            <input type="text" value={notes} onChange={e => setNotes(e.target.value)}
              placeholder="Ex : Remplacement congé..."
              className="w-full px-4 py-2 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]" />
          </div>
        </div>

        <div className="px-6 py-4 border-t border-[var(--border)] flex gap-3">
          <button onClick={onClose} className="flex-1 px-4 py-3 bg-[var(--surface-2)] text-[var(--text-muted)] rounded-xl text-sm font-semibold">Annuler</button>
          <button
            onClick={handleAssign}
            disabled={!canSubmit || saving}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-3    disabled:opacity-50 bg-[var(--brand)] text-[var(--on-brand)] rounded-xl text-sm font-semibold shadow-lg ">
            {saving ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
            {type === 'recurring' && selectedDays.length > 1 ? `Assigner (${selectedDays.length} jours)` : 'Assigner'}
          </button>
        </div>
      </div>
    </AttendanceDialog>
  );
}

// ─── Vue Employés Shiftés ─────────────────────────────────────────────────────
function EmployeeShiftView({ assignments, employees, shifts, loading }: {
  assignments: ShiftAssignment[];
  employees: Employee[];
  shifts: WorkShift[];
  loading: boolean;
}) {
  const [search, setSearch] = useState('');
  const [filterShift, setFilterShift] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'date' | 'recurring'>('all');
  const [showAll, setShowAll] = useState(false);

  type EmployeeGroup = { employee: Employee; assignments: ShiftAssignment[]; hasShift: boolean; };

  const employeeMap = new Map<string, EmployeeGroup>();

  assignments.forEach(a => {
    if (!employeeMap.has(a.employeeId)) {
      employeeMap.set(a.employeeId, { employee: a.employee, assignments: [], hasShift: true });
    }
    employeeMap.get(a.employeeId)!.assignments.push(a);
  });

  if (showAll) {
    employees.forEach(emp => {
      if (!employeeMap.has(emp.id)) {
        employeeMap.set(emp.id, { employee: emp, assignments: [], hasShift: false });
      }
    });
  }

  const allGroups = Array.from(employeeMap.values());

  const filtered = allGroups.filter(g => {
    const nameMatch = `${g.employee.firstName} ${g.employee.lastName} ${g.employee.department?.name ?? ''}`.toLowerCase().includes(search.toLowerCase());
    const shiftMatch = !filterShift || g.assignments.some(a => a.shiftId === filterShift);
    const typeMatch = filterType === 'all'
      || (filterType === 'date' && g.assignments.some(a => a.specificDate))
      || (filterType === 'recurring' && g.assignments.some(a => a.dayOfWeek !== undefined));
    return nameMatch && shiftMatch && typeMatch;
  }).sort((a, b) => {
    if (a.hasShift && !b.hasShift) return -1;
    if (!a.hasShift && b.hasShift) return 1;
    return `${a.employee.firstName} ${a.employee.lastName}`.localeCompare(`${b.employee.firstName} ${b.employee.lastName}`);
  });

  const assignedCount = new Set(assignments.map(a => a.employeeId)).size;
  const withoutShiftCount = employees.length - assignedCount;

  if (loading) {
    return (
      <KonzaLoader variant="page" />
    );
  }

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 attendance-metrics">
        <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-4 text-center">
          <p className="text-2xl font-semibold text-[var(--text)]">{employees.length}</p>
          <p className="text-xs text-[var(--text-muted)] mt-0.5 flex items-center justify-center gap-1"><Users size={11} />Total</p>
        </div>
        <div className="bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  border border-[var(--border)]  rounded-2xl p-4 text-center">
          <p className="text-2xl font-semibold text-[var(--success-text)] ">{assignedCount}</p>
          <p className="text-xs text-[var(--success-text)]  mt-0.5 flex items-center justify-center gap-1"><UserCheck size={11} />Avec planning</p>
        </div>
        <div className="bg-[var(--surface-2)] border border-[var(--border)] rounded-2xl p-4 text-center">
          <p className="text-2xl font-semibold text-[var(--text-muted)]">{withoutShiftCount}</p>
          <p className="text-xs text-[var(--text-muted)] mt-0.5 flex items-center justify-center gap-1"><UserX size={11} />Horaires globaux</p>
        </div>
      </div>

      {/* Filtres */}
      <div className="flex flex-wrap gap-2 attendance-filters">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
          <input type="text" placeholder="Rechercher un employé..." value={search} onChange={e => setSearch(e.target.value)}
            className="w-full pl-8 pr-4 py-2.5 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm focus:border-[var(--border)]" />
        </div>
        <AttendanceSelect value={filterShift} onChange={e => setFilterShift(e.target.value)}
          className="px-3 py-2.5 border-2 border-[var(--border)] rounded-xl bg-[var(--surface)] text-sm text-[var(--text-muted)] focus:border-[var(--border)]">
          <option value="">Tous les shifts</option>
          {shifts.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </AttendanceSelect>
        <div className="flex bg-[var(--surface-2)] rounded-xl p-1 gap-1">
          {([['all', 'Tous'], ['date', 'Date précise'], ['recurring', 'Récurrent']] as const).map(([val, label]) => (
            <button key={val} onClick={() => setFilterType(val as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${filterType === val ? 'bg-[var(--surface)] text-[var(--text)] shadow-sm' : 'text-[var(--text-muted)]'}`}>
              {label}
            </button>
          ))}
        </div>
        <button onClick={() => setShowAll(v => !v)}
          className={`flex items-center gap-2 px-3 py-2 rounded-xl border-2 text-xs font-semibold transition-colors ${showAll ? 'border-[var(--border)] bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  text-[var(--success-text)] ' : 'border-[var(--border)] text-[var(--text-muted)]'}`}>
          <Eye size={13} />
          {showAll ? 'Shiftés + Globaux' : 'Shiftés seulement'}
        </button>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-12 text-center">
          <Users size={28} className="text-[var(--text-muted)] mx-auto mb-3" />
          <p className="text-sm text-[var(--text-muted)] font-semibold mb-1">
            {assignedCount === 0 ? 'Aucun employé n\'a encore de shift assigné' : 'Aucun résultat'}
          </p>
          {assignedCount === 0 && <p className="text-xs text-[var(--text-muted)]">Cliquez sur "Assigner" pour lier un employé à un planning.</p>}
        </div>
      ) : (
        <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl overflow-hidden">
          <div className="grid grid-cols-[1fr_auto] sm:grid-cols-[2fr_3fr_auto] gap-4 px-5 py-3 bg-[var(--surface-2)]/50 border-b border-[var(--border)]">
            <p className="text-xs font-semibold text-[var(--text-muted)]  ">Employé</p>
            <p className="text-xs font-semibold text-[var(--text-muted)]   hidden sm:block">Planning assigné</p>
            <p className="text-xs font-semibold text-[var(--text-muted)]  ">Statut</p>
          </div>
          <div className="divide-y divide-[var(--border)]">
            {filtered.map(({ employee, assignments: empAssignments, hasShift }) => (
              <div key={employee.id} className="grid grid-cols-[1fr_auto] sm:grid-cols-[2fr_3fr_auto] gap-4 px-5 py-4 items-start hover:bg-[var(--surface-2)]/30 transition-colors">
                <div className="flex items-center gap-3 min-w-0">
                  {employee.photoUrl
                    ? <img src={employee.photoUrl} className="w-9 h-9 rounded-xl object-cover flex-shrink-0" alt="" />
                    : <div className="w-9 h-9 rounded-xl    flex items-center justify-center text-xs font-semibold bg-[var(--brand)] text-[var(--on-brand)] flex-shrink-0">{employee.firstName[0]}{employee.lastName[0]}</div>
                  }
                  <div className="min-w-0">
                    <p className="font-semibold text-sm text-[var(--text)] truncate">{employee.firstName} {employee.lastName}</p>
                    {employee.department?.name && (
                      <p className="text-xs text-[var(--text-muted)] truncate flex items-center gap-1"><Building2 size={10} />{employee.department.name}</p>
                    )}
                    {employee.position && <p className="text-[10px] text-[var(--text-muted)] truncate mt-0.5">{employee.position}</p>}
                  </div>
                </div>
                <div className="hidden sm:flex flex-col gap-1.5 min-w-0">
                  {!hasShift ? (
                    <span className="inline-flex items-center gap-1.5 text-xs text-[var(--text-muted)] italic"><Info size={11} />Horaires officiels de l'entreprise</span>
                  ) : (
                    empAssignments.map(a => (
                      <div key={a.id} className="flex items-center gap-2 flex-wrap">
                        <ShiftBadge shift={a.shift} small />
                        <span className="text-xs text-[var(--text-muted)] flex items-center gap-1">
                          {a.specificDate ? (
                            <><Calendar size={10} />{new Date(a.specificDate).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}</>
                          ) : a.dayOfWeek !== undefined ? (
                            <><Repeat size={10} />{DAY_NAMES_FULL[a.dayOfWeek]}s
                              {(a.validFrom || a.validUntil) && (
                                <span className="text-[var(--text-muted)]">
                                  {a.validFrom ? ` · du ${new Date(a.validFrom).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}` : ''}
                                  {a.validUntil ? ` au ${new Date(a.validUntil).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}` : ''}
                                </span>
                              )}
                            </>
                          ) : null}
                        </span>
                        {a.notes && <span className="text-[10px] text-[var(--text-muted)] italic truncate max-w-[120px]" title={a.notes}> {a.notes}</span>}
                      </div>
                    ))
                  )}
                </div>
                <div className="flex-shrink-0">
                  {hasShift ? (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  text-[var(--success-text)]  rounded-lg text-[10px] font-semibold"><UserCheck size={10} />Shifté</span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-[var(--surface-2)] text-[var(--text-muted)] rounded-lg text-[10px] font-semibold"><Clock size={10} />Global</span>
                  )}
                </div>
              </div>
            ))}
          </div>
          <div className="px-5 py-3 bg-[var(--surface-2)]/50 border-t border-[var(--border)] flex items-center justify-between">
            <p className="text-xs text-[var(--text-muted)]">{assignedCount} avec planning · {withoutShiftCount} horaires globaux</p>
            <button
              onClick={() => {
                const lines = ['Nom,Département,Poste,Shift,Type,Détail'];
                filtered.forEach(({ employee, assignments: empAssignments, hasShift }) => {
                  if (!hasShift) {
                    lines.push(`"${employee.firstName} ${employee.lastName}","${employee.department?.name ?? ''}","${employee.position ?? ''}","Horaires globaux","",""`);
                  } else {
                    empAssignments.forEach(a => {
                      const t = a.specificDate ? 'Date' : 'Récurrent';
                      const detail = a.specificDate ? a.specificDate : a.dayOfWeek !== undefined ? DAY_NAMES_FULL[a.dayOfWeek] : '';
                      lines.push(`"${employee.firstName} ${employee.lastName}","${employee.department?.name ?? ''}","${employee.position ?? ''}","${a.shift.name}","${t}","${detail}"`);
                    });
                  }
                });
                const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url; a.download = `plannings-${new Date().toISOString().split('T')[0]}.csv`; a.click();
                URL.revokeObjectURL(url);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[var(--surface)] border border-[var(--border)] rounded-lg text-xs font-semibold text-[var(--text-muted)] hover:bg-[var(--surface-2)] transition-colors">
              <Download size={12} />Export CSV
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Page principale ──────────────────────────────────────────────────────────
function ShiftsPageContent() {
  const router = useRouter();

  const [shifts, setShifts] = useState<WorkShift[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [assignments, setAssignments] = useState<ShiftAssignment[]>([]);
  const [userRole, setUserRole] = useState('');
  const [loading, setLoading] = useState(true);
  const [assignLoading, setAssignLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'shifts' | 'employees'>('shifts');
  const [shiftModal, setShiftModal] = useState(false);
  const [editingShift, setEditingShift] = useState<WorkShift | null>(null);
  const [assignModal, setAssignModal] = useState(false);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3500);
  };

  const isAdmin = ['ADMIN', 'HR_MANAGER', 'SUPER_ADMIN'].includes(userRole);
  const canAssign = ['ADMIN', 'HR_MANAGER', 'SUPER_ADMIN', 'MANAGER'].includes(userRole);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const userRes: any = await api.get('/auth/me');
      setUserRole(userRes?.role || '');

      let shiftsData: WorkShift[] = [];
      try {
        const sr = await api.get('/attendance/shifts') as any;
        shiftsData = Array.isArray(sr) ? sr : [];
      } catch (e: any) {
        if (e?.response?.status === 404 || e?.message?.includes('WorkShift')) {
          showToast(' Tables shifts non créées. Lancez npx prisma migrate dev.', false);
        }
      }
      setShifts(shiftsData);

      try {
        const empsRes: any = await api.get('/employees?status=ACTIVE&limit=200');
        const empsArray = Array.isArray(empsRes) ? empsRes
          : Array.isArray(empsRes?.employees) ? empsRes.employees
          : Array.isArray(empsRes?.data) ? empsRes.data : [];
        setEmployees(empsArray);
      } catch (e) {
        console.warn('Erreur chargement employés:', e);
      }
    } catch (e: any) {
      setError(e?.message || 'Impossible de charger la page');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchAssignments = useCallback(async () => {
    setAssignLoading(true);
    try {
      const data = await api.get('/attendance/shift-assignments') as any;
      setAssignments(Array.isArray(data) ? data : []);
    } catch (e: any) {
      console.warn('Erreur assignations:', e);
    } finally {
      setAssignLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);
  useEffect(() => { if (activeTab === 'employees') fetchAssignments(); }, [activeTab, fetchAssignments]);

  const handleSaveShift = async (data: any) => {
    setSaving(true);
    try {
      if (editingShift) {
        await api.put(`/attendance/shifts/${editingShift.id}`, data);
        showToast('Shift mis à jour ');
      } else {
        await api.post('/attendance/shifts', data);
        showToast('Shift créé ');
      }
      setShiftModal(false);
      setEditingShift(null);
      fetchData();
    } catch (e: any) {
      showToast(e?.response?.data?.message || e.message || 'Erreur', false);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Désactiver ce shift ?')) return;
    try {
      await api.delete(`/attendance/shifts/${id}`);
      showToast('Shift désactivé');
      fetchData();
    } catch (e: any) {
      showToast(e?.response?.data?.message || e.message || 'Erreur', false);
    }
  };

  const handleAssign = async (data: any) => {
    setSaving(true);
    try {
      if (data.days && data.days.length > 0) {
        // Récurrent multi-jours → 1 POST par jour sélectionné
        await Promise.all(
          data.days.map((dow: number) =>
            api.post('/attendance/shift-assignments', {
              shiftId:    data.shiftId,
              employeeId: data.employeeId,
              dayOfWeek:  dow,
              validFrom:  data.validFrom,
              validUntil: data.validUntil,
              notes:      data.notes,
            })
          )
        );
      } else {
        // Date précise → 1 POST
        await api.post('/attendance/shift-assignments', {
          shiftId:      data.shiftId,
          employeeId:   data.employeeId,
          specificDate: data.specificDate,
          notes:        data.notes,
        });
      }
      showToast('Planning assigné ');
      setAssignModal(false);
      await fetchAssignments();
      setActiveTab('employees');
    } catch (e: any) {
      showToast(e?.response?.data?.message || e.message || 'Erreur', false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="attendance-shifts-workspace space-y-6">
<PresenceSubNav userRole={userRole} />

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3.5 rounded-2xl bg-[var(--brand)] text-[var(--on-brand)] shadow-2xl ${toast.ok ? 'bg-[var(--brand)]' : 'bg-[var(--danger)]'}`}>
          {toast.ok ? <Check size={16} /> : <X size={16} />}
          <span className="font-semibold text-sm">{toast.msg}</span>
        </div>
      )}

      {/* Modals */}
      {(shiftModal || editingShift) && (
        <ShiftModal
          initial={editingShift || undefined}
          onSave={handleSaveShift}
          onCancel={() => { setShiftModal(false); setEditingShift(null); }}
          saving={saving}
        />
      )}
      {assignModal && (
        <AssignModal
          shifts={shifts}
          employees={employees}
          onAssign={handleAssign}
          onClose={() => setAssignModal(false)}
          saving={saving}
        />
      )}

      {/* Header */}
      <div className="flex items-center gap-4 attendance-page-header">
        <button onClick={() => router.back()} className="p-2 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--border)] transition-colors" aria-label="Retour">
          <ArrowLeft size={20} className="text-[var(--text-muted)]" />
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-semibold text-[var(--text)]">Plannings & Shifts</h1>
          <p className="text-sm text-[var(--text-muted)] mt-0.5">Gérez les horaires flexibles — Matin, Soir, Nuit, Garde</p>
        </div>
        <div className="flex items-center gap-2">
          {canAssign && shifts.length > 0 && (
            <button onClick={() => setAssignModal(true)}
              className="k-button k-button-secondary">
              <Plus size={15} />Assigner
            </button>
          )}
          {isAdmin && (
            <button onClick={() => setShiftModal(true)}
              className="k-button k-button-primary">
              <Plus size={15} />Nouveau shift
            </button>
          )}
          <button onClick={fetchData} className="p-2 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--border)] transition-colors" aria-label="Actualiser">
            <RefreshCw size={18} className={`text-[var(--text-muted)] ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Banner info */}
      <div className="bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  border border-[var(--border)]  rounded-2xl p-4 flex items-start gap-3">
        <AlertCircle size={18} className="text-[var(--success-text)] flex-shrink-0 mt-0.5" />
        <p className="text-sm text-[var(--success-text)] ">
          Un shift assigné remplace l'heure officielle globale pour le calcul des retards et heures sup.
          Un employé à <strong>18h</strong> n'est pas en retard à 8h — son planning prime.
        </p>
      </div>

      {error && (
        <div className="bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))]  border border-[var(--border)]  rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle size={18} className="text-[var(--danger-text)] flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-[var(--danger-text)] ">Erreur de chargement</p>
            <p className="text-xs text-[var(--danger-text)]  mt-0.5">{error}</p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex bg-[var(--surface-2)] rounded-2xl p-1.5 gap-1">
        <button onClick={() => setActiveTab('shifts')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-colors ${activeTab === 'shifts' ? 'bg-[var(--surface)] text-[var(--text)] shadow-sm' : 'text-[var(--text-muted)] hover:text-[var(--text)]'}`}>
          <Clock size={15} />Shifts ({shifts.length})
        </button>
        <button onClick={() => setActiveTab('employees')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-colors ${activeTab === 'employees' ? 'bg-[var(--surface)] text-[var(--text)] shadow-sm' : 'text-[var(--text-muted)] hover:text-[var(--text)]'}`}>
          <Users size={15} />Employés & Plannings
          {assignments.length > 0 && (
            <span className="px-1.5 py-0.5 bg-[var(--brand)] text-[var(--on-brand)] text-[10px] font-semibold rounded-full">
              {new Set(assignments.map(a => a.employeeId)).size}
            </span>
          )}
        </button>
      </div>

      {loading ? (
        <KonzaLoader variant="section" />
      ) : activeTab === 'shifts' ? (
        <div className="space-y-6">
          {shifts.length === 0 ? (
            <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-12 text-center">
              <div className="w-16 h-16 bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock size={28} className="text-[var(--success-text)]" />
              </div>
              <p className="font-semibold text-[var(--text)] mb-1">Aucun shift configuré</p>
              <p className="text-sm text-[var(--text-muted)] mb-5">
                {isAdmin ? 'Créez des shifts pour gérer les horaires flexibles.' : "Aucun planning n'a encore été créé."}
              </p>
              {isAdmin && (
                <button onClick={() => setShiftModal(true)}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-[var(--brand)] text-[var(--on-brand)] rounded-xl text-sm font-semibold">
                  <Plus size={15} />Créer le premier shift
                </button>
              )}
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {shifts.map(shift => (
                <div key={shift.id} className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-4 hover:shadow-md transition-colors group">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: shift.color }} />
                      <div>
                        <p className="font-semibold text-[var(--text)] flex items-center gap-1.5 text-sm">
                          <ShiftIcon shift={shift} />{shift.name}
                        </p>
                        {shift.isDefault && (
                          <span className="text-[10px] px-1.5 py-0.5 bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))]  text-[var(--success-text)]  rounded font-semibold">Défaut</span>
                        )}
                      </div>
                    </div>
                    {isAdmin && (
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => setEditingShift(shift)} className="p-1.5 hover:bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] dark:hover:bg-[color-mix(in_srgb,var(--green)_12%,var(--surface))] rounded-lg transition-colors" aria-label="Modifier">
                          <Edit2 size={13} className="text-[var(--success-text)]" />
                        </button>
                        <button onClick={() => handleDelete(shift.id)} className="p-1.5 hover:bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] dark:hover:bg-[color-mix(in_srgb,var(--danger)_10%,var(--surface))] rounded-lg transition-colors" aria-label="Supprimer">
                          <Trash2 size={13} className="text-[var(--danger-text)]" />
                        </button>
                      </div>
                    )}
                  </div>
                  <div className="space-y-1.5 text-xs text-[var(--text-muted)]">
                    <div className="flex items-center justify-between">
                      <span>Horaires</span>
                      <span className="font-mono font-semibold text-[var(--text)]">
                        {fmtHHMM(shift.startHour, shift.startMinute)} → {fmtHHMM(shift.endHour, shift.endMinute)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Durée</span>
                      <span className="font-semibold text-[var(--success-text)] ">{shift.durationHours}h</span>
                    </div>
                    {shift.crossesMidnight && (
                      <div className="flex items-center gap-1 text-[var(--warning-text)] ">
                        <Moon size={11} /><span>Traverse minuit</span>
                      </div>
                    )}
                    {shift.isNightShift && shift.nightPremiumRate > 0 && (
                      <div className="flex items-center justify-between">
                        <span>Prime nuit</span>
                        <span className="font-semibold text-[var(--warning-text)] ">+{shift.nightPremiumRate}%</span>
                      </div>
                    )}
                  </div>
                  {assignments.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-[var(--border)] flex items-center gap-1.5">
                      <Users size={11} className="text-[var(--text-muted)]" />
                      <span className="text-xs text-[var(--text-muted)]">
                        {new Set(assignments.filter(a => a.shiftId === shift.id).map(a => a.employeeId)).size} employé(s)
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {canAssign && shifts.length > 0 && (
            <div className="bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6">
              <h3 className="text-sm font-semibold text-[var(--text-muted)] mb-4 flex items-center gap-2">
                <Info size={15} className="text-[var(--success-text)]" />Cas d'usage
              </h3>
              <div className="grid sm:grid-cols-3 gap-3">
                {[
                  { Icon: Stethoscope, title: 'Pharmacie / Hôpital', desc: 'Garde de nuit contractuelle — heures normales avec prime' },
                  { Icon: Factory, title: 'Usine 3×8', desc: 'Matin / Soir / Nuit en rotation hebdomadaire' },
                  { Icon: ShieldCheck, title: 'Sécurité / Gardiennage', desc: 'Shifts 12h avec prime nuit calculée automatiquement' },
                ].map(uc => (
                  <div key={uc.title} className="p-4 bg-[var(--surface-2)] rounded-xl">
                    <uc.Icon size={20} strokeWidth={1.5} className="mb-3 text-[var(--text-secondary)]" />
                    <p className="text-sm font-semibold text-[var(--text)] mb-1">{uc.title}</p>
                    <p className="text-xs text-[var(--text-muted)]">{uc.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <EmployeeShiftView
          assignments={assignments}
          employees={employees}
          shifts={shifts}
          loading={assignLoading}
        />
      )}
    </div>
  );
}

export default function ShiftsPage() {
  return <AttendanceModuleFrame kind="list"><ShiftsPageContent /></AttendanceModuleFrame>;
}
