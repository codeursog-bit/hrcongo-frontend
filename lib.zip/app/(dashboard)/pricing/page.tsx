'use client';
import { ModulePageFrame, ModulePageSkeleton } from '@/components/requests/ModulePageFrame';
import { Button } from '@/components/design-system/primitives';
import '@/components/requests/service-pages.css';


// ============================================================================
// 💎 PAGE PRICING - MODAL MOBILE MONEY (nouveau flow)
// ============================================================================
// Fichier: app/(dashboard)/pricing/page.tsx

import { useState, useEffect, Suspense } from 'react';
import { useSubscription, usePlans } from '@/hooks/useSubscription';
import { useSearchParams, useRouter } from 'next/navigation';
import { MotekiCheckoutModal } from '@/components/payment/MotekiCheckoutModal';
import { ChariowCheckoutModal } from '@/components/payment/ChariowCheckoutModal';
import { YabetooCheckoutModal, type PaymentIntent } from '@/components/payment/YabetooCheckoutModal';
import { api } from '@/services/api';
import { DiscountCodeField, discountedPrice, type AppliedDiscount } from '@/components/subscription/DiscountCodeField';
import {
  Check, Zap, Gift, Sparkles, AlertTriangle,
  Rocket, Building2, Star, X, Phone, ChevronDown, Loader2, Crown,
} from 'lucide-react';
import { toast } from 'sonner';
import { KonzaLoader } from '@/components/ui/KonzaLoader';

// ============================================================================
// 📝 TYPES
// ============================================================================
const PLAN_LABELS: Record<string, string> = {
  FREE: 'Gratuit', STARTER:'25 employés', BASIC: '50 employés', PRO: '100 employés', ENTERPRISE: 'Plus de 100 employés',
};

// ============================================================================
// 🎯 COMPOSANT PRICING
// ============================================================================
function PricingContent() {
  const searchParams  = useSearchParams();
  const canceled      = searchParams.get('canceled');
  const { subscription } = useSubscription();
  const { plans, isLoading } = usePlans();

  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'yearly'>('monthly');
  const [upgradingPlan, setUpgradingPlan] = useState<string | null>(null);
  const [checkoutTarget, setCheckoutTarget] = useState<{ plan: 'STARTER' | 'BASIC' | 'PRO' | 'ENTERPRISE'; billingPeriod: 'monthly' | 'yearly'; amount: number } | null>(null);

  const router = useRouter();

  // 🔀 Bascule automatique de prestataire — voir GET /subscriptions/payment-provider.
  const [activeProvider, setActiveProvider] = useState<'MOTEKI' | 'CHARIOW' | 'YABETOOPAY' | 'NONE' | null>(null);
  const [paymentIntent,  setPaymentIntent]  = useState<PaymentIntent | null>(null);

  // 🎟️ Code de réduction + 📄 tarif négocié (devis) — uniquement avec YabetoPay
  const [discountInput, setDiscountInput] = useState('');
  const [applied, setApplied] = useState<AppliedDiscount | null>(null);
  const [quote, setQuote] = useState<{ id: string; plan: string; amount: number; months: number; coversPortfolio?: boolean; coveredCompanies?: string[] } | null>(null);

  useEffect(() => {
    api.get<{ quote: any }>('/subscriptions/quote')
      .then((r) => setQuote(r.quote))
      .catch(() => {});
  }, []);

  useEffect(() => {
    api.get<{ provider: 'MOTEKI' | 'CHARIOW' | 'YABETOOPAY' | 'NONE' }>('/subscriptions/payment-provider')
      .then((r) => setActiveProvider(r.provider))
      .catch(() => setActiveProvider('NONE')); // repli prudent si l'appel échoue — jamais planter
  }, []);

  // Moteki et Chariow initient ET déclenchent le paiement en un seul appel
  // (fait par leur modal respectif — checkoutTarget sert aux deux, le
  // rendu choisit le bon composant selon activeProvider). YabetooPay a
  // besoin d'un PaymentIntent créé d'abord via /subscriptions/upgrade
  // (flux original en 2 étapes, inchangé) avant d'ouvrir son propre modal.
  // NONE = aucun prestataire configuré côté serveur, on ne tente rien.
  const handleUpgrade = async (plan: 'STARTER' | 'BASIC' | 'PRO' | 'ENTERPRISE') => {
    const planData = plans?.[plan];
    const amount = billingPeriod === 'yearly' ? planData?.priceYearly : planData?.priceMonthly;
    if (!amount) {
      toast.error("Impossible de déterminer le tarif de ce plan, réessayez.");
      return;
    }

    if (activeProvider === 'NONE') {
      toast.error('Le paiement en ligne est momentanément indisponible. Contactez le support.');
      return;
    }

    if (activeProvider === 'YABETOOPAY') {
      setUpgradingPlan(plan);
      try {
        const data = await api.post<PaymentIntent>('/subscriptions/upgrade', {
          plan,
          billingPeriod,
          // code « Appliqué » en priorité, sinon ce qui est tapé (le serveur le vérifie et renvoie une erreur claire)
          discountCode: applied?.code ?? (discountInput.trim() || undefined),
        });
        setPaymentIntent(data);
      } catch (error: any) {
        toast.error(error.message || "Erreur lors de l'initialisation du paiement");
      } finally {
        setUpgradingPlan(null);
      }
      return;
    }

    setCheckoutTarget({ plan, billingPeriod, amount });
  };

  // Paiement au tarif négocié (devis enregistré par le super admin)
  const handlePayQuote = async () => {
    if (activeProvider !== 'YABETOOPAY') {
      toast.error("Le paiement sur devis n'est pas disponible avec ce moyen de paiement.");
      return;
    }
    try {
      const data = await api.post<PaymentIntent>('/subscriptions/upgrade', { useQuote: true });
      setPaymentIntent(data);
    } catch (error: any) {
      toast.error(error.message || "Erreur lors de l'initialisation du paiement");
    }
  };

  if (isLoading) {
    return (
      <ModulePageSkeleton label="Chargement de l’abonnement" />
    );
  }

  const planOrder   = ['FREE', 'STARTER', 'BASIC', 'PRO', 'ENTERPRISE'];
  const sortedPlans = Object.entries(plans || {}).filter(([key]) => key !== 'FREE')
    .sort(([a], [b]) => planOrder.indexOf(a) - planOrder.indexOf(b));

  const getPlanIcon = (planKey: string) => {
    switch (planKey) {
      case 'FREE':       return <Star      className="w-5 h-5 text-slate-400" />;
      case 'BASIC':      return <Rocket    className="w-5 h-5 text-blue-400" />;
      case 'PRO':        return <Zap       className="w-5 h-5 text-purple-400" />;
      case 'ENTERPRISE': return <Building2 className="w-5 h-5 text-pink-400" />;
      default:           return <Star      className="w-5 h-5 text-slate-400" />;
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Fond Aurora */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-0 -left-40 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 -right-40 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl animate-pulse" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">

        {/* Alerte annulation */}
        {canceled && (
          <div className="mb-8 bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-400 p-6 rounded-lg flex items-start gap-4">
            <AlertTriangle className="w-6 h-6 text-yellow-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-lg font-semibold text-yellow-800 dark:text-yellow-400 mb-1">Paiement annulé</h3>
              <p className="text-sm text-yellow-700 dark:text-yellow-300">
                Aucune somme n'a été prélevée. Vous pouvez réessayer ci-dessous.
              </p>
            </div>
          </div>
        )}

        {/* Plan FREE actuel si retour au gratuit */}
        {subscription?.plan === 'FREE' && (
          <div className="mb-8 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 p-5 rounded-xl flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-slate-200 dark:bg-slate-700 flex items-center justify-center shrink-0">
              <Star className="w-5 h-5 text-slate-500" />
            </div>
            <div>
              <p className="font-semibold text-slate-700 dark:text-slate-200 text-sm">
                Vous êtes sur le plan <span className="font-bold">Gratuit</span>
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Choisissez un plan ci-dessous pour débloquer toutes les fonctionnalités.
              </p>
            </div>
          </div>
        )}

        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 glass-card rounded-full mb-6">
            <Gift className="w-5 h-5 text-purple-400" />
            <span className="text-sm font-semibold glow-text">30 jours d'essai PRO gratuit !</span>
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300 bg-clip-text text-transparent">
            Choisissez votre plan
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Paiement Mobile Money direct — MTN, Airtel, Orange. Activation immédiate.
          </p>
        </div>

        {/* Toggle Mensuel / Annuel */}
        <div className="flex justify-center mb-12">
          <div className="glass-card p-1.5 rounded-full inline-flex">
            {(['monthly', 'yearly'] as const).map(period => (
              <Button variant="ghost"
                key={period}
                onClick={() => setBillingPeriod(period)}
                className={`
                  px-6 py-2.5 rounded-full font-semibold text-sm transition-all duration-300 relative
                  ${billingPeriod === period
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'}
                `}
              >
                {period === 'monthly' ? 'Mensuel' : 'Annuel'}
                {period === 'yearly' && (
                  <span className="absolute -top-2 -right-2 px-2 py-0.5 bg-green-500 text-white text-xs font-bold rounded-full">
                    -17%
                  </span>
                )}
              </Button>
            ))}
          </div>
        </div>

        {/* Tarif négocié (devis) — YabetoPay uniquement */}
        {activeProvider === 'YABETOOPAY' && quote && (
          <div className="max-w-xl mx-auto mb-8 glass-card rounded-2xl p-5 flex items-center justify-between gap-4">
            <div>
              <p className="text-sm font-semibold">Votre tarif négocié</p>
              <p className="text-sm text-slate-500">
                {quote.amount.toLocaleString('fr-FR')} FCFA pour {quote.months} mois
              </p>
              {quote.coversPortfolio && (quote.coveredCompanies?.length ?? 0) > 0 && (
                <p className="text-xs text-slate-500 mt-1">
                  Un seul paiement active vos {quote.coveredCompanies!.length} entreprises : {quote.coveredCompanies!.join(', ')}
                </p>
              )}
            </div>
            <Button variant="primary" onClick={handlePayQuote} className="px-4 py-2 rounded-xl bg-purple-600 text-white text-sm">
              Payer
            </Button>
          </div>
        )}

        {/* Code de réduction — YabetoPay uniquement */}
        {activeProvider === 'YABETOOPAY' && (
          <div className="max-w-md mx-auto mb-8">
            <DiscountCodeField
              value={discountInput}
              onChange={setDiscountInput}
              applied={applied}
              onApplied={setApplied}
              billingPeriod={billingPeriod}
            />
          </div>
        )}

        {/* Cartes */}
        {sortedPlans.length === 0 && <div role="status" className="glass-panel rounded-2xl p-8 text-center"><h2 className="font-semibold text-lg">Les offres ne sont pas disponibles pour le moment.</h2><p className="text-sm text-[var(--text-secondary)] mt-2">Réessayez dans un instant pour consulter les tarifs.</p><Button variant="secondary" className="mt-4" onClick={()=>window.location.reload()}>Réessayer</Button></div>}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {sortedPlans.map(([planKey, plan]: [string, any]) => {
            const isCurrentPlan = subscription?.plan === planKey;
            const isPro         = planKey === 'PRO';
            const isFree        = planKey === 'FREE';
            const isConfigured = plan.priceMonthly != null && plan.priceYearly != null;
            const isUpgrading   = upgradingPlan === planKey;
            const monthlyPrice  = billingPeriod === 'yearly'
              ? (isConfigured ? Math.round(plan.priceYearly / 12) : null)
              : plan.priceMonthly;
            const totalPrice    = billingPeriod === 'yearly' ? plan.priceYearly : plan.priceMonthly;

            return (
              <div
                key={planKey}
                className={`
                  relative glass-panel rounded-2xl p-6 transition-all duration-300 hover:scale-105
                  ${isPro ? 'border-2 border-purple-500/50 shadow-2xl shadow-purple-500/20' : ''}
                  ${isCurrentPlan ? 'ring-2 ring-green-500' : ''}
                `}
              >
                {isPro && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-sm font-bold rounded-full shadow-lg flex items-center gap-1.5 whitespace-nowrap">
                    <Sparkles className="w-4 h-4" /> Populaire
                  </div>
                )}
                {isCurrentPlan && (
                  <div className="absolute -top-4 right-4 px-3 py-1 bg-green-500 text-white text-xs font-bold rounded-full whitespace-nowrap">
                    ✓ Plan actuel
                  </div>
                )}

                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-2">
                    {getPlanIcon(planKey)}
                    <h3 className="text-xl font-bold">{plan.name}</h3>
                  </div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{plan.description}</p>
                </div>

                <div className="mb-6">
                  {isFree ? (
                    <div className="text-4xl font-bold">Gratuit</div>
                  ) : !isConfigured ? (
                    <div className="text-lg font-semibold">Tarif non configuré</div>
                  ) : (
                    <>
                      <div className="text-4xl font-bold mb-1">
                        {monthlyPrice.toLocaleString()} <span className="text-lg">FCFA</span>
                      </div>
                      <div className="text-sm text-slate-500">
                        {billingPeriod === 'yearly' ? (
                          <>
                            {totalPrice.toLocaleString()} FCFA / an
                            <span className="ml-2 text-green-500 font-semibold">
                              -{((plan.priceMonthly * 12) - plan.priceYearly).toLocaleString()} FCFA
                            </span>
                          </>
                        ) : '/ mois'}
                      </div>
                      {applied && (
                        <div className="mt-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 px-3 py-2 text-sm">
                          <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                            Avec {applied.code} (−{applied.percentOff} %)
                          </span>
                          <div className="font-bold">
                            <span className="line-through text-slate-400 font-normal mr-2">{totalPrice.toLocaleString('fr-FR')}</span>
                            {discountedPrice(totalPrice, applied.percentOff).toLocaleString('fr-FR')} FCFA à payer
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>

                <Button variant="ghost"
                  onClick={() => !isFree && handleUpgrade(planKey as 'STARTER' | 'BASIC' | 'PRO' | 'ENTERPRISE')}
                  disabled={isFree || isUpgrading || !isConfigured}
                  className={`
                    w-full py-3 px-6 rounded-lg font-bold text-sm mb-6
                    transition-all duration-300 flex items-center justify-center gap-2
                    ${isFree
                      ? 'bg-slate-200 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                      : isCurrentPlan
                        ? 'bg-green-500 text-white cursor-not-allowed'
                        : isUpgrading
                          ? 'bg-purple-400 text-white cursor-not-allowed'
                          : isPro
                            ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:shadow-lg hover:scale-105'
                            : 'bg-gradient-to-r from-blue-500 to-sky-500 text-white hover:shadow-lg hover:scale-105'
                    }
                  `}
                >
                  {isFree ? (
                    <><Star className="w-4 h-4" /> Plan gratuit</>
                  ) : isCurrentPlan ? (
                    <><Check className="w-4 h-4" /> Renouveler</>
                  ) : isUpgrading ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Préparation…</>
                  ) : (
                    <><Rocket className="w-4 h-4" /> Choisir ce plan</>
                  )}
                </Button>

                <div className="space-y-2">
                  <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-2">Inclus :</p>
                  <div className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                    <span>
                      {plan.limits.maxEmployees === -1 ? 'Employés illimités' : `${plan.limits.maxEmployees} employés max`}
                    </span>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                    <span>
                      {plan.limits.maxUsers === -1 ? 'Administrateurs illimités' : `${plan.limits.maxUsers} administrateur${plan.limits.maxUsers > 1 ? 's' : ''}`}
                    </span>
                  </div>
                  <div className="border-t border-slate-200 dark:border-slate-700 pt-2 mt-2 space-y-2">
                    <p className="text-xs text-[var(--text-secondary)]">{plan.limits.maxLoansAdvances} prêts/avances · {plan.limits.maxPermissionTickets} tickets · {plan.limits.maxAbsenceRequests} absences par mois</p>
                    {plan.limits.hasCNSSDeclaration&&<p className="text-sm">Déclarations CNSS</p>}
                    {plan.limits.hasDASDeclaration&&<p className="text-sm">Déclarations DAS</p>}
                    {plan.limits.hasAnnualPayroll&&<p className="text-sm">Bulletins annuels</p>}
                    {plan.limits.hasEmployeeImportExcel && (
                      <div className="flex items-start gap-2 text-sm">
                        <Check className="w-4 h-4 text-green-500 mt-0.5 shrink-0" /><span>Import Excel</span>
                      </div>
                    )}
                    {plan.limits.hasLeaveManagement && (
                      <div className="flex items-start gap-2 text-sm">
                        <Check className="w-4 h-4 text-green-500 mt-0.5 shrink-0" /><span>Gestion congés</span>
                      </div>
                    )}
                    {plan.limits.hasAttendanceGPS && (
                      <div className="flex items-start gap-2 text-sm">
                        <Check className="w-4 h-4 text-green-500 mt-0.5 shrink-0" /><span>Pointage GPS</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQ */}
        <div className="mt-20 glass-panel p-8 rounded-2xl">
          <h2 className="text-2xl font-bold mb-6 text-center">Questions fréquentes</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-bold mb-2 flex items-center gap-2">
                <Gift className="w-5 h-5 text-purple-400" /> Comment fonctionne l'essai gratuit ?
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                30 jours d'essai PRO gratuit à l'inscription. Aucune carte bancaire requise.
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-2 flex items-center gap-2">
                <Zap className="w-5 h-5 text-blue-400" /> Moyens de paiement ?
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Mobile Money direct depuis l'app : MTN, Airtel, Orange via Moteki.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Modal paiement — Moteki */}
      {checkoutTarget && activeProvider === 'MOTEKI' && (
        <div className="loan-document-protected"><MotekiCheckoutModal
          plan={checkoutTarget.plan}
          billingPeriod={checkoutTarget.billingPeriod}
          amount={checkoutTarget.amount}
          planLabel={PLAN_LABELS[checkoutTarget.plan] ?? checkoutTarget.plan}
          onClose={() => setCheckoutTarget(null)}
          onError={(msg) => toast.error(msg)}
          onSuccess={() => router.push(`/success?plan=${checkoutTarget.plan}&immediate=true`)}
        /></div>
      )}

      {/* Modal paiement — Chariow (redondance de Moteki) */}
      {checkoutTarget && activeProvider === 'CHARIOW' && (
        <div className="loan-document-protected"><ChariowCheckoutModal
          plan={checkoutTarget.plan}
          billingPeriod={checkoutTarget.billingPeriod}
          amount={checkoutTarget.amount}
          planLabel={PLAN_LABELS[checkoutTarget.plan] ?? checkoutTarget.plan}
          onClose={() => setCheckoutTarget(null)}
          onError={(msg) => toast.error(msg)}
        /></div>
      )}

      {/* Modal paiement — YabetooPay (filet de secours, code original intact) */}
      {paymentIntent && (
        <div className="loan-document-protected"><YabetooCheckoutModal
          intent={paymentIntent}
          planLabel={PLAN_LABELS[paymentIntent.plan] ?? paymentIntent.plan}
          onClose={() => setPaymentIntent(null)}
          onSuccess={() => {
            toast.success('Paiement envoyé ! Votre abonnement sera activé après confirmation.');
          }}
          onError={(msg) => toast.error(msg)}
        /></div>
      )}
    </div>
  );
}

export default function PricingPage() {
  return (
    <ModulePageFrame kind="list"><div className="service-module-page" data-service="pricing"><Suspense fallback={
      <ModulePageSkeleton label="Chargement de l’abonnement" />
    }>
      <PricingContent />
    </Suspense></div></ModulePageFrame>
  );
}
