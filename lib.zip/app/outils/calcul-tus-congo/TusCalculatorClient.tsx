'use client';
import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import { Navbar } from '@/components/landing/Navbar';
import { Footer } from '@/components/landing/Footer';

const TAUX_DGI  = 0.02025;
const TAUX_CNSS = 0.05475;
const fmt = (v: number) => Math.round(v).toLocaleString('fr-FR');

export default function TusCalculatorClient() {
  const [gross, setGross] = useState('');
  const res = useMemo(() => {
    const g = Number(gross);
    if (!g || g < 1) return null;
    return {
      g,
      dgi:  Math.round(g * TAUX_DGI),
      cnss: Math.round(g * TAUX_CNSS),
      total: Math.round(g * (TAUX_DGI + TAUX_CNSS)),
    };
  }, [gross]);

  return (
    <div className="min-h-screen bg-[#050607]">
      <Navbar />
      <div className="bg-gradient-to-br from-[#0c0c0d] to-[#1a110c] text-white">
        <div className="max-w-4xl mx-auto px-4 pt-20 pb-10">
          <nav className="flex items-center gap-2 text-xs text-[#6f6f6f] mb-6">
            <Link href="/" className="hover:text-[#d6d6d6]">Accueil</Link><span>›</span>
            <Link href="/outils" className="hover:text-[#d6d6d6]">Outils RH</Link><span>›</span>
            <span className="text-[#d6d6d6]">Calcul TUS Congo</span>
          </nav>
          <span className="inline-block px-3 py-1 bg-[#FF9A62]/10 border border-[#FF9A62]/20 rounded-full text-xs text-[#FF9A62] mb-4">
            TUS — Taxe Unique sur les Salaires
          </span>
          <h1 className="text-3xl md:text-4xl font-black tracking-tight mb-3">
            Calcul TUS Congo-Brazzaville<br />
            <span className="text-[#FF9A62]">7,5% sur le salaire brut</span>
          </h1>
          <p className="text-[#9a9a9a] text-sm max-w-xl">
            Le TUS, c'est une taxe que <strong className="text-white">seul l'employeur paie</strong>.
            Le salarié ne la voit même pas sur son bulletin. On vous explique comment elle fonctionne.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-10 space-y-10">

        {/* Explication */}
        <section className="rounded-2xl border p-6 bg-[#161616] border-[#2a2a2a]">
          <h2 className="font-black text-lg mb-3 text-white">Le TUS en 3 phrases simples</h2>
          <div className="space-y-3">
            {[
              { n: '1', t: 'C\'est une taxe patronale', d: 'Seul l\'employeur la paie. Le salarié ne la voit pas sur son bulletin.' },
              { n: '2', t: '7,5% du salaire brut total', d: 'Sans plafond. Sur 500 000 FCFA de brut → 37 500 FCFA de TUS.' },
              { n: '3', t: 'Versée en deux endroits', d: '2,025% vont à la DGI (via eTax), 5,475% vont à la CNSS (même bordereau que les cotisations CNSS).' },
            ].map(s => (
              <div key={s.n} className="flex items-start gap-4 p-4 rounded-xl border bg-[#FF9A62]/15 border-[#FF9A62]">
                <span className="w-7 h-7 rounded-full bg-[#B85A32] text-white font-black text-sm flex items-center justify-center shrink-0">{s.n}</span>
                <div>
                  <p className="font-bold text-sm text-[#FF9A62]">{s.t}</p>
                  <p className="text-xs text-[#6f6f6f] mt-0.5">{s.d}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Calculateur */}
        <div className="grid md:grid-cols-2 gap-6 items-start">
          <div className="rounded-2xl border p-6 bg-[#161616] border-[#2a2a2a]">
            <h2 className="font-black text-base mb-2 text-white">Calculez le TUS</h2>
            <p className="text-xs text-[#9a9a9a] mb-4">Entrez le salaire brut mensuel total (masse salariale).</p>
            <label className="block text-[11px] font-bold text-[#9a9a9a] uppercase tracking-wider mb-1.5">Salaire brut (FCFA)</label>
            <input type="number" value={gross} onChange={e => setGross(e.target.value)} placeholder="Ex : 500 000"
              className="w-full px-4 py-3 border-2 rounded-xl text-lg font-black font-mono outline-none focus:border-[#FF9A62] transition-colors border-[#3a3a3a] bg-[#2a2a2a]" />
            <p className="text-[10px] text-[#9a9a9a] mt-2">Pas de plafond — le TUS s'applique sur l'intégralité du brut</p>
          </div>

          {!res ? (
            <div className="border border-dashed rounded-2xl p-12 text-center bg-[#161616]/50 border-[#2a2a2a]">
              <p className="text-3xl mb-3"></p>
              <p className="text-sm text-[#9a9a9a]">Entrez un salaire pour calculer</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="rounded-2xl border overflow-hidden bg-[#161616] border-[#FF9A62]">
                <div className="px-4 py-3 border-b bg-[#FF9A62]/15 border-[#FF9A62]">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[#FF9A62]">TUS sur {fmt(res.g)} FCFA</p>
                  <p className="text-[10px] text-[#9a9a9a]">100% charge employeur</p>
                </div>
                <div className="p-4 space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-[#2a2a2a]">
                    <div>
                      <p className="text-sm font-bold text-[#e5e5e5]">Part DGI (2,025%)</p>
                      <p className="text-[10px] text-[#9a9a9a]">Versé via eTax Congo avant le 15</p>
                    </div>
                    <span className="font-black font-mono text-[#FF9A62]">{fmt(res.dgi)} FCFA</span>
                  </div>
                  <div className="flex justify-between items-center py-2">
                    <div>
                      <p className="text-sm font-bold text-[#e5e5e5]">Part CNSS (5,475%)</p>
                      <p className="text-[10px] text-[#9a9a9a]">Inclus dans le bordereau CNSS mensuel</p>
                    </div>
                    <span className="font-black font-mono text-[#FF9A62]">{fmt(res.cnss)} FCFA</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t -mx-4 px-4 py-3 border-[#FF9A62] bg-[#FF9A62]/15">
                    <span className="text-sm font-bold text-[#FF9A62]">Total TUS mensuel</span>
                    <span className="font-black font-mono text-lg text-[#FF9A62]">{fmt(res.total)} FCFA</span>
                  </div>
                </div>
              </div>
              <Link href="/simulateur"
                className="flex items-center justify-between p-4 bg-[#FAFAFA] text-black rounded-2xl hover:bg-white transition-colors group">
                <div>
                  <p className="font-black text-sm">Calculer le coût employeur total</p>
                  <p className="text-xs text-[#3a3a3a]">TUS + CNSS + CAMU tout inclus</p>
                </div>
                <span className="text-xl group-hover:translate-x-1 transition-transform">→</span>
              </Link>
            </div>
          )}
        </div>

        {/* FAQ */}
        <section>
          <h2 className="text-xl font-black mb-4 text-white">Questions fréquentes — TUS Congo</h2>
          <div className="space-y-3">
            {[
              { q: 'Le TUS est-il déductible au Congo ?', a: 'Oui. Le TUS versé est déductible du bénéfice imposable de l\'entreprise au titre des charges d\'exploitation, comme toutes les charges sociales patronales.' },
              { q: 'Que se passe-t-il si on oublie de payer le TUS ?', a: 'Le non-paiement du TUS expose l\'employeur à des pénalités et majorations de la DGI (pour la part DGI) et de la CNSS (pour la part CNSS). Un contrôle fiscal peut entraîner un redressement sur plusieurs années.' },
            ].map(({ q, a }) => (
              <details key={q} className="group border rounded-xl overflow-hidden bg-[#161616] border-[#2a2a2a]">
                <summary className="flex items-center justify-between px-5 py-4 cursor-pointer font-bold text-sm list-none text-white">
                  {q}<span className="text-[#9a9a9a] text-xs ml-3 group-open:rotate-180 transition-transform inline-block">▼</span>
                </summary>
                <div className="px-5 pb-4 pt-2 text-sm leading-relaxed border-t text-[#9a9a9a] border-[#2a2a2a]">{a}</div>
              </details>
            ))}
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
}