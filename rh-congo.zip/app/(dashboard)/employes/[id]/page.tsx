// 'use client';

// import React, { useState, useEffect } from 'react';
// import Link from 'next/link';
// import { useRouter } from 'next/navigation';
// import { 
//   ArrowLeft, Edit, FileText, Trash2, Clock, Wallet, Calendar, 
//   CheckCircle, Mail, Phone, MapPin, Building2, User, Download, 
//   AlertCircle, Printer, Eye, EyeOff,
//   Briefcase, BadgeCheck, X,
//   Laptop, Plus, Loader2, Shield, Award,
//   BookOpen, Hash, CreditCard, ChevronRight,
//   Gift, TrendingUp, Star
// } from 'lucide-react';
// import { motion, AnimatePresence } from 'framer-motion';
// import { api } from '@/services/api';

// type TabType = 'info' | 'docs' | 'paie' | 'conges' | 'materiel';

// interface EmployeeDetail {
//   id: string;
//   firstName: string;
//   lastName: string;
//   email: string;
//   phone: string;
//   address: string;
//   city: string;
//   placeOfBirth: string;
//   dateOfBirth: string;
//   gender: string;
//   maritalStatus: string;
//   numberOfChildren: number;
//   employeeNumber: string;
//   hireDate: string;
//   contractType: string;
//   position: string;
//   baseSalary: number;
//   department: { name: string };
//   nationalIdNumber: string;
//   cnssNumber: string;
//   photoUrl: string;
//   isSubjectToIrpp: boolean;
//   isSubjectToCnss: boolean;
//   taxExemptionReason: string;
//   professionalCategory: string;
//   echelon: string;
//   paymentMethod: string;
// }

// // ─── Lire le rôle depuis le localStorage ──────────────────────────────────────
// function getRoleFromStorage(): string {
//   try {
//     const raw = localStorage.getItem('user');
//     if (!raw) return 'EMPLOYEE';
//     const u = JSON.parse(raw);
//     return u?.role || 'EMPLOYEE';
//   } catch {
//     return 'EMPLOYEE';
//   }
// }

// export default function EmployeeProfilePage({ params }: { params: { id: string } }) {
//   const router = useRouter();
//   const [activeTab, setActiveTab] = useState<TabType>('info');
//   const [showSalary, setShowSalary] = useState(false);
//   const [employee, setEmployee] = useState<EmployeeDetail | null>(null);
//   const [isLoading, setIsLoading] = useState(true);
//   const [companyConvention, setCompanyConvention] = useState<string | null>(null);

//   // 🆕 Rôle utilisateur pour affichage conditionnel du bouton supprimer
//   const [userRole, setUserRole] = useState('EMPLOYEE');
//   const canDelete = ['SUPER_ADMIN', 'ADMIN'].includes(userRole);

//   // 🆕 États modal de suppression
//   const [showDeleteModal, setShowDeleteModal] = useState(false);
//   const [isDeleting, setIsDeleting] = useState(false);

//   // Tab Data
//   const [tabData, setTabData] = useState<any>(null);
//   const [tabLoading, setTabLoading] = useState(false);

//   useEffect(() => {
//     setUserRole(getRoleFromStorage());
//   }, []);

//   useEffect(() => {
//     const fetchEmployee = async () => {
//       try {
//         const data = await api.get<EmployeeDetail>(`/employees/${params.id}`);
//         setEmployee(data);
//         // Charger convention de l'entreprise
//         try {
//           const company: any = await api.get('/companies/mine');
//           if (company?.collectiveAgreement) setCompanyConvention(company.collectiveAgreement);
//         } catch {}
//       } catch (e) {
//         console.error('Error fetching employee', e);
//       } finally {
//         setIsLoading(false);
//       }
//     };
//     fetchEmployee();
//   }, [params.id]);

//   useEffect(() => {
//     if (!employee || activeTab === 'info') return;
//     const fetchTabData = async () => {
//       setTabLoading(true);
//       setTabData(null);
//       try {
//         let data;
//         if (activeTab === 'docs') data = await api.get(`/documents/employee/${employee.id}`);
//         if (activeTab === 'paie') data = await api.get(`/payrolls?employeeId=${employee.id}`);
//         if (activeTab === 'conges') data = await api.get(`/leaves?employeeId=${employee.id}`);
//         if (activeTab === 'materiel') data = await api.get(`/assets/employee/${employee.id}`);
//         setTabData(data);
//       } catch (e) {
//         console.error(e);
//       } finally {
//         setTabLoading(false);
//       }
//     };
//     fetchTabData();
//   }, [activeTab, employee]);

//   // 🆕 Logique de suppression avec redirection
//   const handleDelete = async () => {
//     if (!employee) return;
//     setIsDeleting(true);
//     try {
//       await api.delete(`/employees/${params.id}`);
//       router.push('/employes');
//     } catch (err: any) {
//       alert(err?.message || 'Erreur lors de la suppression');
//       setIsDeleting(false);
//       setShowDeleteModal(false);
//     }
//   };

//   const getAnciennete = () => {
//     if (!employee?.hireDate) return '';
//     const hire = new Date(employee.hireDate);
//     const now = new Date();
//     const months = Math.floor((now.getTime() - hire.getTime()) / (1000 * 60 * 60 * 24 * 30.44));
//     const years = Math.floor(months / 12);
//     const rem = months % 12;
//     if (years === 0) return `${rem} mois`;
//     return `${years} an${years > 1 ? 's' : ''}${rem > 0 ? ` ${rem} mois` : ''}`;
//   };

//   if (isLoading || !employee) return (
//     <div className="min-h-screen flex items-center justify-center">
//       <Loader2 className="animate-spin text-sky-500" size={32} />
//     </div>
//   );

//   const renderTabContent = () => {
//     if (activeTab === 'info') {
//       return (
//         <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
//           {/* Colonne gauche */}
//           <div className="lg:col-span-2 space-y-8">

//             {/* Informations personnelles */}
//             <section>
//               <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
//                 <User size={20} className="text-sky-500" /> Informations Personnelles
//               </h3>
//               <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-8">
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Nom complet</p>
//                   <p className="font-medium text-gray-900 dark:text-white">{employee.firstName} {employee.lastName}</p>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Date de naissance</p>
//                   <p className="font-medium text-gray-900 dark:text-white">{new Date(employee.dateOfBirth).toLocaleDateString('fr-FR')}</p>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Lieu de naissance</p>
//                   <p className="font-medium text-gray-900 dark:text-white">{employee.placeOfBirth}</p>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Genre</p>
//                   <p className="font-medium text-gray-900 dark:text-white">{employee.gender === 'MALE' ? 'Homme' : 'Femme'}</p>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Phone size={11} /> Téléphone</p>
//                   <p className="font-medium font-mono text-gray-900 dark:text-white">{employee.phone}</p>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Mail size={11} /> Email</p>
//                   <p className="font-medium text-gray-900 dark:text-white truncate">{employee.email}</p>
//                 </div>
//                 <div className="col-span-2">
//                   <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><MapPin size={11} /> Adresse</p>
//                   <p className="font-medium text-gray-900 dark:text-white">{employee.address}{employee.city ? `, ${employee.city}` : ''}</p>
//                 </div>
//                 {(employee.maritalStatus || employee.numberOfChildren >= 0) && (
//                   <>
//                     <div>
//                       <p className="text-xs text-gray-500 mb-1">Situation familiale</p>
//                       <p className="font-medium text-gray-900 dark:text-white">
//                         {employee.maritalStatus === 'SINGLE' ? 'Célibataire' : employee.maritalStatus === 'MARRIED' ? 'Marié(e)' : employee.maritalStatus === 'DIVORCED' ? 'Divorcé(e)' : 'Veuf/Veuve'}
//                       </p>
//                     </div>
//                     <div>
//                       <p className="text-xs text-gray-500 mb-1">Enfants à charge</p>
//                       <p className="font-medium text-gray-900 dark:text-white">{employee.numberOfChildren || 0}</p>
//                     </div>
//                   </>
//                 )}
//               </div>
//             </section>

//             {/* Documents administratifs */}
//             <section>
//               <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
//                 <BookOpen size={20} className="text-indigo-500" /> Documents Administratifs
//               </h3>
//               <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 grid grid-cols-1 md:grid-cols-2 gap-4">
//                 <div className="p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-600">
//                   <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Hash size={11} /> N° CNI / Passeport</p>
//                   <p className="font-semibold font-mono text-gray-900 dark:text-white">{employee.nationalIdNumber || <span className="text-gray-400 italic text-sm font-sans font-normal">Non renseigné</span>}</p>
//                 </div>
//                 <div className="p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-600">
//                   <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Shield size={11} /> N° CNSS</p>
//                   <p className="font-semibold font-mono text-gray-900 dark:text-white">{employee.cnssNumber || <span className="text-gray-400 italic text-sm font-sans font-normal">Non renseigné</span>}</p>
//                 </div>
//               </div>
//             </section>

//             {/* Convention collective + catégorie */}
//             {(companyConvention || employee.professionalCategory) && (
//               <section>
//                 <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
//                   <Award size={20} className="text-purple-500" /> Classification Conventionnelle
//                 </h3>
//                 <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 space-y-3">
//                   {companyConvention && (
//                     <div className="flex items-center justify-between p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl border border-purple-200 dark:border-purple-700">
//                       <div>
//                         <p className="text-xs text-purple-500 mb-0.5">Convention Collective</p>
//                         <p className="font-bold text-purple-900 dark:text-purple-100">{companyConvention}</p>
//                       </div>
//                       <BookOpen size={20} className="text-purple-400" />
//                     </div>
//                   )}
//                   {employee.professionalCategory && (
//                     <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-600">
//                       <div>
//                         <p className="text-xs text-gray-500 mb-0.5">Catégorie Professionnelle</p>
//                         <p className="font-bold font-mono text-gray-900 dark:text-white">{employee.professionalCategory}</p>
//                       </div>
//                       {employee.echelon && (
//                         <div className="text-right">
//                           <p className="text-xs text-gray-500 mb-0.5">Échelon</p>
//                           <p className="font-bold text-sky-600 dark:text-sky-400">{employee.echelon}</p>
//                         </div>
//                       )}
//                     </div>
//                   )}
//                 </div>
//               </section>
//             )}

//             {/* Régime fiscal */}
//             <section>
//               <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
//                 <Shield size={20} className="text-emerald-500" /> Régime Fiscal
//               </h3>
//               <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
//                 <div className="grid grid-cols-2 gap-3 mb-3">
//                   <div className={`p-4 rounded-xl border-2 flex items-center gap-3 ${employee.isSubjectToIrpp ? 'border-sky-400 bg-sky-50 dark:bg-sky-900/20' : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800'}`}>
//                     <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${employee.isSubjectToIrpp ? 'bg-sky-500' : 'bg-gray-300 dark:bg-gray-600'}`}>
//                       <CheckCircle size={16} className="text-white" />
//                     </div>
//                     <div>
//                       <p className="text-xs font-bold text-gray-900 dark:text-white">IRPP / ITS</p>
//                       <p className="text-xs text-gray-500">{employee.isSubjectToIrpp ? 'Soumis' : 'Exempté'}</p>
//                     </div>
//                   </div>
//                   <div className={`p-4 rounded-xl border-2 flex items-center gap-3 ${employee.isSubjectToCnss ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20' : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800'}`}>
//                     <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${employee.isSubjectToCnss ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-600'}`}>
//                       <CheckCircle size={16} className="text-white" />
//                     </div>
//                     <div>
//                       <p className="text-xs font-bold text-gray-900 dark:text-white">CNSS (4%)</p>
//                       <p className="text-xs text-gray-500">{employee.isSubjectToCnss ? 'Soumis' : 'Exempté'}</p>
//                     </div>
//                   </div>
//                 </div>
//                 {employee.taxExemptionReason && (
//                   <div className="p-3 bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-700 rounded-lg">
//                     <p className="text-xs text-amber-700 dark:text-amber-300 flex items-start gap-2">
//                       <AlertCircle size={12} className="mt-0.5 shrink-0" />
//                       <span><strong>Raison d'exemption :</strong> {employee.taxExemptionReason}</span>
//                     </p>
//                   </div>
//                 )}
//               </div>
//             </section>
//           </div>

//           {/* Colonne droite */}
//           <div className="space-y-6">
//             {/* Emploi */}
//             <section>
//               <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
//                 <Briefcase size={20} className="text-purple-500" /> Emploi
//               </h3>
//               <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 space-y-4">
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Date d'embauche</p>
//                   <p className="font-medium text-gray-900 dark:text-white">{new Date(employee.hireDate).toLocaleDateString('fr-FR')}</p>
//                   <p className="text-xs text-sky-600 dark:text-sky-400 mt-0.5">Ancienneté : {getAnciennete()}</p>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Type de contrat</p>
//                   <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-sky-100 dark:bg-sky-900/30 text-sky-700 dark:text-sky-300 text-sm font-bold">
//                     <Briefcase size={12} /> {employee.contractType}
//                   </span>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Poste occupé</p>
//                   <p className="font-medium text-gray-900 dark:text-white">{employee.position}</p>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Département</p>
//                   <p className="font-medium text-gray-900 dark:text-white">{employee.department?.name}</p>
//                 </div>
//                 <div>
//                   <p className="text-xs text-gray-500 mb-1">Mode de paiement</p>
//                   <p className="font-medium text-gray-900 dark:text-white">
//                     {employee.paymentMethod === 'CASH' ? 'Espèces' : employee.paymentMethod === 'BANK_TRANSFER' ? 'Virement bancaire' : 'Mobile Money'}
//                   </p>
//                 </div>
//                 <div className="pt-4 border-t border-gray-200 dark:border-gray-600">
//                   <p className="text-xs text-gray-400 uppercase font-bold mb-1">Salaire de base</p>
//                   <div className="flex items-center justify-between">
//                     <p className="text-xl font-bold text-gray-900 dark:text-white font-mono">
//                       {showSalary ? `${employee.baseSalary.toLocaleString('fr-FR')} FCFA` : '• • • • • • •'}
//                     </p>
//                     <button onClick={() => setShowSalary(!showSalary)} className="text-gray-400 hover:text-sky-500 transition-colors p-1">
//                       {showSalary ? <EyeOff size={18} /> : <Eye size={18} />}
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             </section>

//             {/* Actions rapides */}
//             <section>
//               <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
//                 <Star size={20} className="text-amber-500" /> Actions Rapides
//               </h3>
//               <div className="space-y-2">
//                 <Link href={`/employes/${params.id}/primes`}
//                   className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750/50 border border-gray-100 dark:border-gray-700 rounded-xl hover:border-purple-300 dark:hover:border-purple-600 hover:bg-purple-50 dark:hover:bg-purple-900/10 transition-all group">
//                   <div className="flex items-center gap-3">
//                     <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center">
//                       <Gift size={16} className="text-purple-500" />
//                     </div>
//                     <span className="font-bold text-sm text-gray-900 dark:text-white">Gérer les primes</span>
//                   </div>
//                   <ChevronRight size={16} className="text-gray-400 group-hover:text-purple-500 transition-colors" />
//                 </Link>
//                 <Link href={`/employes/${params.id}/edit`}
//                   className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750/50 border border-gray-100 dark:border-gray-700 rounded-xl hover:border-sky-300 dark:hover:border-sky-600 hover:bg-sky-50 dark:hover:bg-sky-900/10 transition-all group">
//                   <div className="flex items-center gap-3">
//                     <div className="w-8 h-8 bg-sky-100 dark:bg-sky-900/30 rounded-lg flex items-center justify-center">
//                       <Edit size={16} className="text-sky-500" />
//                     </div>
//                     <span className="font-bold text-sm text-gray-900 dark:text-white">Modifier le dossier</span>
//                   </div>
//                   <ChevronRight size={16} className="text-gray-400 group-hover:text-sky-500 transition-colors" />
//                 </Link>
//                 <button onClick={() => setActiveTab('paie')}
//                   className="w-full flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750/50 border border-gray-100 dark:border-gray-700 rounded-xl hover:border-emerald-300 dark:hover:border-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-all group">
//                   <div className="flex items-center gap-3">
//                     <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg flex items-center justify-center">
//                       <TrendingUp size={16} className="text-emerald-500" />
//                     </div>
//                     <span className="font-bold text-sm text-gray-900 dark:text-white">Historique de paie</span>
//                   </div>
//                   <ChevronRight size={16} className="text-gray-400 group-hover:text-emerald-500 transition-colors" />
//                 </button>

//                 {/* 🆕 Bouton Supprimer dans les actions rapides — visible seulement ADMIN/SUPER_ADMIN */}
//                 {canDelete && (
//                   <button
//                     onClick={() => setShowDeleteModal(true)}
//                     className="w-full flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750/50 border border-gray-100 dark:border-gray-700 rounded-xl hover:border-red-300 dark:hover:border-red-700 hover:bg-red-50 dark:hover:bg-red-900/10 transition-all group"
//                   >
//                     <div className="flex items-center gap-3">
//                       <div className="w-8 h-8 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center">
//                         <Trash2 size={16} className="text-red-500" />
//                       </div>
//                       <span className="font-bold text-sm text-red-600 dark:text-red-400">Supprimer l'employé</span>
//                     </div>
//                     <ChevronRight size={16} className="text-gray-400 group-hover:text-red-500 transition-colors" />
//                   </button>
//                 )}
//               </div>
//             </section>
//           </div>
//         </div>
//       );
//     }

//     if (tabLoading) return <div className="py-20 flex justify-center"><Loader2 className="animate-spin text-sky-500" size={32} /></div>;
//     if (!tabData || tabData.length === 0) return (
//       <div className="py-20 text-center">
//         <AlertCircle size={28} className="text-gray-300 dark:text-gray-600 mx-auto mb-3" />
//         <p className="text-gray-400 font-medium">Aucune donnée disponible</p>
//       </div>
//     );

//     if (activeTab === 'docs') {
//       return (
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
//           {tabData.map((doc: any) => (
//             <div key={doc.id} className="p-4 border border-gray-100 dark:border-gray-700 rounded-xl flex items-center gap-3 bg-white dark:bg-gray-800 hover:shadow-md transition-all">
//               <div className="p-3 bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400 rounded-lg"><FileText size={20} /></div>
//               <div className="flex-1 overflow-hidden">
//                 <p className="font-bold truncate text-gray-900 dark:text-white">{doc.name}</p>
//                 <p className="text-xs text-gray-500">{doc.type}</p>
//               </div>
//               <button className="text-gray-400 hover:text-sky-500 transition-colors"><Download size={18} /></button>
//             </div>
//           ))}
//         </div>
//       );
//     }

//     if (activeTab === 'paie') {
//       return (
//         <div className="space-y-3">
//           {tabData.map((p: any) => (
//             <Link href={`/paie/bulletins/${p.id}`} key={p.id}>
//               <div className="flex justify-between items-center p-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-750 hover:border-sky-200 dark:hover:border-sky-800 transition-all cursor-pointer group">
//                 <div className="flex items-center gap-4">
//                   <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-emerald-500 text-white rounded-xl flex flex-col items-center justify-center font-bold text-xs shadow-lg shadow-sky-500/20">
//                     <span className="leading-none">{String(p.month).padStart(2, '0')}</span>
//                     <span className="leading-none opacity-75 text-[10px]">{p.year?.toString().slice(2)}</span>
//                   </div>
//                   <div>
//                     <p className="font-bold text-gray-900 dark:text-white">Bulletin de Paie</p>
//                     <p className="text-xs text-gray-500">Net versé : <strong className="text-emerald-600 dark:text-emerald-400">{p.netSalary?.toLocaleString('fr-FR')} FCFA</strong></p>
//                   </div>
//                 </div>
//                 <div className="flex items-center gap-3">
//                   <span className={`text-xs px-3 py-1 rounded-full font-bold ${p.status === 'PAID' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'}`}>
//                     {p.status === 'PAID' ? 'Payé' : 'En attente'}
//                   </span>
//                   <ChevronRight size={16} className="text-gray-400 group-hover:text-sky-500 transition-colors" />
//                 </div>
//               </div>
//             </Link>
//           ))}
//         </div>
//       );
//     }

//     if (activeTab === 'conges') {
//       return (
//         <div className="space-y-3">
//           {tabData.map((l: any) => (
//             <div key={l.id} className="flex justify-between items-center p-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl">
//               <div className="flex items-center gap-4">
//                 <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${l.type === 'SICK' ? 'bg-red-100 dark:bg-red-900/20 text-red-500' : 'bg-blue-100 dark:bg-blue-900/20 text-blue-500'}`}>
//                   <Calendar size={18} />
//                 </div>
//                 <div>
//                   <p className="font-bold text-gray-900 dark:text-white">
//                     {l.type === 'SICK' ? 'Congé maladie' : l.type === 'ANNUAL' ? 'Congé annuel' : l.type}
//                   </p>
//                   <p className="text-xs text-gray-500">
//                     {new Date(l.startDate).toLocaleDateString('fr-FR')} → {new Date(l.endDate).toLocaleDateString('fr-FR')} · <strong>{l.daysCount}j</strong>
//                   </p>
//                 </div>
//               </div>
//               <span className={`text-xs px-3 py-1 rounded-full font-bold ${l.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : l.status === 'PENDING' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'}`}>
//                 {l.status === 'APPROVED' ? 'Approuvé' : l.status === 'PENDING' ? 'En attente' : 'Refusé'}
//               </span>
//             </div>
//           ))}
//         </div>
//       );
//     }

//     if (activeTab === 'materiel') {
//       return (
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//           {tabData.map((a: any) => (
//             <div key={a.id} className="p-4 border border-gray-100 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 flex items-center gap-4">
//               <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-lg"><Laptop size={20} className="text-gray-500 dark:text-gray-400" /></div>
//               <div>
//                 <p className="font-bold text-gray-900 dark:text-white">{a.name}</p>
//                 <p className="text-xs text-gray-500 font-mono">{a.serialNumber}</p>
//               </div>
//             </div>
//           ))}
//         </div>
//       );
//     }
//   };

//   return (
//     <div className="max-w-7xl mx-auto pb-20 space-y-6">

//       {/* 🆕 MODAL DE SUPPRESSION ── */}
//       <AnimatePresence>
//         {showDeleteModal && (
//           <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
//             {/* Overlay sombre */}
//             <motion.div
//               initial={{ opacity: 0 }}
//               animate={{ opacity: 1 }}
//               exit={{ opacity: 0 }}
//               className="absolute inset-0 bg-black/60 backdrop-blur-sm"
//               onClick={() => !isDeleting && setShowDeleteModal(false)}
//             />

//             {/* Carte de confirmation */}
//             <motion.div
//               initial={{ opacity: 0, scale: 0.92, y: 20 }}
//               animate={{ opacity: 1, scale: 1, y: 0 }}
//               exit={{ opacity: 0, scale: 0.92, y: 20 }}
//               transition={{ type: 'spring', stiffness: 300, damping: 25 }}
//               className="relative bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-2xl max-w-md w-full border-2 border-red-200 dark:border-red-800 z-10 overflow-hidden"
//             >
//               {/* Décoration de fond */}
//               <div className="absolute top-0 right-0 w-40 h-40 bg-red-50 dark:bg-red-900/10 rounded-bl-full -mr-10 -mt-10 pointer-events-none" />

//               {/* Bouton fermer */}
//               {!isDeleting && (
//                 <button
//                   onClick={() => setShowDeleteModal(false)}
//                   className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl transition-colors z-10"
//                 >
//                   <X size={18} />
//                 </button>
//               )}

//               {/* Icône danger */}
//               <div className="relative flex justify-center mb-5">
//                 <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
//                   <div className="w-14 h-14 bg-red-200 dark:bg-red-800/40 rounded-full flex items-center justify-center">
//                     <Trash2 size={26} className="text-red-600 dark:text-red-400" />
//                   </div>
//                 </div>
//               </div>

//               {/* Titre */}
//               <h2 className="text-xl font-bold text-center text-gray-900 dark:text-white mb-1">
//                 Supprimer cet employé ?
//               </h2>
//               <p className="text-center text-gray-500 dark:text-gray-400 text-sm mb-1">
//                 Vous êtes sur le point de désactiver le dossier de
//               </p>
//               <p className="text-center font-extrabold text-gray-900 dark:text-white text-lg mb-5">
//                 {employee.firstName} {employee.lastName}
//               </p>

//               {/* Bloc d'avertissements */}
//               <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700/50 rounded-2xl p-4 mb-6">
//                 <p className="text-red-700 dark:text-red-300 text-sm font-bold flex items-center gap-2 mb-3">
//                   <AlertCircle size={16} className="shrink-0" />
//                   Cette action est irréversible
//                 </p>
//                 <ul className="space-y-2">
//                   <li className="flex items-start gap-2 text-red-600 dark:text-red-400 text-xs">
//                     <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0" />
//                     Le statut de l'employé passera à <strong className="ml-1">TERMINÉ</strong>
//                   </li>
//                   <li className="flex items-start gap-2 text-red-600 dark:text-red-400 text-xs">
//                     <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0" />
//                     Le compte utilisateur associé sera <strong className="ml-1">définitivement supprimé</strong>
//                   </li>
//                   <li className="flex items-start gap-2 text-red-600 dark:text-red-400 text-xs">
//                     <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0" />
//                     L'adresse email sera à nouveau <strong className="ml-1">disponible</strong>
//                   </li>
//                   <li className="flex items-start gap-2 text-emerald-600 dark:text-emerald-400 text-xs">
//                     <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
//                     L'historique de paie et les congés seront <strong className="ml-1">conservés</strong>
//                   </li>
//                 </ul>
//               </div>

//               {/* Boutons d'action */}
//               <div className="flex gap-3">
//                 <button
//                   onClick={() => setShowDeleteModal(false)}
//                   disabled={isDeleting}
//                   className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-bold hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
//                 >
//                   Annuler
//                 </button>
//                 <button
//                   onClick={handleDelete}
//                   disabled={isDeleting}
//                   className="flex-1 px-4 py-3 rounded-xl bg-red-500 hover:bg-red-600 active:bg-red-700 text-white font-bold transition-colors disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-red-500/25"
//                 >
//                   {isDeleting ? (
//                     <>
//                       <Loader2 size={16} className="animate-spin" />
//                       Suppression...
//                     </>
//                   ) : (
//                     <>
//                       <Trash2 size={16} />
//                       Supprimer
//                     </>
//                   )}
//                 </button>
//               </div>
//             </motion.div>
//           </div>
//         )}
//       </AnimatePresence>

//       <Link href="/employes" className="inline-flex items-center text-sm text-gray-500 hover:text-sky-500 transition-colors">
//         <ArrowLeft size={16} className="mr-2" /> Retour à la liste
//       </Link>

//       {/* CARTE HEADER */}
//       <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 md:p-8 shadow-sm border border-gray-100 dark:border-gray-700 relative overflow-hidden">
//         <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-sky-50 to-transparent dark:from-sky-900/10 rounded-bl-full -mr-16 -mt-16 pointer-events-none" />

//         <div className="flex flex-col md:flex-row gap-8 items-start relative z-10">
//           <div className="relative shrink-0">
//             <img
//               src={employee.photoUrl || `https://ui-avatars.com/api/?name=${employee.firstName}+${employee.lastName}&background=0EA5E9&color=fff&size=128`}
//               alt={employee.firstName}
//               className="w-32 h-32 rounded-2xl object-cover shadow-lg border-4 border-white dark:border-gray-700"
//             />
//             <div className="absolute -bottom-2 -right-2 w-7 h-7 bg-emerald-500 rounded-full border-2 border-white dark:border-gray-800 flex items-center justify-center">
//               <CheckCircle size={14} className="text-white" />
//             </div>
//           </div>

//           <div className="flex-1 min-w-0">
//             <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
//               <div>
//                 <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
//                   {employee.firstName} {employee.lastName}
//                 </h1>
//                 <p className="text-lg text-gray-500 dark:text-gray-400 font-medium flex items-center gap-2 flex-wrap mt-1">
//                   <span>{employee.position}</span>
//                   <span className="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600" />
//                   <span className="text-sky-600 dark:text-sky-400">{employee.department?.name}</span>
//                 </p>
//                 <div className="flex flex-wrap gap-2 mt-3">
//                   <span className="px-3 py-1 rounded-lg bg-gray-100 dark:bg-gray-700 text-sm font-mono text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-600">
//                     {employee.employeeNumber}
//                   </span>
//                   <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-gray-50 dark:bg-gray-750 text-sm text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-gray-700">
//                     <Briefcase size={14} /> {employee.contractType}
//                   </span>
//                   {companyConvention && (
//                     <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-50 dark:bg-purple-900/20 text-sm font-bold text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
//                       <BookOpen size={13} /> {companyConvention}
//                     </span>
//                   )}
//                 </div>
//               </div>

//               {/* Boutons d'action dans le header */}
//               <div className="flex items-center gap-2 shrink-0">
//                 <Link href={`/employes/${params.id}/primes`}
//                   className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 hover:bg-purple-100 transition-colors border border-purple-200 dark:border-purple-800"
//                   title="Gérer les primes">
//                   <Gift size={20} />
//                 </Link>
//                 <button onClick={() => router.push(`/employes/${params.id}/edit`)}
//                   className="p-2.5 rounded-xl bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400 hover:bg-sky-100 transition-colors border border-sky-200 dark:border-sky-700"
//                   title="Modifier">
//                   <Edit size={20} />
//                 </button>
//                 {/* 🆕 Bouton supprimer dans le header — visible seulement ADMIN/SUPER_ADMIN */}
//                 {canDelete && (
//                   <button
//                     onClick={() => setShowDeleteModal(true)}
//                     className="p-2.5 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors border border-red-200 dark:border-red-800"
//                     title="Supprimer l'employé"
//                   >
//                     <Trash2 size={20} />
//                   </button>
//                 )}
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* TABS */}
//       <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
//         <div className="flex overflow-x-auto no-scrollbar border-b border-gray-100 dark:border-gray-700">
//           {[
//             { id: 'info', label: 'Informations' },
//             { id: 'docs', label: 'Documents' },
//             { id: 'paie', label: 'Historique Paie' },
//             { id: 'conges', label: 'Congés' },
//             { id: 'materiel', label: 'Matériel' },
//           ].map((tab) => (
//             <button
//               key={tab.id}
//               onClick={() => setActiveTab(tab.id as TabType)}
//               className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-all relative ${
//                 activeTab === tab.id
//                   ? 'text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-900/10'
//                   : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
//               }`}
//             >
//               {tab.label}
//               {activeTab === tab.id && (
//                 <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-sky-500" />
//               )}
//             </button>
//           ))}
//         </div>
//         <div className="p-6 md:p-8 min-h-[400px]">
//           <AnimatePresence mode="wait">
//             <motion.div
//               key={activeTab}
//               initial={{ opacity: 0, y: 10 }}
//               animate={{ opacity: 1, y: 0 }}
//               exit={{ opacity: 0, y: -10 }}
//               transition={{ duration: 0.15 }}
//             >
//               {renderTabContent()}
//             </motion.div>
//           </AnimatePresence>
//         </div>
//       </div>
//     </div>
//   );
// }
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { 
  ArrowLeft, Edit, FileText, Trash2, Clock, Wallet, Calendar, 
  CheckCircle, Mail, Phone, MapPin, Building2, User, Download, 
  AlertCircle, Printer, Eye, EyeOff,
  Briefcase, BadgeCheck, X,
  Laptop, Plus, Loader2, Shield, Award,
  BookOpen, Hash, CreditCard, ChevronRight,
  Gift, TrendingUp, Star, CalendarDays,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { differenceInDays } from 'date-fns';
import { api } from '@/services/api';

type TabType = 'info' | 'docs' | 'paie' | 'conges' | 'materiel';

const TEMP_CONTRACTS = ['CDD', 'STAGE', 'INTERIM', 'CONSULTANT', 'PRESTATAIRE'];
const BNC_CONTRACTS  = ['CONSULTANT', 'PRESTATAIRE'];

interface EmployeeDetail {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  placeOfBirth: string;
  dateOfBirth: string;
  gender: string;
  maritalStatus: string;
  numberOfChildren: number;
  employeeNumber: string;
  hireDate: string;
  contractType: string;
  contractEndDate?: string | null;
  position: string;
  baseSalary: number;
  department: { name: string };
  nationalIdNumber: string;
  cnssNumber: string;
  photoUrl: string;
  isSubjectToIrpp: boolean;
  isSubjectToCnss: boolean;
  taxExemptionReason: string;
  professionalCategory: string;
  echelon: string;
  paymentMethod: string;
  // Période d'essai
  trialPeriodDays?: number | null;
  trialEndDate?: string | null;
  trialConfirmedAt?: string | null;
  trialStatus?: string;
  // BNC
  isResident?: boolean;
  nationality?: string | null;
}

function getRoleFromStorage(): string {
  try {
    const raw = localStorage.getItem('user');
    if (!raw) return 'EMPLOYEE';
    const u = JSON.parse(raw);
    return u?.role || 'EMPLOYEE';
  } catch {
    return 'EMPLOYEE';
  }
}

// 🆕 Composant durée + jours restants pour contrats temporaires
function ContractCountdown({ contractType, hireDate, contractEndDate }: {
  contractType: string;
  hireDate: string;
  contractEndDate?: string | null;
}) {
  if (!TEMP_CONTRACTS.includes(contractType) || !contractEndDate) return null;

  const today    = new Date();
  const endDate  = new Date(contractEndDate);
  const start    = new Date(hireDate);
  const totalDays = differenceInDays(endDate, start);
  const daysLeft  = differenceInDays(endDate, today);
  const isExpired = daysLeft < 0;
  const pctElapsed = Math.min(100, Math.round(((totalDays - Math.max(daysLeft, 0)) / totalDays) * 100));

  const urgencyColor = isExpired
    ? 'text-gray-500'
    : daysLeft <= 7  ? 'text-red-600 dark:text-red-400'
    : daysLeft <= 14 ? 'text-orange-600 dark:text-orange-400'
    : daysLeft <= 30 ? 'text-yellow-600 dark:text-yellow-500'
    : 'text-emerald-600 dark:text-emerald-400';

  const barColor = isExpired
    ? 'bg-gray-400'
    : daysLeft <= 7  ? 'bg-red-500'
    : daysLeft <= 14 ? 'bg-orange-500'
    : daysLeft <= 30 ? 'bg-yellow-500'
    : 'bg-emerald-500';

  const durationLabel = totalDays < 30
    ? `${totalDays}j`
    : totalDays < 365
    ? `${Math.floor(totalDays / 30)} mois`
    : `${Math.floor(totalDays / 365)} an${Math.floor(totalDays / 365) > 1 ? 's' : ''}`;

  return (
    <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600 space-y-3">
      {/* Date de fin */}
      <div>
        <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
          <CalendarDays size={11} /> Date de fin de contrat
        </p>
        <p className={`font-bold ${urgencyColor}`}>
          {endDate.toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}
        </p>
      </div>

      {/* Barre progression */}
      <div>
        <div className="flex justify-between text-xs text-gray-400 mb-1">
          <span>Durée totale : {durationLabel}</span>
          <span>{pctElapsed}% écoulé</span>
        </div>
        <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${barColor}`}
            style={{ width: `${pctElapsed}%` }}
          />
        </div>
      </div>

      {/* Jours restants */}
      {isExpired ? (
        <div className="flex items-center gap-2 p-2 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
          <span className="text-xs font-bold text-gray-500">⚠️ Contrat expiré</span>
        </div>
      ) : (
        <div className={`flex items-center gap-2 p-2.5 rounded-lg ${
          daysLeft <= 7
            ? 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'
            : daysLeft <= 30
            ? 'bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800'
            : 'bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800'
        }`}>
          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${barColor} ${daysLeft <= 7 ? 'animate-pulse' : ''}`} />
          <span className={`text-xs font-bold ${urgencyColor}`}>
            {daysLeft <= 7
              ? `🔴 Expire dans ${daysLeft} jour${daysLeft > 1 ? 's' : ''} !`
              : daysLeft <= 30
              ? `🟠 ${daysLeft} jours restants`
              : `✅ ${daysLeft} jours restants`
            }
          </span>
        </div>
      )}
    </div>
  );
}

export default function EmployeeProfilePage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabType>('info');
  const [showSalary, setShowSalary] = useState(false);
  const [employee, setEmployee] = useState<EmployeeDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [companyConvention, setCompanyConvention] = useState<string | null>(null);

  const [userRole, setUserRole] = useState('EMPLOYEE');
  const canDelete = ['SUPER_ADMIN', 'ADMIN'].includes(userRole);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const [tabData, setTabData] = useState<any>(null);
  const [tabLoading, setTabLoading] = useState(false);

  useEffect(() => {
    setUserRole(getRoleFromStorage());
  }, []);

  useEffect(() => {
    const fetchEmployee = async () => {
      try {
        const data = await api.get<EmployeeDetail>(`/employees/${params.id}`);
        setEmployee(data);
        try {
          const company: any = await api.get('/companies/mine');
          if (company?.collectiveAgreement) setCompanyConvention(company.collectiveAgreement);
        } catch {}
      } catch (e) {
        console.error('Error fetching employee', e);
      } finally {
        setIsLoading(false);
      }
    };
    fetchEmployee();
  }, [params.id]);

  useEffect(() => {
    if (!employee || activeTab === 'info') return;
    const fetchTabData = async () => {
      setTabLoading(true);
      setTabData(null);
      try {
        let data;
        if (activeTab === 'docs')     data = await api.get(`/documents/employee/${employee.id}`);
        if (activeTab === 'paie')     data = await api.get(`/payrolls?employeeId=${employee.id}`);
        if (activeTab === 'conges')   data = await api.get(`/leaves?employeeId=${employee.id}`);
        if (activeTab === 'materiel') data = await api.get(`/assets/employee/${employee.id}`);
        setTabData(data);
      } catch (e) {
        console.error(e);
      } finally {
        setTabLoading(false);
      }
    };
    fetchTabData();
  }, [activeTab, employee]);

  const handleDelete = async () => {
    if (!employee) return;
    setIsDeleting(true);
    try {
      await api.delete(`/employees/${params.id}`);
      router.push('/employes');
    } catch (err: any) {
      alert(err?.message || 'Erreur lors de la suppression');
      setIsDeleting(false);
      setShowDeleteModal(false);
    }
  };

  const getAnciennete = () => {
    if (!employee?.hireDate) return '';
    const hire = new Date(employee.hireDate);
    const now = new Date();
    const months = Math.floor((now.getTime() - hire.getTime()) / (1000 * 60 * 60 * 24 * 30.44));
    const years = Math.floor(months / 12);
    const rem = months % 12;
    if (years === 0) return `${rem} mois`;
    return `${years} an${years > 1 ? 's' : ''}${rem > 0 ? ` ${rem} mois` : ''}`;
  };

  if (isLoading || !employee) return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="animate-spin text-sky-500" size={32} />
    </div>
  );

  const renderTabContent = () => {
    if (activeTab === 'info') {
      return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Colonne gauche */}
          <div className="lg:col-span-2 space-y-8">

            {/* Informations personnelles */}
            <section>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <User size={20} className="text-sky-500" /> Informations Personnelles
              </h3>
              <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-8">
                <div>
                  <p className="text-xs text-gray-500 mb-1">Nom complet</p>
                  <p className="font-medium text-gray-900 dark:text-white">{employee.firstName} {employee.lastName}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Date de naissance</p>
                  <p className="font-medium text-gray-900 dark:text-white">{new Date(employee.dateOfBirth).toLocaleDateString('fr-FR')}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Lieu de naissance</p>
                  <p className="font-medium text-gray-900 dark:text-white">{employee.placeOfBirth}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Genre</p>
                  <p className="font-medium text-gray-900 dark:text-white">{employee.gender === 'MALE' ? 'Homme' : 'Femme'}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Phone size={11} /> Téléphone</p>
                  <p className="font-medium font-mono text-gray-900 dark:text-white">{employee.phone}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Mail size={11} /> Email</p>
                  <p className="font-medium text-gray-900 dark:text-white truncate">{employee.email}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><MapPin size={11} /> Adresse</p>
                  <p className="font-medium text-gray-900 dark:text-white">{employee.address}{employee.city ? `, ${employee.city}` : ''}</p>
                </div>
                {(employee.maritalStatus || employee.numberOfChildren >= 0) && (
                  <>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Situation familiale</p>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {employee.maritalStatus === 'SINGLE' ? 'Célibataire' : employee.maritalStatus === 'MARRIED' ? 'Marié(e)' : employee.maritalStatus === 'DIVORCED' ? 'Divorcé(e)' : 'Veuf/Veuve'}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Enfants à charge</p>
                      <p className="font-medium text-gray-900 dark:text-white">{employee.numberOfChildren || 0}</p>
                    </div>
                  </>
                )}
              </div>
            </section>

            {/* Documents administratifs */}
            <section>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <BookOpen size={20} className="text-indigo-500" /> Documents Administratifs
              </h3>
              <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-600">
                  <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Hash size={11} /> N° CNI / Passeport</p>
                  <p className="font-semibold font-mono text-gray-900 dark:text-white">{employee.nationalIdNumber || <span className="text-gray-400 italic text-sm font-sans font-normal">Non renseigné</span>}</p>
                </div>
                <div className="p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-600">
                  <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Shield size={11} /> N° CNSS</p>
                  <p className="font-semibold font-mono text-gray-900 dark:text-white">{employee.cnssNumber || <span className="text-gray-400 italic text-sm font-sans font-normal">Non renseigné</span>}</p>
                </div>
              </div>
            </section>

            {/* Convention collective */}
            {(companyConvention || employee.professionalCategory) && (
              <section>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                  <Award size={20} className="text-purple-500" /> Classification Conventionnelle
                </h3>
                <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 space-y-3">
                  {companyConvention && (
                    <div className="flex items-center justify-between p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl border border-purple-200 dark:border-purple-700">
                      <div>
                        <p className="text-xs text-purple-500 mb-0.5">Convention Collective</p>
                        <p className="font-bold text-purple-900 dark:text-purple-100">{companyConvention}</p>
                      </div>
                      <BookOpen size={20} className="text-purple-400" />
                    </div>
                  )}
                  {employee.professionalCategory && (
                    <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-600">
                      <div>
                        <p className="text-xs text-gray-500 mb-0.5">Catégorie Professionnelle</p>
                        <p className="font-bold font-mono text-gray-900 dark:text-white">{employee.professionalCategory}</p>
                      </div>
                      {employee.echelon && (
                        <div className="text-right">
                          <p className="text-xs text-gray-500 mb-0.5">Échelon</p>
                          <p className="font-bold text-sky-600 dark:text-sky-400">{employee.echelon}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </section>
            )}

            {/* Régime fiscal */}
            <section>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <Shield size={20} className="text-emerald-500" /> Régime Fiscal
              </h3>
              <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className={`p-4 rounded-xl border-2 flex items-center gap-3 ${employee.isSubjectToIrpp ? 'border-sky-400 bg-sky-50 dark:bg-sky-900/20' : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${employee.isSubjectToIrpp ? 'bg-sky-500' : 'bg-gray-300 dark:bg-gray-600'}`}>
                      <CheckCircle size={16} className="text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-900 dark:text-white">IRPP / ITS</p>
                      <p className="text-xs text-gray-500">{employee.isSubjectToIrpp ? 'Soumis' : 'Exempté'}</p>
                    </div>
                  </div>
                  <div className={`p-4 rounded-xl border-2 flex items-center gap-3 ${employee.isSubjectToCnss ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20' : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${employee.isSubjectToCnss ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-600'}`}>
                      <CheckCircle size={16} className="text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-900 dark:text-white">CNSS (4%)</p>
                      <p className="text-xs text-gray-500">{employee.isSubjectToCnss ? 'Soumis' : 'Exempté'}</p>
                    </div>
                  </div>
                </div>
                {employee.taxExemptionReason && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-700 rounded-lg">
                    <p className="text-xs text-amber-700 dark:text-amber-300 flex items-start gap-2">
                      <AlertCircle size={12} className="mt-0.5 shrink-0" />
                      <span><strong>Raison d'exemption :</strong> {employee.taxExemptionReason}</span>
                    </p>
                  </div>
                )}
              </div>
            </section>
          </div>

          {/* Colonne droite */}
          <div className="space-y-6">
            {/* EMPLOI — 🆕 avec durée contrat */}
            <section>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <Briefcase size={20} className="text-purple-500" /> Emploi
              </h3>
              <div className="bg-gray-50 dark:bg-gray-750/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 space-y-4">
                <div>
                  <p className="text-xs text-gray-500 mb-1">Date d'embauche</p>
                  <p className="font-medium text-gray-900 dark:text-white">{new Date(employee.hireDate).toLocaleDateString('fr-FR')}</p>
                  <p className="text-xs text-sky-600 dark:text-sky-400 mt-0.5">Ancienneté : {getAnciennete()}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Type de contrat</p>
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-sm font-bold ${
                    employee.contractType === 'CDI'         ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300' :
                    employee.contractType === 'CDD'         ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300' :
                    employee.contractType === 'STAGE'       ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300' :
                    employee.contractType === 'CONSULTANT'  ? 'bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300' :
                    employee.contractType === 'PRESTATAIRE' ? 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300' :
                    'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300'
                  }`}>
                    <Briefcase size={12} />
                    {employee.contractType === 'CDI' ? '♾️ CDI' :
                     employee.contractType === 'CDD' ? '📅 CDD' :
                     employee.contractType === 'STAGE' ? '🎓 Stage' :
                     employee.contractType === 'CONSULTANT' ? '💼 Consultant' :
                     employee.contractType === 'PRESTATAIRE' ? '🤝 Prestataire' :
                     employee.contractType === 'INTERIM' ? '🔄 Intérim' :
                     employee.contractType}
                  </span>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Poste occupé</p>
                  <p className="font-medium text-gray-900 dark:text-white">{employee.position}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Département</p>
                  <p className="font-medium text-gray-900 dark:text-white">{employee.department?.name}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Mode de paiement</p>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {employee.paymentMethod === 'CASH' ? 'Espèces' : employee.paymentMethod === 'BANK_TRANSFER' ? 'Virement bancaire' : 'Mobile Money'}
                  </p>
                </div>

                {/* 🆕 Durée contrat pour CDD/STAGE/INTERIM/CONSULTANT */}
                <ContractCountdown
                  contractType={employee.contractType}
                  hireDate={employee.hireDate}
                  contractEndDate={employee.contractEndDate}
                />

                {/* CDI — badge durée indéterminée */}
                {employee.contractType === 'CDI' && (
                  <div className="pt-3 border-t border-gray-200 dark:border-gray-600">
                    <div className="flex items-center gap-2 p-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                      <CheckCircle size={13} className="text-emerald-500" />
                      <span className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold">CDI — Durée indéterminée</span>
                    </div>
                  </div>
                )}

                {/* Période d'essai */}
                {employee.trialPeriodDays && employee.trialPeriodDays > 0 && (
                  <div className="pt-3 border-t border-gray-200 dark:border-gray-600">
                    <p className="text-xs text-gray-500 mb-2 flex items-center gap-1.5">
                      <Clock size={11} /> Période d'essai
                    </p>
                    {employee.trialStatus === 'IN_PROGRESS' && employee.trialEndDate && (
                      <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl border border-indigo-200 dark:border-indigo-700">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-bold text-indigo-700 dark:text-indigo-300">⏱️ Essai en cours</span>
                          <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">
                            {Math.max(0, Math.ceil((new Date(employee.trialEndDate).getTime() - Date.now()) / 86400000))} jours restants
                          </span>
                        </div>
                        <p className="text-xs text-indigo-600 dark:text-indigo-500">
                          Fin le {new Date(employee.trialEndDate).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}
                        </p>
                        <p className="text-xs text-indigo-500 mt-1">Rupture sans préavis ni indemnités possible.</p>
                      </div>
                    )}
                    {employee.trialStatus === 'CONFIRMED' && (
                      <div className="flex items-center gap-2 p-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg border border-emerald-200 dark:border-emerald-700">
                        <CheckCircle size={13} className="text-emerald-500" />
                        <span className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold">
                          Essai confirmé {employee.trialConfirmedAt ? `— le ${new Date(employee.trialConfirmedAt).toLocaleDateString('fr-FR')}` : ''}
                        </span>
                      </div>
                    )}
                    {employee.trialStatus === 'EXPIRED' && (
                      <div className="flex items-center gap-2 p-2 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-700">
                        <AlertCircle size={13} className="text-amber-500" />
                        <span className="text-xs text-amber-700 dark:text-amber-300 font-semibold">
                          Essai expiré — à régulariser (confirmation ou rupture)
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {/* BNC — Consultant / Prestataire */}
                {BNC_CONTRACTS.includes(employee.contractType) && (
                  <div className="pt-3 border-t border-gray-200 dark:border-gray-600">
                    <p className="text-xs text-gray-500 mb-2">Régime fiscal BNC</p>
                    <div className="p-3 bg-teal-50 dark:bg-teal-900/20 rounded-xl border border-teal-200 dark:border-teal-700 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-teal-700 dark:text-teal-400">Résidence</span>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${employee.isResident !== false ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400' : 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-400'}`}>
                          {employee.isResident !== false ? '🇨🇬 Résident' : '🌍 Non-résident'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-teal-700 dark:text-teal-400">Taux BNC</span>
                        <span className="text-xs font-black text-teal-800 dark:text-teal-300">
                          {employee.isResident !== false ? '10%' : '20%'}
                        </span>
                      </div>
                      {employee.nationality && (
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-teal-700 dark:text-teal-400">Nationalité</span>
                          <span className="text-xs font-semibold text-teal-800 dark:text-teal-300">{employee.nationality}</span>
                        </div>
                      )}
                      <p className="text-[11px] text-teal-600 dark:text-teal-500 pt-1">
                        ⚠️ Pas de bulletin — FACTURE HT. BNC reversé DGI avant le 15.
                      </p>
                    </div>
                  </div>
                )}

                {/* INTERIM — info agence */}
                {employee.contractType === 'INTERIM' && (
                  <div className="pt-3 border-t border-gray-200 dark:border-gray-600">
                    <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-xl border border-orange-200 dark:border-orange-700">
                      <p className="text-xs font-bold text-orange-700 dark:text-orange-400 mb-1">🔄 Intérimaire</p>
                      <p className="text-xs text-orange-600 dark:text-orange-500">
                        Salarié de l'agence d'intérim. Aucun bulletin généré côté entreprise. Suivi de mission uniquement.
                      </p>
                    </div>
                  </div>
                )}

                {/* STAGE — info convention */}
                {employee.contractType === 'STAGE' && (
                  <div className="pt-3 border-t border-gray-200 dark:border-gray-600">
                    <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-xl border border-purple-200 dark:border-purple-700">
                      <p className="text-xs font-bold text-purple-700 dark:text-purple-400 mb-1">🎓 Stage</p>
                      <p className="text-xs text-purple-600 dark:text-purple-500">
                        Gratification. CNSS patronale AT 2,25% uniquement. ITS seulement si gratification &gt; SMIG (50 400 FCFA).
                      </p>
                    </div>
                  </div>
                )}

                <div className="pt-4 border-t border-gray-200 dark:border-gray-600">
                  <p className="text-xs text-gray-400 uppercase font-bold mb-1">Salaire de base</p>
                  <div className="flex items-center justify-between">
                    <p className="text-xl font-bold text-gray-900 dark:text-white font-mono">
                      {showSalary ? `${employee.baseSalary?.toLocaleString('fr-FR')} FCFA` : '• • • • • • •'}
                    </p>
                    <button onClick={() => setShowSalary(!showSalary)} className="text-gray-400 hover:text-sky-500 transition-colors p-1">
                      {showSalary ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* Actions rapides */}
            <section>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                <Star size={20} className="text-amber-500" /> Actions Rapides
              </h3>
              <div className="space-y-2">
                <Link href={`/employes/${params.id}/primes`}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750/50 border border-gray-100 dark:border-gray-700 rounded-xl hover:border-purple-300 dark:hover:border-purple-600 hover:bg-purple-50 dark:hover:bg-purple-900/10 transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center">
                      <Gift size={16} className="text-purple-500" />
                    </div>
                    <span className="font-bold text-sm text-gray-900 dark:text-white">Gérer les primes</span>
                  </div>
                  <ChevronRight size={16} className="text-gray-400 group-hover:text-purple-500 transition-colors" />
                </Link>
                <Link href={`/employes/${params.id}/edit`}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750/50 border border-gray-100 dark:border-gray-700 rounded-xl hover:border-sky-300 dark:hover:border-sky-600 hover:bg-sky-50 dark:hover:bg-sky-900/10 transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-sky-100 dark:bg-sky-900/30 rounded-lg flex items-center justify-center">
                      <Edit size={16} className="text-sky-500" />
                    </div>
                    <span className="font-bold text-sm text-gray-900 dark:text-white">Modifier le dossier</span>
                  </div>
                  <ChevronRight size={16} className="text-gray-400 group-hover:text-sky-500 transition-colors" />
                </Link>
                <button onClick={() => setActiveTab('paie')}
                  className="w-full flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750/50 border border-gray-100 dark:border-gray-700 rounded-xl hover:border-emerald-300 dark:hover:border-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg flex items-center justify-center">
                      <TrendingUp size={16} className="text-emerald-500" />
                    </div>
                    <span className="font-bold text-sm text-gray-900 dark:text-white">Historique de paie</span>
                  </div>
                  <ChevronRight size={16} className="text-gray-400 group-hover:text-emerald-500 transition-colors" />
                </button>
                {canDelete && (
                  <button
                    onClick={() => setShowDeleteModal(true)}
                    className="w-full flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-750/50 border border-gray-100 dark:border-gray-700 rounded-xl hover:border-red-300 dark:hover:border-red-700 hover:bg-red-50 dark:hover:bg-red-900/10 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center">
                        <Trash2 size={16} className="text-red-500" />
                      </div>
                      <span className="font-bold text-sm text-red-600 dark:text-red-400">Supprimer l'employé</span>
                    </div>
                    <ChevronRight size={16} className="text-gray-400 group-hover:text-red-500 transition-colors" />
                  </button>
                )}
              </div>
            </section>
          </div>
        </div>
      );
    }

    if (tabLoading) return <div className="py-20 flex justify-center"><Loader2 className="animate-spin text-sky-500" size={32} /></div>;
    if (!tabData || tabData.length === 0) return (
      <div className="py-20 text-center">
        <AlertCircle size={28} className="text-gray-300 dark:text-gray-600 mx-auto mb-3" />
        <p className="text-gray-400 font-medium">Aucune donnée disponible</p>
      </div>
    );

    if (activeTab === 'docs') {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tabData.map((doc: any) => (
            <div key={doc.id} className="p-4 border border-gray-100 dark:border-gray-700 rounded-xl flex items-center gap-3 bg-white dark:bg-gray-800 hover:shadow-md transition-all">
              <div className="p-3 bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400 rounded-lg"><FileText size={20} /></div>
              <div className="flex-1 overflow-hidden">
                <p className="font-bold truncate text-gray-900 dark:text-white">{doc.name}</p>
                <p className="text-xs text-gray-500">{doc.type}</p>
              </div>
              <button className="text-gray-400 hover:text-sky-500 transition-colors"><Download size={18} /></button>
            </div>
          ))}
        </div>
      );
    }

    if (activeTab === 'paie') {
      return (
        <div className="space-y-3">
          {tabData.map((p: any) => (
            <Link href={`/paie/bulletins/${p.id}`} key={p.id}>
              <div className="flex justify-between items-center p-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-750 hover:border-sky-200 dark:hover:border-sky-800 transition-all cursor-pointer group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-emerald-500 text-white rounded-xl flex flex-col items-center justify-center font-bold text-xs shadow-lg shadow-sky-500/20">
                    <span className="leading-none">{String(p.month).padStart(2, '0')}</span>
                    <span className="leading-none opacity-75 text-[10px]">{p.year?.toString().slice(2)}</span>
                  </div>
                  <div>
                    <p className="font-bold text-gray-900 dark:text-white">Bulletin de Paie</p>
                    <p className="text-xs text-gray-500">Net versé : <strong className="text-emerald-600 dark:text-emerald-400">{p.netSalary?.toLocaleString('fr-FR')} FCFA</strong></p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs px-3 py-1 rounded-full font-bold ${p.status === 'PAID' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'}`}>
                    {p.status === 'PAID' ? 'Payé' : 'En attente'}
                  </span>
                  <ChevronRight size={16} className="text-gray-400 group-hover:text-sky-500 transition-colors" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      );
    }

    if (activeTab === 'conges') {
      return (
        <div className="space-y-3">
          {tabData.map((l: any) => (
            <div key={l.id} className="flex justify-between items-center p-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${l.type === 'SICK' ? 'bg-red-100 dark:bg-red-900/20 text-red-500' : 'bg-blue-100 dark:bg-blue-900/20 text-blue-500'}`}>
                  <Calendar size={18} />
                </div>
                <div>
                  <p className="font-bold text-gray-900 dark:text-white">
                    {l.type === 'SICK' ? 'Congé maladie' : l.type === 'ANNUAL' ? 'Congé annuel' : l.type}
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(l.startDate).toLocaleDateString('fr-FR')} → {new Date(l.endDate).toLocaleDateString('fr-FR')} · <strong>{l.daysCount}j</strong>
                  </p>
                </div>
              </div>
              <span className={`text-xs px-3 py-1 rounded-full font-bold ${l.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : l.status === 'PENDING' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'}`}>
                {l.status === 'APPROVED' ? 'Approuvé' : l.status === 'PENDING' ? 'En attente' : 'Refusé'}
              </span>
            </div>
          ))}
        </div>
      );
    }

    if (activeTab === 'materiel') {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tabData.map((a: any) => (
            <div key={a.id} className="p-4 border border-gray-100 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 flex items-center gap-4">
              <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-lg"><Laptop size={20} className="text-gray-500 dark:text-gray-400" /></div>
              <div>
                <p className="font-bold text-gray-900 dark:text-white">{a.name}</p>
                <p className="text-xs text-gray-500 font-mono">{a.serialNumber}</p>
              </div>
            </div>
          ))}
        </div>
      );
    }
  };

  return (
    <div className="max-w-7xl mx-auto pb-20 space-y-6">

      {/* MODAL SUPPRESSION */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => !isDeleting && setShowDeleteModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className="relative bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-2xl max-w-md w-full border-2 border-red-200 dark:border-red-800 z-10 overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-40 h-40 bg-red-50 dark:bg-red-900/10 rounded-bl-full -mr-10 -mt-10 pointer-events-none" />
              {!isDeleting && (
                <button onClick={() => setShowDeleteModal(false)}
                  className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl transition-colors z-10">
                  <X size={18} />
                </button>
              )}
              <div className="relative flex justify-center mb-5">
                <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
                  <div className="w-14 h-14 bg-red-200 dark:bg-red-800/40 rounded-full flex items-center justify-center">
                    <Trash2 size={26} className="text-red-600 dark:text-red-400" />
                  </div>
                </div>
              </div>
              <h2 className="text-xl font-bold text-center text-gray-900 dark:text-white mb-1">Supprimer cet employé ?</h2>
              <p className="text-center text-gray-500 dark:text-gray-400 text-sm mb-1">Vous êtes sur le point de désactiver le dossier de</p>
              <p className="text-center font-extrabold text-gray-900 dark:text-white text-lg mb-5">{employee.firstName} {employee.lastName}</p>
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700/50 rounded-2xl p-4 mb-6">
                <p className="text-red-700 dark:text-red-300 text-sm font-bold flex items-center gap-2 mb-3">
                  <AlertCircle size={16} className="shrink-0" /> Cette action est irréversible
                </p>
                <ul className="space-y-2">
                  {[
                    { text: <>Le statut passera à <strong>TERMINÉ</strong></>, color: 'red' },
                    { text: <>Le compte utilisateur sera <strong>définitivement supprimé</strong></>, color: 'red' },
                    { text: <>L'email sera à nouveau <strong>disponible</strong></>, color: 'red' },
                    { text: <>L'historique de paie et congés seront <strong>conservés</strong></>, color: 'emerald' },
                  ].map((item, i) => (
                    <li key={i} className={`flex items-start gap-2 text-${item.color}-600 dark:text-${item.color}-400 text-xs`}>
                      <span className={`w-1.5 h-1.5 rounded-full bg-${item.color}-400 mt-1.5 shrink-0`} />
                      {item.text}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setShowDeleteModal(false)} disabled={isDeleting}
                  className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-bold hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors disabled:opacity-50">
                  Annuler
                </button>
                <button onClick={handleDelete} disabled={isDeleting}
                  className="flex-1 px-4 py-3 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold transition-colors disabled:opacity-70 flex items-center justify-center gap-2 shadow-lg shadow-red-500/25">
                  {isDeleting ? <><Loader2 size={16} className="animate-spin" />Suppression...</> : <><Trash2 size={16} />Supprimer</>}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <Link href="/employes" className="inline-flex items-center text-sm text-gray-500 hover:text-sky-500 transition-colors">
        <ArrowLeft size={16} className="mr-2" /> Retour à la liste
      </Link>

      {/* HEADER */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 md:p-8 shadow-sm border border-gray-100 dark:border-gray-700 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-sky-50 to-transparent dark:from-sky-900/10 rounded-bl-full -mr-16 -mt-16 pointer-events-none" />
        <div className="flex flex-col md:flex-row gap-8 items-start relative z-10">
          <div className="relative shrink-0">
            <img
              src={employee.photoUrl || `https://ui-avatars.com/api/?name=${employee.firstName}+${employee.lastName}&background=0EA5E9&color=fff&size=128`}
              alt={employee.firstName}
              className="w-32 h-32 rounded-2xl object-cover shadow-lg border-4 border-white dark:border-gray-700"
            />
            <div className="absolute -bottom-2 -right-2 w-7 h-7 bg-emerald-500 rounded-full border-2 border-white dark:border-gray-800 flex items-center justify-center">
              <CheckCircle size={14} className="text-white" />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{employee.firstName} {employee.lastName}</h1>
                <p className="text-lg text-gray-500 dark:text-gray-400 font-medium flex items-center gap-2 flex-wrap mt-1">
                  <span>{employee.position}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600" />
                  <span className="text-sky-600 dark:text-sky-400">{employee.department?.name}</span>
                </p>
                <div className="flex flex-wrap gap-2 mt-3">
                  <span className="px-3 py-1 rounded-lg bg-gray-100 dark:bg-gray-700 text-sm font-mono text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-600">
                    {employee.employeeNumber}
                  </span>
                  <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-gray-50 dark:bg-gray-750 text-sm text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-gray-700">
                    <Briefcase size={14} /> {employee.contractType}
                  </span>
                  {/* 🆕 Badge jours restants dans le header si contrat temporaire */}
                  {TEMP_CONTRACTS.includes(employee.contractType) && employee.contractEndDate && (() => {
                    const daysLeft = differenceInDays(new Date(employee.contractEndDate), new Date());
                    if (daysLeft < 0) return (
                      <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-gray-100 text-gray-500 text-sm font-bold border border-gray-300">
                        ⚠️ Expiré
                      </span>
                    );
                    if (daysLeft <= 30) return (
                      <span className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-sm font-bold border ${
                        daysLeft <= 7
                          ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800'
                          : 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 border-orange-200 dark:border-orange-800'
                      }`}>
                        <CalendarDays size={13} /> J-{daysLeft}
                      </span>
                    );
                    return null;
                  })()}
                  {companyConvention && (
                    <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-50 dark:bg-purple-900/20 text-sm font-bold text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                      <BookOpen size={13} /> {companyConvention}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Link href={`/employes/${params.id}/primes`}
                  className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 hover:bg-purple-100 transition-colors border border-purple-200 dark:border-purple-800"
                  title="Gérer les primes">
                  <Gift size={20} />
                </Link>
                <button onClick={() => router.push(`/employes/${params.id}/edit`)}
                  className="p-2.5 rounded-xl bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400 hover:bg-sky-100 transition-colors border border-sky-200 dark:border-sky-700"
                  title="Modifier">
                  <Edit size={20} />
                </button>
                {canDelete && (
                  <button onClick={() => setShowDeleteModal(true)}
                    className="p-2.5 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors border border-red-200 dark:border-red-800"
                    title="Supprimer l'employé">
                    <Trash2 size={20} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* TABS */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="flex overflow-x-auto no-scrollbar border-b border-gray-100 dark:border-gray-700">
          {[
            { id: 'info',     label: 'Informations' },
            { id: 'docs',     label: 'Documents' },
            { id: 'paie',     label: 'Historique Paie' },
            { id: 'conges',   label: 'Congés' },
            { id: 'materiel', label: 'Matériel' },
          ].map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as TabType)}
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-all relative ${
                activeTab === tab.id
                  ? 'text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-900/10'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              {tab.label}
              {activeTab === tab.id && (
                <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-sky-500" />
              )}
            </button>
          ))}
        </div>
        <div className="p-6 md:p-8 min-h-[400px]">
          <AnimatePresence mode="wait">
            <motion.div key={activeTab}
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}>
              {renderTabContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}