'use client';

// ============================================================================
// 📁 app/(dashboard)/loans/rapport/page.tsx
// ✅ Page "Rapport" — même modèle de tableau de bord que les rapports
//    congés/absences (onglets mois, camemberts, courbe annuelle, top 20),
//    mais pour les prêts/avances/retenues — avec le style et les couleurs de
//    l'app (pas ceux du fichier Excel).
// ============================================================================

import { debtRefDate } from '@/lib/debt-dates';
import React, { useEffect, useMemo, useState } from 'react';
import { Users2, Banknote, PiggyBank, TrendingUp } from 'lucide-react';
import {
  ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend,
} from 'recharts';
import { api } from '@/services/api';
import FinanceSubNav from '@/components/FinanceSubNav';
import { KonzaLoader } from '@/components/ui/KonzaLoader';
import LoansRequestsPanel from '@/components/request-reports/LoansRequestsPanel';

const MONTHS_FR = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
const MONTHS_FULL = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const TYPE_LABEL: Record<string, string> = { ARGENT: 'Prêt argent', MARCHANDISE: 'Marchandise', AUTRE: 'Autre prêt', AVANCE: 'Avance sur salaire' };
// Palette de l'app (sky / emerald / amber / violet / rose) — pas les couleurs du fichier Excel
const TYPE_COLOR: Record<string, string> = { ARGENT: '#0ea5e9', MARCHANDISE: '#8b5cf6', AUTRE: '#f59e0b', AVANCE: '#10b981' };
const DEPT_COLORS = ['#0ea5e9', '#f59e0b', '#8b5cf6', '#10b981', '#ef4444', '#ec4899', '#14b8a6'];
const fmt = (n: number) => Math.round(n).toLocaleString('fr-FR') + ' FCFA';

export default function LoansReportPage() {
  const [loans, setLoans] = useState<any[]>([]);
  const [advances, setAdvances] = useState<any[]>([]);
  const [userRole, setUserRole] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [deptFilterAnnual, setDeptFilterAnnual] = useState('');
  const [top20Mode, setTop20Mode] = useState<'mois' | 'annee'>('mois');

  useEffect(() => {
    try { const stored = localStorage.getItem('user'); if (stored) setUserRole(JSON.parse(stored).role || ''); } catch {}
    (async () => {
      try {
        const [l, a]: any = await Promise.all([api.get('/loans'), api.get('/loans/advances')]);
        setLoans(l || []); setAdvances(a || []);
      } catch (e) { console.error('Erreur chargement rapport', e); }
      finally { setIsLoading(false); }
    })();
  }, []);

  // ── Dettes validées uniquement (prêts actifs/soldés + avances approuvées/déduites/payées) ──
  const allDebts = useMemo(() => {
    const l = loans.filter(x => ['ACTIVE', 'PAID'].includes(x.status)).map(x => ({ ...x, requestType: x.type ?? 'ARGENT' }));
    const a = advances.filter(x => ['APPROVED', 'DEDUCTED', 'PAID'].includes(x.status)).map(x => ({ ...x, requestType: 'AVANCE' }));
    return [...l, ...a];
  }, [loans, advances]);

  // ✅ Un prêt se classe sur sa date de DÉPART voulue (startDate), pas sur
  // createdAt (date de création de l'enregistrement, souvent "aujourd'hui"
  // même si le prêt a été programmé pour un mois différent) — sinon le
  // rapport classait tout nouveau prêt dans le mois réel du jour, jamais
  // dans le mois réellement choisi. Une avance n'a pas de date de départ
  // distincte : createdAt reste la meilleure approximation de son
  // décaissement réel.
  const refDate = (r: any) => debtRefDate(r, r.requestType === 'AVANCE' ? 'advance' : 'loan');

  const availableYears = useMemo(() => {
    const set = new Set<number>([now.getFullYear()]);
    allDebts.forEach(r => set.add(refDate(r).getFullYear()));
    return Array.from(set).sort((a, b) => b - a);
  }, [allDebts, now]);

  const departments = useMemo(() => Array.from(new Set(allDebts.map(r => r.employee?.department?.name).filter(Boolean))).sort(), [allDebts]);

  // ── Données du mois sélectionné ──────────────────────────────────────────
  const monthDebts = useMemo(() => allDebts.filter(r => {
    const d = refDate(r);
    return d.getFullYear() === year && d.getMonth() + 1 === month;
  }), [allDebts, month, year]);

  const employeesConcerned = useMemo(() => new Set(monthDebts.map(r => r.employeeId)).size, [monthDebts]);
  const monthTotal = useMemo(() => monthDebts.reduce((s, r) => s + Number(r.amount), 0), [monthDebts]);

  const byTypeMonth = useMemo(() => {
    const map: Record<string, number> = {};
    monthDebts.forEach(r => { map[r.requestType] = (map[r.requestType] ?? 0) + Number(r.amount); });
    return Object.entries(map).map(([type, montant]) => ({ type, label: TYPE_LABEL[type] ?? type, montant, pct: monthTotal ? Math.round((montant / monthTotal) * 1000) / 10 : 0 }));
  }, [monthDebts, monthTotal]);

  const byDeptMonth = useMemo(() => {
    const map: Record<string, number> = {};
    monthDebts.forEach(r => { const n = r.employee?.department?.name || 'Sans département'; map[n] = (map[n] ?? 0) + Number(r.amount); });
    const sorted = Object.entries(map).sort((a, b) => b[1] - a[1]);
    // ✅ Au-delà de 6 départements, le donut devient illisible (tranches
    // minuscules, étiquettes qui se chevauchent) — on regroupe le reste
    // dans "Autres", comme n'importe quel tableau de bord professionnel.
    const TOP_N = 6;
    const top = sorted.slice(0, TOP_N);
    const rest = sorted.slice(TOP_N);
    const result = top.map(([name, montant], i) => ({ name, montant, pct: monthTotal ? Math.round((montant / monthTotal) * 1000) / 10 : 0, color: DEPT_COLORS[i % DEPT_COLORS.length] }));
    if (rest.length > 0) {
      const autresMontant = rest.reduce((s, [, m]) => s + m, 0);
      result.push({ name: `Autres (${rest.length})`, montant: autresMontant, pct: monthTotal ? Math.round((autresMontant / monthTotal) * 1000) / 10 : 0, color: '#94a3b8' });
    }
    return result;
  }, [monthDebts, monthTotal]);

  // ── Vue annuelle : montants par mois et par type ─────────────────────────
  const annualSeries = useMemo(() => MONTHS_FR.map((label, idx) => {
    const monthNum = idx + 1;
    const row: any = { mois: label };
    Object.keys(TYPE_LABEL).forEach(t => { row[TYPE_LABEL[t]] = 0; });
    allDebts.filter(r => { const d = refDate(r); return d.getFullYear() === year && d.getMonth() + 1 === monthNum; })
      .forEach(r => { row[TYPE_LABEL[r.requestType] ?? r.requestType] += Number(r.amount); });
    return row;
  }), [allDebts, year]);

  const annualSeriesByDept = useMemo(() => MONTHS_FR.map((label, idx) => {
    const monthNum = idx + 1;
    const montant = allDebts.filter(r => {
      const d = refDate(r);
      return d.getFullYear() === year && d.getMonth() + 1 === monthNum && (!deptFilterAnnual || r.employee?.department?.name === deptFilterAnnual);
    }).reduce((s, r) => s + Number(r.amount), 0);
    return { mois: label, Montant: Math.round(montant) };
  }), [allDebts, year, deptFilterAnnual]);

  // ── KPI annuels — vue d'ensemble de l'année entière, pas juste le mois sélectionné ──
  const yearDebts = useMemo(() => allDebts.filter(r => refDate(r).getFullYear() === year), [allDebts, year]);
  const annualKpis = useMemo(() => {
    const total = yearDebts.reduce((s, r) => s + Number(r.amount), 0);
    const count = yearDebts.length;
    const employeesCount = new Set(yearDebts.map(r => r.employeeId)).size;
    // Mois le plus chargé de l'année (utile pour anticiper la trésorerie)
    const byMonth: Record<number, number> = {};
    yearDebts.forEach(r => { const m = refDate(r).getMonth() + 1; byMonth[m] = (byMonth[m] ?? 0) + Number(r.amount); });
    const peakMonthEntry = Object.entries(byMonth).sort((a, b) => b[1] - a[1])[0];
    return {
      total,
      count,
      employeesCount,
      avgAmount: count ? Math.round(total / count) : 0,
      peakMonth: peakMonthEntry ? MONTHS_FR[Number(peakMonthEntry[0]) - 1] : '—',
      peakMonthAmount: peakMonthEntry ? peakMonthEntry[1] : 0,
    };
  }, [yearDebts]);

  const annualByType = useMemo(() => {
    const map: Record<string, number> = {};
    yearDebts.forEach(r => { map[r.requestType] = (map[r.requestType] ?? 0) + Number(r.amount); });
    const total = yearDebts.reduce((s, r) => s + Number(r.amount), 0);
    return Object.entries(map).map(([type, montant]) => ({ type, label: TYPE_LABEL[type] ?? type, montant, pct: total ? Math.round((montant / total) * 1000) / 10 : 0 }));
  }, [yearDebts]);

  // ── Top 20 — employés avec le plus de dettes ─────────────────────────────
  const top20 = useMemo(() => {
    const source = top20Mode === 'mois' ? monthDebts : allDebts.filter(r => refDate(r).getFullYear() === year);
    const map = new Map<string, { name: string; montant: number }>();
    source.forEach(r => {
      const key = r.employeeId;
      const name = `${r.employee?.firstName ?? ''} ${r.employee?.lastName ?? ''}`.trim() || '—';
      const entry = map.get(key) ?? { name, montant: 0 };
      entry.montant += Number(r.amount);
      map.set(key, entry);
    });
    return Array.from(map.values()).sort((a, b) => b.montant - a.montant).slice(0, 20);
  }, [monthDebts, allDebts, top20Mode, year]);

  if (isLoading) return <KonzaLoader variant="page" />;

  return (
    <div className="max-w-[1500px] mx-auto pb-24 space-y-6">
      <FinanceSubNav userRole={userRole} />
      <div>
        <h1 className="text-xl font-bold text-[var(--text)]">Rapport — Prêts, avances & retenues</h1>
        <p className="text-sm text-[var(--text-muted)]">Vue d'ensemble mensuelle et annuelle des dettes des employés.</p>
      </div>

      {/* ══════════════════ ONGLETS MOIS ══════════════════ */}
      <div className="flex flex-wrap gap-1 bg-[var(--surface-2)] p-1 rounded-xl w-fit">
        {MONTHS_FR.map((m, i) => (
          <button key={m} onClick={() => setMonth(i + 1)} className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition-all ${month === i + 1 ? 'bg-emerald-500 text-white shadow-sm' : 'text-[var(--text-muted)] hover:bg-[var(--surface-2)]'}`}>
            {m}
          </button>
        ))}
        <select value={year} onChange={e => setYear(Number(e.target.value))} className="ml-1 text-xs px-2 rounded-lg border-0 bg-[var(--surface)] font-bold text-[var(--text-muted)]">
          {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>

      <LoansRequestsPanel loans={loans} advances={advances} month={month} year={year} />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* ══════════════════ COLONNE GAUCHE : légende + tableau ══════════════════ */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4">
            <p className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1">{MONTHS_FULL[month - 1]} {year}</p>
            <p className="text-2xl font-bold text-[var(--text)]">{employeesConcerned}</p>
            <p className="text-xs text-[var(--text-muted)]">employé(s) avec une dette ce mois</p>
          </div>

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4">
            <p className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-3">Légende</p>
            <div className="space-y-2">
              {Object.entries(TYPE_LABEL).map(([type, label]) => (
                <div key={type} className="flex items-center gap-2 text-sm text-[var(--text-muted)]">
                  <span className="w-3 h-3 rounded-sm shrink-0" style={{ background: TYPE_COLOR[type] }} />
                  {label}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-[var(--surface-2)]">
                <tr>
                  <th className="px-3 py-2 text-left text-[10px] font-bold text-[var(--text-muted)] uppercase">Type</th>
                  <th className="px-3 py-2 text-right text-[10px] font-bold text-[var(--text-muted)] uppercase">Montant</th>
                  <th className="px-3 py-2 text-right text-[10px] font-bold text-[var(--text-muted)] uppercase">%</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border)]">
                {byTypeMonth.length === 0 ? (
                  <tr><td colSpan={3} className="text-center py-6 text-[var(--text-muted)] text-xs">Aucune dette ce mois-ci.</td></tr>
                ) : byTypeMonth.map(t => (
                  <tr key={t.type}>
                    <td className="px-3 py-2 flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ background: TYPE_COLOR[t.type] }} />{t.label}</td>
                    <td className="px-3 py-2 text-right font-semibold text-[var(--text)] whitespace-nowrap">{fmt(t.montant)}</td>
                    <td className="px-3 py-2 text-right text-[var(--text-muted)]">{t.pct}%</td>
                  </tr>
                ))}
                {byTypeMonth.length > 0 && (
                  <tr className="bg-[var(--surface-2)] font-bold">
                    <td className="px-3 py-2">Total</td>
                    <td className="px-3 py-2 text-right whitespace-nowrap">{fmt(monthTotal)}</td>
                    <td className="px-3 py-2 text-right">100%</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* ══════════════════ COLONNE DROITE : camemberts ══════════════════ */}
        <div className="lg:col-span-9 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <p className="text-sm font-bold text-[var(--text)] mb-4">Répartition des dettes par type — {MONTHS_FULL[month - 1]}</p>
            {byTypeMonth.length === 0 ? <EmptyChart /> : (
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <ResponsiveContainer width="100%" height={220} className="sm:!w-1/2">
                  <PieChart>
                    <Pie data={byTypeMonth} dataKey="montant" nameKey="label" innerRadius={50} outerRadius={95} paddingAngle={2}>
                      {byTypeMonth.map((t, i) => <Cell key={i} fill={TYPE_COLOR[t.type]} stroke="none" />)}
                    </Pie>
                    <Tooltip formatter={(v: number) => fmt(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <ChartLegendList items={byTypeMonth.map(t => ({ label: t.label, pct: t.pct, montant: t.montant, color: TYPE_COLOR[t.type] }))} />
              </div>
            )}
          </div>

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <p className="text-sm font-bold text-[var(--text)] mb-4">Répartition par département — {MONTHS_FULL[month - 1]}</p>
            {byDeptMonth.length === 0 ? <EmptyChart /> : (
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <ResponsiveContainer width="100%" height={220} className="sm:!w-1/2">
                  <PieChart>
                    <Pie data={byDeptMonth} dataKey="montant" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={2}>
                      {byDeptMonth.map((d, i) => <Cell key={i} fill={d.color} stroke="none" />)}
                    </Pie>
                    <Tooltip formatter={(v: number) => fmt(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <ChartLegendList items={byDeptMonth.map(d => ({ label: d.name, pct: d.pct, montant: d.montant, color: d.color }))} />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ══════════════════ VUE ANNUELLE — section pleine largeur, indépendante de la vue mensuelle ══════════════════ */}
      <div className="space-y-4">
        <div>
          <h2 className="text-base font-bold text-[var(--text)]">Vue annuelle — {year}</h2>
          <p className="text-xs text-[var(--text-muted)]">Vision globale sur l'année, indépendamment du mois sélectionné ci-dessus.</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <AnnualKpiCard icon={Banknote} label={`Total accordé (${year})`} value={fmt(annualKpis.total)} tone="sky" />
          <AnnualKpiCard icon={Users2} label="Dossiers sur l'année" value={String(annualKpis.count)} sub={`${annualKpis.employeesCount} employé(s) concerné(s)`} tone="slate" />
          <AnnualKpiCard icon={PiggyBank} label="Montant moyen / dossier" value={fmt(annualKpis.avgAmount)} tone="emerald" />
          <AnnualKpiCard icon={TrendingUp} label="Mois le plus chargé" value={annualKpis.peakMonth} sub={annualKpis.peakMonthAmount ? fmt(annualKpis.peakMonthAmount) : undefined} tone="amber" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <p className="text-sm font-bold text-[var(--text)] mb-4">Montants par mois et par type — {year}</p>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={annualSeries}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="mois" fontSize={12} />
                <YAxis fontSize={12} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
                <Tooltip formatter={(v: number) => fmt(v)} />
                <Legend />
                {Object.entries(TYPE_LABEL).map(([type, label]) => (
                  <Area key={type} type="monotone" dataKey={label} stackId="1" stroke={TYPE_COLOR[type]} fill={TYPE_COLOR[type]} fillOpacity={0.55} />
                ))}
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Répartition par type — année entière, en complément du graphe empilé */}
          <div className="lg:col-span-4 bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <p className="text-sm font-bold text-[var(--text)] mb-4">Répartition par type — {year}</p>
            {annualByType.length === 0 ? <EmptyChart /> : (
              <>
                <ResponsiveContainer width="100%" height={160}>
                  <PieChart>
                    <Pie data={annualByType} dataKey="montant" nameKey="label" innerRadius={45} outerRadius={75} paddingAngle={2}>
                      {annualByType.map((t, i) => <Cell key={i} fill={TYPE_COLOR[t.type]} stroke="none" />)}
                    </Pie>
                    <Tooltip formatter={(v: number) => fmt(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="mt-2">
                  <ChartLegendList items={annualByType.map(t => ({ label: t.label, pct: t.pct, montant: t.montant, color: TYPE_COLOR[t.type] }))} />
                </div>
              </>
            )}
          </div>
        </div>

        {/* ══════════════════ VUE ANNUELLE — PAR DÉPARTEMENT ══════════════════ */}
        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm font-bold text-[var(--text)]">Montants par mois — par département ({year})</p>
            <select value={deptFilterAnnual} onChange={e => setDeptFilterAnnual(e.target.value)} className="text-xs px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)]">
              <option value="">Tous les départements</option>
              {departments.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={annualSeriesByDept}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="mois" fontSize={12} />
              <YAxis fontSize={12} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
              <Tooltip formatter={(v: number) => fmt(v)} />
              <Area type="monotone" dataKey="Montant" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.35} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ══════════════════ TOP 20 ══════════════════ */}
      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
        <div className="p-4 flex items-center justify-between border-b border-[var(--border)]">
          <p className="text-sm font-bold text-[var(--text)] flex items-center gap-2"><Users2 size={16} /> Top 20 — employés avec le plus de dettes</p>
          <div className="flex gap-1 bg-[var(--surface-2)] p-1 rounded-lg">
            <button onClick={() => setTop20Mode('mois')} className={`px-3 py-1 rounded-md text-xs font-semibold ${top20Mode === 'mois' ? 'bg-[var(--surface)] shadow-sm text-[var(--text)]' : 'text-[var(--text-muted)]'}`}>{MONTHS_FULL[month - 1]}</button>
            <button onClick={() => setTop20Mode('annee')} className={`px-3 py-1 rounded-md text-xs font-semibold ${top20Mode === 'annee' ? 'bg-[var(--surface)] shadow-sm text-[var(--text)]' : 'text-[var(--text-muted)]'}`}>Annuel {year}</button>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-[var(--surface-2)]">
            <tr>
              <th className="px-4 py-2 text-left text-[10px] font-bold text-[var(--text-muted)] uppercase w-10">#</th>
              <th className="px-4 py-2 text-left text-[10px] font-bold text-[var(--text-muted)] uppercase">Employé</th>
              <th className="px-4 py-2 text-right text-[10px] font-bold text-[var(--text-muted)] uppercase">Montant total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--border)]">
            {top20.length === 0 ? (
              <tr><td colSpan={3} className="text-center py-10 text-[var(--text-muted)]">Aucune donnée pour cette période.</td></tr>
            ) : top20.map((e, i) => (
              <tr key={e.name + i} className="hover:bg-[var(--surface-2)]/40">
                <td className="px-4 py-2 text-[var(--text-muted)] font-semibold">{i + 1}</td>
                <td className="px-4 py-2 font-semibold text-[var(--text)]">{e.name}</td>
                <td className="px-4 py-2 text-right font-bold text-[var(--text)] whitespace-nowrap">{fmt(e.montant)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function EmptyChart() {
  return <div className="h-[260px] flex items-center justify-center text-sm text-[var(--text-muted)]">Aucune donnée pour cette période.</div>;
}

function AnnualKpiCard({ icon: Icon, label, value, sub, tone }: { icon: any; label: string; value: string; sub?: string; tone: 'slate' | 'emerald' | 'amber' | 'sky' }) {
  const cls: Record<string, string> = {
    slate: 'bg-[var(--surface-2)] text-[var(--text-muted)]',
    emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-300',
    amber: 'bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-300',
    sky: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-300',
  };
  return (
    <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${cls[tone]}`}><Icon size={18} /></div>
      <p className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-1">{label}</p>
      <p className="text-lg font-bold text-[var(--text)] truncate">{value}</p>
      {sub && <p className="text-xs text-[var(--text-muted)] mt-0.5 truncate">{sub}</p>}
    </div>
  );
}

/** Légende en liste (couleur + nom + % + montant) — remplace les labels
 * flottants de recharts sur le camembert, qui se chevauchent dès qu'il y a
 * plus de 3-4 tranches proches en taille. Toujours lisible, quel que soit
 * le nombre d'entrées. */
function ChartLegendList({ items }: { items: { label: string; pct: number; montant: number; color: string }[] }) {
  const sorted = [...items].sort((a, b) => b.montant - a.montant);
  return (
    <div className="w-full sm:w-1/2 space-y-2">
      {sorted.map((it, i) => (
        <div key={i} className="flex items-center gap-2 text-xs">
          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: it.color }} />
          <span className="text-[var(--text-muted)] truncate flex-1">{it.label}</span>
          <span className="font-semibold text-[var(--text)] whitespace-nowrap">{it.pct}%</span>
        </div>
      ))}
    </div>
  );
}