'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft, Plus, Trash2, Loader2, CheckCircle2,
  Search, X, Calculator, AlertCircle, ChevronDown,
  ChevronUp, Building2, Check, CreditCard, Wallet,
  Calendar, Briefcase, Users, BadgeCheck, History, RotateCcw,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '@/services/api';

// ─── Types ──────────────────────────────────────────────────────────────────

interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  email?: string;
  baseSalary?: number;
  position?: string;
  employeeNumber?: string;
  contractType?: string;
  hireDate?: string;
  maritalStatus?: string;
  numberOfChildren?: number;
  department?: { name: string };
  isSubjectToCnss?: boolean;
  isSubjectToIrpp?: boolean;
  tolZone?: string;
}

interface CompanyInfo {
  email?: string;
  cnssEmployerRate?: number;
}

interface BonusTemplate {
  id: string;
  name: string;
  defaultAmount: number | null;
  bonusCategory: string;
  isTaxable: boolean;
  isCnss: boolean;
  isActive: boolean;
}

interface CompanyTax {
  id: string;
  name: string;
  code: string;
  employeeRate: number;
  fixedEmployee: number;
  isActive: boolean;
}

interface Loan {
  id: string;
  monthlyRepayment: number;
  remainingBalance: number;
  status: string;
  reason?: string;
  employeeId?: string;
  employee?: { id?: string };
}

interface Advance {
  id: string;
  amount: number;
  status: string;
  deducted: boolean;
  reason?: string;
  employeeId?: string;
  employee?: { id?: string };
}

interface Row {
  localId: string;
  refId?: string;
  label: string;
  base: number | '';
  rate: number | '';
  amount: number;
  // ✅ true = ligne préremplie depuis les primes déjà configurées pour
  // l'employé, jamais touchée par l'utilisateur. Reste synchronisée avec
  // le calcul automatique (donc reproratisée) à chaque recalcul, et n'est
  // PAS envoyée comme "manualBonuses" — dès que l'utilisateur modifie la
  // ligne, elle devient une vraie correction manuelle figée pour ce mois.
  auto?: boolean;
}

interface ManualDeduction {
  localId: string;
  label: string;
  amount: number | '';
}

interface SimResult {
  employee: { id: string; firstName: string; lastName: string; baseSalary: number; effectiveBaseSalary: number; isSubjectToCnss: boolean; isSubjectToIrpp: boolean };
  month: number; year: number; daysToPay: number; workDays: number;
  absenceDeduction: number;
  overtime: { hours10: number; amount10: number; hours25: number; amount25: number; hours50: number; amount50: number; hours100: number; amount100: number; total: number };
  bonuses: Array<{ bonusType: string; amount: number; isCnss?: boolean; isTaxable?: boolean }>;
  adjustedBaseSalary: number; grossSalary: number;
  cnssSalarial: number; its: number; totalDeductions: number; netSalary: number;
  cnssEmployerPension: number; cnssEmployerFamily: number; cnssEmployerAccident: number;
  tusDgiAmount: number; tusCnssAmount: number; totalEmployerCost: number;
  loans: any[]; advances: any[];
  totalLoanDeduction: number; totalAdvanceDeduction: number;
  settings: { cnssSalarialRate: number; overtimeRate10: number; overtimeRate25: number; overtimeRate50: number; overtimeRate100: number };
}

// ─── Constants ───────────────────────────────────────────────────────────────

const MONTHS = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];

const PRIME_SUGGESTIONS = [
  "Prime d'ancienneté","Prime d'assiduité","Prime de confiance",
  "Prime de garde","Prime de motivation","Prime de précaire",
  "Prime de responsabilité","Prime de risque","Prime de base congé",
  "Prime de diplôme","Prime de technicité","Prime de rendement",
  "Prime de résultat","Prime de fin d'année",
];

const INDEMNITE_SUGGESTIONS = [
  "Indemnité de transport","Indemnité de logement","Indemnité de panier",
  "Indemnité kilométrique","Indemnité de représentation","Indemnité vestimentaire",
  "Indemnité de déplacement","Indemnité de téléphone",
];

// ── Autocomplete labels primes & indemnités ──────────────────────────────────
const ALL_PRIME_LABELS = [
  "Prime d'ancienneté", "Prime d'assiduité", "Prime de confiance",
  "Prime de garde", "Prime de motivation", "Prime de précaire",
  "Prime de responsabilité", "Prime de risque", "Prime de base congé",
  "Prime de diplôme", "Prime de technicité", "Prime de rendement",
  "Prime de résultat", "Prime de fin d'année", "Prime de performance",
  "Prime exceptionnelle", "Prime de poste", "Prime de nuit",
  "Prime de dimanche", "Prime de caisse", "Gratification",
  "13ème mois", "Prime d'intéressement",
];

const ALL_INDEM_LABELS = [
  "Indemnité de transport", "Indemnité de logement", "Indemnité de panier",
  "Indemnité kilométrique", "Indemnité de représentation", "Indemnité vestimentaire",
  "Indemnité de déplacement", "Indemnité de téléphone", "Indemnité de salissure",
  "Indemnité de fonction", "Indemnité de stage", "Indemnité d'expatriation",
  "Indemnité de licenciement", "Indemnité compensatrice de congés",
];

const MARITAL_LABELS: Record<string, string> = {
  SINGLE: 'Célibataire', MARRIED: 'Marié(e)',
  DIVORCED: 'Divorcé(e)', WIDOWED: 'Veuf/Veuve',
};

const uid  = () => Math.random().toString(36).slice(2, 9);
const fmt  = (v: number) => Math.round(v || 0).toLocaleString('fr-FR');
const n    = (v: number | '') => Number(v) || 0;

const seniority = (hireDate?: string) => {
  if (!hireDate) return null;
  const hire = new Date(hireDate);
  const now  = new Date();
  const years  = now.getFullYear() - hire.getFullYear();
  const months = now.getMonth() - hire.getMonth();
  const total  = years + (months < 0 ? -1 : 0);
  if (total < 1) {
    const m = ((years * 12) + months + 12) % 12;
    return `${m} mois`;
  }
  return `${total} an${total > 1 ? 's' : ''}`;
};

// ─── Micro-composants ────────────────────────────────────────────────────────

const SLabel = ({ children }: { children: React.ReactNode }) => (
  <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5">{children}</label>
);

const Card = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
  <div className={`bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 ${className}`}>
    {children}
  </div>
);

const SectionHeader = ({ icon, title, subtitle, total, color }: {
  icon: React.ReactNode; title: string; subtitle: string; total?: number; color: string;
}) => (
  <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100 dark:border-gray-700/50">
    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${color}`}>
      {icon}
    </div>
    <div className="flex-1 min-w-0">
      <p className="text-sm font-bold text-gray-800 dark:text-gray-200">{title}</p>
      <p className="text-[11px] text-gray-400 dark:text-gray-500">{subtitle}</p>
    </div>
    {total != null && total > 0 && (
      <span className="text-sm font-mono font-bold text-gray-600 dark:text-gray-300 shrink-0">
        {fmt(total)} F
      </span>
    )}
  </div>
);

const BLine = ({ label, value, cls, sm }: { label: string; value: string; cls?: string; sm?: boolean }) => (
  <div className={`flex items-center justify-between ${sm ? 'py-0.5' : 'py-1.5'}`}>
    <span className={`${sm ? 'text-xs' : 'text-sm'} text-gray-500 dark:text-gray-400`}>{label}</span>
    <span className={`font-mono font-bold tabular-nums ${sm ? 'text-xs' : 'text-sm'} ${cls ?? 'text-gray-700 dark:text-gray-200'}`}>{value}</span>
  </div>
);

const SimpleRow = ({ row, onChangeLabel, onChangeAmount, onRemove, placeholder = 'Libellé…', amountPlaceholder = '0' }: {
  row: Row; onChangeLabel: (v:string)=>void; onChangeAmount: (v:number|'')=>void; onRemove: ()=>void; placeholder?: string; amountPlaceholder?: string;
}) => (
  <motion.div initial={{ opacity:0, y:-4 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-4 }} className="group flex items-center gap-2">
    <input type="text" value={row.label} onChange={e => onChangeLabel(e.target.value)} placeholder={placeholder}
      className="flex-1 min-w-0 px-3 py-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-400/30 placeholder:text-gray-300 dark:placeholder:text-gray-600" />
    <div className="relative w-32 shrink-0">
      <input type="number" value={row.amount || ''} onChange={e => onChangeAmount(e.target.value===''?'':Number(e.target.value))} placeholder={amountPlaceholder}
        className="w-full pl-3 pr-5 py-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-bold text-right text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-400/30" />
      <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-gray-400 pointer-events-none">F</span>
    </div>
    <button onClick={onRemove} className="p-1.5 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all shrink-0"><Trash2 size={13} /></button>
  </motion.div>
);

const InputRow = ({
  row, onChangeLabel, onChangeBase, onChangeRate, onRemove, placeholder = 'Libellé…', suggestions = [],
}: {
  row: Row;
  onChangeLabel: (v: string) => void;
  onChangeBase: (v: number | '') => void;
  onChangeRate: (v: number | '') => void;
  onRemove: () => void;
  placeholder?: string;
  suggestions?: string[];
}) => (
  <motion.div
    initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
    className="group grid grid-cols-[1fr_100px_70px_90px_28px] gap-2 items-center"
  >
    <LabelInput
      value={row.label}
      onChange={onChangeLabel}
      placeholder={placeholder}
      suggestions={suggestions}
    />
    <div className="relative">
      <input
        type="number"
        value={row.base}
        onChange={e => onChangeBase(e.target.value === '' ? '' : Number(e.target.value))}
        placeholder="Base"
        className="w-full pl-2 pr-5 py-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-mono text-right text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
      />
      <span className="absolute right-1.5 top-1/2 -translate-y-1/2 text-[9px] text-gray-400 pointer-events-none">F</span>
    </div>
    <input
      type="number"
      value={row.rate}
      step="0.01"
      onChange={e => onChangeRate(e.target.value === '' ? '' : Number(e.target.value))}
      placeholder="Taux"
      className="w-full px-2 py-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-mono text-center text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
    />
    <div className={`px-2 py-2 rounded-xl text-sm font-black font-mono text-right tabular-nums border transition-colors ${
      row.amount > 0
        ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
        : 'bg-gray-50 dark:bg-gray-900/30 border-gray-100 dark:border-gray-700/50 text-gray-300 dark:text-gray-600'
    }`}>
      {row.amount > 0 ? row.amount.toLocaleString('fr-FR') : '—'}
    </div>
    <button
      onClick={onRemove}
      className="p-1.5 text-gray-300 hover:text-red-500 dark:hover:text-red-400 opacity-0 group-hover:opacity-100 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
    >
      <Trash2 size={13} />
    </button>
  </motion.div>
);


// ─── LabelInput — input avec autocomplete contextuel ────────────────────────
// Suggestions filtrées par ce qui est tapé, insensibles à la casse.
// L'utilisateur peut taper n'importe quoi (pas limité aux suggestions).

const LabelInput = ({
  value, onChange, placeholder, suggestions, className = '',
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  suggestions: string[];
  className?: string;
}) => {
  const [open, setOpen]   = React.useState(false);
  const [query, setQuery] = React.useState(value);
  const ref               = React.useRef<HTMLDivElement>(null);

  // Sync externe → interne
  React.useEffect(() => { setQuery(value); }, [value]);

  // Fermer si clic extérieur
  React.useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const filtered = query.length >= 1
    ? suggestions.filter(s => s.toLowerCase().includes(query.toLowerCase())).slice(0, 8)
    : [];

  const handleChange = (v: string) => {
    setQuery(v);
    onChange(v);
    setOpen(true);
  };

  const handleSelect = (s: string) => {
    setQuery(s);
    onChange(s);
    setOpen(false);
  };

  return (
    <div ref={ref} className={`relative ${className}`}>
      <input
        type="text"
        value={query}
        onChange={e => handleChange(e.target.value)}
        onFocus={() => query.length >= 1 && setOpen(true)}
        placeholder={placeholder}
        className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-400/30 placeholder:text-gray-300 dark:placeholder:text-gray-600"
      />
      <AnimatePresence>
        {open && filtered.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
            className="absolute z-[999] left-0 right-0 top-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-2xl overflow-hidden"
          >
            {filtered.map(s => (
              <button key={s} onMouseDown={() => handleSelect(s)}
                className="w-full px-3 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors border-b border-gray-50 dark:border-gray-700/50 last:border-0">
                {/* Highlight la partie matchée */}
                {(() => {
                  const idx = s.toLowerCase().indexOf(query.toLowerCase());
                  if (idx === -1) return s;
                  return (
                    <>
                      {s.slice(0, idx)}
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">{s.slice(idx, idx + query.length)}</span>
                      {s.slice(idx + query.length)}
                    </>
                  );
                })()}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// ─── Page principale ─────────────────────────────────────────────────────────

export default function ManuelPayrollPage() {
  const router = useRouter();
  const now    = new Date();

  const [employees, setEmployees]       = useState<Employee[]>([]);
  const [empSearch, setEmpSearch]       = useState('');
  const [showDrop, setShowDrop]         = useState(false);
  const [selectedEmp, setSelectedEmp]   = useState<Employee | null>(null);
  const [empDetail, setEmpDetail]       = useState<Employee | null>(null);
  const [loadingEmp, setLoadingEmp]     = useState(true);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [month, setMonth]               = useState(MONTHS[now.getMonth()]);
  const [year, setYear]                 = useState(now.getFullYear());
  // ✅ Vide par défaut — rempli avec les VRAIS jours de présence renvoyés
  // par la simulation (sim.daysToPay), tant que l'utilisateur n'a pas
  // modifié le champ à la main (workedDaysEdited).
  const [workedDays, setWorkedDays]         = useState<number | ''>('');
  const [workedDaysEdited, setWorkedDaysEdited] = useState(false);
  // ✅ Préremplissage primes/indemnités depuis ce qui est déjà configuré
  // pour l'employé (convention, ancienneté, primes récurrentes) — une
  // seule fois par employé sélectionné, pour ne pas écraser une saisie
  // en cours à chaque recalcul.
  const [bonusesPrefilled, setBonusesPrefilled] = useState(false);
  const [ot10, setOt10]   = useState<number | ''>(0);
  const [ot25, setOt25]   = useState<number | ''>(0);
  const [ot50, setOt50]   = useState<number | ''>(0);
  const [ot100, setOt100] = useState<number | ''>(0);

  const [bonusTemplates, setBonusTemplates] = useState<BonusTemplate[]>([]);
  const [companyTaxes, setCompanyTaxes]     = useState<CompanyTax[]>([]);
  const [empLoans, setEmpLoans]             = useState<Loan[]>([]);
  const [empAdvances, setEmpAdvances]       = useState<Advance[]>([]);
  const [companyInfo, setCompanyInfo]       = useState<CompanyInfo>({});

  const [primes, setPrimes]           = useState<Row[]>([]);
  const [indemnites, setIndemnites]   = useState<Row[]>([]);
  const [taxes, setTaxes]             = useState<Row[]>([]);
  const [loans, setLoans]             = useState<Row[]>([]);
  const [advances, setAdvances]       = useState<Row[]>([]);
  const [retenues, setRetenues]       = useState<ManualDeduction[]>([]);  // ✅ retenues libres


  const [congesDroits, setCongesDroits]       = useState<number|''>('');
  const [congesPris, setCongesPris]           = useState<number|''>('');
  const [congesSolde, setCongesSolde]         = useState<number|''>('');
  const [joursCongesPris, setJoursCongesPris] = useState<number|''>('');  // jours consommés ce mois

  // ── CarryOver — point de départ historique ────────────────────────────────
  // ✅ Simplifié : seul le brut annuel est saisi. Le reste (CNSS sal. 4%, net
  // imposable, charges pat.) est dérivé automatiquement. Le taux patronal est
  // pré-rempli depuis la config entreprise (20.28% par défaut) mais reste éditable.
  const [carryOverBrut, setCarryOverBrut]       = useState<number|''>('');
  const [carryOverTauxPat, setCarryOverTauxPat] = useState<number|''>('');
  const [savingCarryOver, setSavingCarryOver]   = useState(false);
  const [carryOverSaved, setCarryOverSaved]     = useState(false);

  const [showPrimeSugg, setShowPrimeSugg]     = useState(false);
  const [showIndemSugg, setShowIndemSugg]     = useState(false);
  const [showTaxSugg, setShowTaxSugg]         = useState(false);
  const [primeSuggSearch, setPrimeSuggSearch] = useState('');
  const [indemSuggSearch, setIndemSuggSearch] = useState('');

  const [sim, setSim]               = useState<SimResult | null>(null);
  const [simLoading, setSimLoading] = useState(false);
  const [simError, setSimError]     = useState<string | null>(null);
  const [showEmpCost, setShowEmpCost] = useState(false);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess]       = useState(false);
  const [createdId, setCreatedId]   = useState<string | null>(null);

  // ── Toggle "Utiliser données précédentes" ────────────────────────────────
  const [usePrevData, setUsePrevData]       = useState(false);
  const [loadingPrev, setLoadingPrev]       = useState(false);
  const [prevDataLoaded, setPrevDataLoaded] = useState(false);

  useEffect(() => {
    api.get<any>('/employees/simple')
      .then(r => setEmployees(Array.isArray(r) ? r : (r?.data ?? [])))
      .catch(() => setEmployees([]))
      .finally(() => setLoadingEmp(false));
  }, []);

  useEffect(() => {
    Promise.all([
      api.get<any>('/bonus-templates').catch(() => []),
      api.get<any>('/company-taxes').catch(() => []),
      api.get<any>('/company/info').catch(() => ({})),
    ]).then(([bt, ct, ci]) => {
      setBonusTemplates((Array.isArray(bt) ? bt : []).filter((t: BonusTemplate) => t.isActive));
      setCompanyTaxes((Array.isArray(ct) ? ct : []).filter((t: CompanyTax) => t.isActive));
      setCompanyInfo(ci ?? {});
      // ✅ Pré-remplit le taux patronal carryOver depuis la config entreprise (sinon 20.28% par défaut)
      setCarryOverTauxPat(Number(ci?.cnssEmployerRate) || 20.28);
    });
  }, []);

  // ✅ Vérifier si c'est l'entreprise parafifi — logique ancienneté/gratif/congés spéciale
  const isParafifi = companyInfo?.email === 'admin@parafifi.cg';

  useEffect(() => {
    if (!selectedEmp) {
      setEmpDetail(null); setEmpLoans([]); setEmpAdvances([]);
      setLoans([]); setAdvances([]);
      return;
    }
    // Nouvel employé → on retente le préremplissage des primes/indemnités
    setBonusesPrefilled(false);
    setLoadingDetail(true);
    Promise.all([
      api.get<any>(`/employees/${selectedEmp.id}`).catch(() => null),
      api.get<any>('/loans').catch(() => []),
      api.get<any>('/loans/advances').catch(() => []),
    ]).then(([detail, allLoans, allAdvances]) => {
      setEmpDetail(detail);
      const empId = selectedEmp.id;
      const activeLoans = (Array.isArray(allLoans) ? allLoans : [])
        .filter((l: Loan) => (l.employeeId === empId || l.employee?.id === empId) && l.status === 'ACTIVE');
      const pendingAdv  = (Array.isArray(allAdvances) ? allAdvances : [])
        .filter((a: Advance) => (a.employeeId === empId || a.employee?.id === empId) && a.status === 'APPROVED' && !a.deducted);
      setEmpLoans(activeLoans);
      setEmpAdvances(pendingAdv);
    }).finally(() => setLoadingDetail(false));
  }, [selectedEmp]);



  const filtered = empSearch.length >= 1
    ? employees.filter(e =>
        `${e.firstName} ${e.lastName} ${e.employeeNumber ?? ''}`.toLowerCase()
          .includes(empSearch.toLowerCase())
      ).slice(0, 8)
    : [];

  const newRow = (label = ''): Row => ({ localId: uid(), label, base: '', rate: 1, amount: 0 });

  // ✅ Trier les primes — congés toujours en dernière position
  const sortPrimes = (rows: Row[]): Row[] => {
    const isConge = (r: Row) => /cong[eé]/i.test(r.label);
    return [...rows.filter(r => !isConge(r)), ...rows.filter(r => isConge(r))];
  };

  const updateRow = (set: React.Dispatch<React.SetStateAction<Row[]>>, localId: string, patch: Partial<Row>) =>
    set(prev => {
      const updated = prev.map(r => {
        if (r.localId !== localId) return r;
        // ✅ Dès que l'utilisateur touche une ligne préremplie, elle sort du
        // mode "auto" — son montant est désormais figé et envoyé tel quel.
        const next = { ...r, ...patch, auto: false };
        next.amount = Math.round((Number(next.base) || 0) * (Number(next.rate) || 0));
        return next;
      });
      // Re-trier si c'est la liste des primes (label modifié)
      return 'label' in patch ? sortPrimes(updated) : updated;
    });

  const removeRow = (set: React.Dispatch<React.SetStateAction<Row[]>>, localId: string) =>
    set(prev => prev.filter(r => r.localId !== localId));

  const addSuggestion = (
    set: React.Dispatch<React.SetStateAction<Row[]>>,
    rows: Row[],
    label: string,
    defaultAmount = 0
  ) => {
    if (rows.some(r => r.label === label)) return;
    // ✅ Trier après ajout si c'est une prime (congés en dernier)
    set(prev => sortPrimes([...prev, { ...newRow(label), base: defaultAmount || '', rate: defaultAmount ? 1 : '', amount: defaultAmount || 0 }]));
  };

  const addTaxFromTemplate = (tax: CompanyTax) => {
    if (taxes.some(t => t.refId === tax.id)) return;
    const grossEst = n(empDetail?.baseSalary as any) + primes.reduce((s,r) => s + n(r.amount), 0);
    const fixed = Number(tax.fixedEmployee);
    const rate  = Number(tax.employeeRate);
    const amt   = fixed > 0 ? fixed : Math.round(grossEst * rate);
    const id    = tax.id;
    const name  = tax.name;
    setTaxes(prev => [...prev, { localId: uid(), refId: id, label: name, base: '', rate: 1, amount: amt }]);
  };

  // ── CarryOver : débloqué en janvier ou si pas de bulletins (retour congé) ──
  // On détecte via sim : si c'est jan OU si le brut du cycle précédent = 0
  const isCarryOverMonth = month === 'Janvier' || (sim && (sim as any).ytd?.grossSalary === 0);

  // ── Dérivés du carryOver, calculés depuis le seul brut annuel saisi ────────
  const CARRYOVER_CNSS_SAL_RATE = 0.04; // CNSS salarié 4% (taux fixe légal)
  const carryOverChargesSal = Math.round(n(carryOverBrut) * CARRYOVER_CNSS_SAL_RATE);
  const carryOverNetImp     = Math.round(n(carryOverBrut) - carryOverChargesSal);
  const carryOverChargesPat = Math.round(n(carryOverBrut) * (n(carryOverTauxPat) / 100));
  // Net annuel historique — pas d'ITS connu sur l'historique, on aligne sur le net imposable
  const carryOverNetSalary  = carryOverNetImp;

  const saveCarryOver = async () => {
    if (!selectedEmp) return;
    setSavingCarryOver(true);
    try {
      await api.patch(`/employees/${selectedEmp.id}`, {
        ytdCarryOverBrut:       n(carryOverBrut)       || null,
        ytdCarryOverNetImp:     carryOverNetImp        || null,
        ytdCarryOverNetSalary:  carryOverNetSalary      || null,
        ytdCarryOverChargesSal: carryOverChargesSal     || null,
        ytdCarryOverChargesPat: carryOverChargesPat     || null,
        ytdCarryOverDate:       new Date(`${year}-01-01`).toISOString(),
      });
      setCarryOverSaved(true);
      setTimeout(() => setCarryOverSaved(false), 3000);
    } catch (e: any) {
      alert(`Erreur sauvegarde : ${e?.message}`);
    } finally {
      setSavingCarryOver(false);
    }
  };

  // ── Bannière congé — solde >= 26j ───────────────────────────────────────────
  const soldeConge     = (sim as any)?.ytd?.soldeConge   ?? 0;
  const baseCongeCalc  = (sim as any)?.ytd?.baseConge ?? 0;
  const showCongeBanner = soldeConge >= 26 && selectedEmp && empDetail;

  // ── Détection auto prime par label — universel ──────────────────────────────
  const applyAutoIfNeeded = (localId: string, label: string) => {
    if (!empDetail?.baseSalary) return;
    const l    = label.toLowerCase().trim();
    const base = Number(empDetail.baseSalary);
    if (/anc[iè]/i.test(l)) {
      const years = getSeniorityYears(empDetail.hireDate);
      if (years > 0) {
        const rate = years / 100;
        setPrimes(prev => prev.map(r => r.localId === localId ? { ...r, base, rate, amount: Math.round(base * rate) } : r));
      }
      return;
    }
    if (/gratif/i.test(l)) {
      setPrimes(prev => prev.map(r => r.localId === localId ? { ...r, base, rate: 0.5, amount: Math.round(base / 2) } : r));
      return;
    }
    if (/cong[eé]/i.test(l)) {
      // ✅ Base congé = brut annuel M-1 / 12 (méthode 1/12e Congo)
      // Le backend calcule le vrai YTD du mois précédent et le retourne dans sim.ytd.baseConge
      const baseConge = (sim as any)?.ytd?.baseConge ?? 0;
      if (!baseConge) return;
      setPrimes(prev => sortPrimes(prev.map(r => r.localId === localId ? { ...r, base: baseConge, rate: 1, amount: baseConge } : r)));
      return;
    }
  };

  // ── ✅ Helper payload — base toujours renseignée, rate seulement si significatif ──
  // ── Calculs spéciaux Parafifi ──────────────────────────────────────────────

  // Ancienneté en années complètes (ex: 5 ans → 0.05, 29 ans → 0.29)
  const getSeniorityRate = (hireDate?: string): number => {
    if (!hireDate) return 0;
    const hire = new Date(hireDate);
    const now  = new Date();
    let years  = now.getFullYear() - hire.getFullYear();
    const m    = now.getMonth() - hire.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < hire.getDate())) years--;
    return Math.max(0, years) / 100; // 5 ans → 0.05
  };

  const getSeniorityYears = (hireDate?: string): number => {
    if (!hireDate) return 0;
    const hire = new Date(hireDate);
    const now  = new Date();
    let years  = now.getFullYear() - hire.getFullYear();
    const m    = now.getMonth() - hire.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < hire.getDate())) years--;
    return Math.max(0, years);
  };

  // Ajouter prime d'ancienneté auto (Parafifi) : base = salaire de base, rate = années/100
  const addAnciennete = () => {
    if (!empDetail?.baseSalary || !empDetail?.hireDate) return;
    const base  = Number(empDetail.baseSalary);
    const years = getSeniorityYears(empDetail.hireDate);
    if (years === 0) return;
    const rate   = years / 100;  // 5 ans → 0.05 → affiché "0,05"
    const amount = Math.round(base * rate);
    const label  = "Prime d'ancienneté";
    if (primes.some(p => p.label === label)) return;
    setPrimes(prev => [...prev, { localId: uid(), label, base, rate, amount }]);
  };

  // Gratification = salaire de base / 2 (base brute, pas ajustée)
  const addGratification = () => {
    if (!empDetail?.baseSalary) return;
    const base   = Number(empDetail.baseSalary);
    const amount = Math.round(base / 2);
    const label  = 'Gratification';
    if (primes.some(p => p.label === label)) return;
    setPrimes(prev => [...prev, { localId: uid(), label, base, rate: 0.5, amount }]);
  };

  // Congés payés — base = ytd.grossSalary / 12 (méthode 1/12e Congo)
  // Vient du back via sim.ytd.baseConge ou approximation depuis carryOverBrut
  const addCongesPaies = () => {
    // ✅ Base congé = brut annuel M-1 / 12 — calculé par le backend dans sim.ytd.baseConge
    const baseConge = (sim as any)?.ytd?.baseConge ?? 0;
    if (!baseConge) return;
    const label = 'Congés payés';
    if (primes.some(p => p.label === label)) return;
    setPrimes(prev => sortPrimes([...prev, { localId: uid(), label, base: baseConge, rate: 1, amount: baseConge }]));
  };;

  // ✅ Les lignes encore "auto" (préremplies, non modifiées) ne sont PAS
  // envoyées : le backend les recalcule lui-même depuis les primes
  // configurées, avec le prorata à jour selon les jours travaillés du
  // moment. Ne partent en "manualBonuses" que les lignes ajoutées ou
  // corrigées à la main — sinon leur montant resterait figé à sa valeur
  // du premier calcul, sans jamais suivre un changement de jours ensuite.
  const buildBonusPayload = (rows: Row[], taxable: boolean) =>
    rows.filter(r => !r.auto && n(r.amount) > 0).map(r => ({
      bonusType:  r.label || (taxable ? 'Prime' : 'Indemnité'),
      amount:     r.amount,
      // ✅ Si base non saisie → base = amount (gain direct sans calcul)
      base:       n(r.base) > 0 ? n(r.base) : r.amount,
      // ✅ Rate seulement si saisi et différent de 0 et 1
      // Si pas de taux ou taux=1 → gain=base, on n'envoie pas rate
      // Les HS ont leur propre logique dans payroll-items_service, pas touchées ici
      // ✅ Toujours envoyer rate si base présente — 1 = montant fixe (s'affiche sur bulletin)
      // undefined = pas de taux ni base (montant direct sans calcul)
      rate:       n(r.rate) > 0 ? n(r.rate) : (n(r.base) > 0 ? 1 : undefined),
      isTaxable:  taxable,
      isCnss:     taxable,
      fiscalType: taxable ? 'TAXABLE_CNSS' : 'NON_TAXABLE',
    }));

  useEffect(() => {
    if (!selectedEmp || !empDetail) return;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(runSim, 700);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [primes, indemnites, selectedEmp, empDetail, month, year, workedDays, ot10, ot25, ot50, ot100]);

  const runSim = async () => {
    if (!selectedEmp || !empDetail) return;
    const baseSal = n(empDetail.baseSalary as any);
    if (!baseSal) return;

    const primesPayload = buildBonusPayload(primes, true);
    const indemPayload  = buildBonusPayload(indemnites, false);
    const manualBonuses = [...primesPayload, ...indemPayload];
    const manualDeductionsPayload = retenues.filter(r => n(r.amount) > 0)
      .map(r => ({ label: r.label || 'Retenue', amount: n(r.amount) }));

    setSimLoading(true); setSimError(null);
    try {
      const result = await api.post<SimResult>('/payrolls/simulate', {
        employeeId: selectedEmp.id,
        month: MONTHS.findIndex(m => m === month) + 1,
        year,
        // ✅ N'envoie un override que si l'utilisateur a lui-même modifié le
        // champ — sinon le backend va chercher les vrais jours en BDD
        // (présences), au lieu de forcer 26 (plein mois) par défaut.
        ...(workedDaysEdited && workedDays !== '' ? { workedDays: n(workedDays) } : {}),
        baseSalary: baseSal,
        overtimeHours10:  n(ot10),
        overtimeHours25:  n(ot25),
        overtimeHours50:  n(ot50),
        overtimeHours100: n(ot100),
        manualBonuses:     manualBonuses.length > 0 ? manualBonuses : undefined,
        manualDeductions:  manualDeductionsPayload.length > 0 ? manualDeductionsPayload : undefined,
      });
      setSim(result);
      // ✅ Première simulation (champ pas encore touché) → on affiche les
      // vrais jours renvoyés par le backend, comme pour les heures sup.
      if (!workedDaysEdited && result?.daysToPay != null) {
        setWorkedDays(result.daysToPay);
      }
      // ✅ Préremplir primes/indemnités avec ce qui est déjà configuré pour
      // cet employé (convention, ancienneté, primes récurrentes) — visible
      // et modifiable au lieu de s'appliquer en silence. Seulement au tout
      // premier calcul pour cet employé (formulaire encore vide, pas de
      // reprise "mois précédent" en cours).
      if (!bonusesPrefilled && !usePrevData && primes.length === 0 && indemnites.length === 0) {
        const cong = /cong[eé]/i;
        const configured = (result?.bonuses ?? []).filter(b => !cong.test(b.bonusType || ''));
        const toPrimes     = configured.filter(b => b.isCnss !== false)
          .map(b => ({ localId: uid(), label: b.bonusType, base: b.amount, rate: 1, amount: b.amount, auto: true }));
        const toIndemnites = configured.filter(b => b.isCnss === false)
          .map(b => ({ localId: uid(), label: b.bonusType, base: b.amount, rate: 1, amount: b.amount, auto: true }));
        if (toPrimes.length > 0)     setPrimes(sortPrimes(toPrimes));
        if (toIndemnites.length > 0) setIndemnites(toIndemnites);
      } else {
        // ✅ Recalcul suivant : les lignes encore "auto" (non éditées) sont
        // resynchronisées sur le dernier montant renvoyé par le backend
        // (donc reproratisé si les jours travaillés ont changé). Une ligne
        // dont la prime n'existe plus côté backend (ex: convention
        // désactivée entre-temps) reste affichée telle quelle — retirer
        // silencieusement une ligne que l'utilisateur voit à l'écran
        // serait plus perturbant qu'utile.
        const freshByType = new Map(
          (result?.bonuses ?? []).map(b => [String(b.bonusType || '').trim().toLowerCase(), b.amount]),
        );
        const syncAuto = (rows: Row[]) => rows.map(r => {
          if (!r.auto) return r;
          const fresh = freshByType.get(String(r.label || '').trim().toLowerCase());
          return fresh != null ? { ...r, base: fresh, rate: 1, amount: fresh } : r;
        });
        if (primes.some(r => r.auto))     setPrimes(prev => syncAuto(prev));
        if (indemnites.some(r => r.auto)) setIndemnites(prev => syncAuto(prev));
      }
      setBonusesPrefilled(true);
    } catch (e: any) {
      setSimError(e?.response?.data?.message || e?.message || 'Erreur');
      setSim(null);
    } finally {
      setSimLoading(false);
    }
  };

  const submit = async () => {
    if (!selectedEmp || !sim || !empDetail) return;
    setSubmitting(true);
    try {
      // ✅ Même helper — cohérence simulate / create
      const primesP = buildBonusPayload(primes, true);
      const indemP  = buildBonusPayload(indemnites, false);

      const manualDedP = retenues.filter(r => n(r.amount) > 0)
        .map(r => ({ label: r.label || 'Retenue', amount: n(r.amount) }));
      const result: any = await api.post('/payrolls/manual', {
        employeeId: selectedEmp.id,
        month: MONTHS.findIndex(m => m === month) + 1,
        year,
        // ✅ Idem simulate() : override seulement si modifié à la main,
        // sinon le backend reprend les vrais jours en BDD.
        ...(workedDaysEdited && workedDays !== '' ? { workedDays: n(workedDays) } : {}),
        baseSalary: n(empDetail.baseSalary as any),
        overtimeHours10:  n(ot10), overtimeHours25: n(ot25),
        overtimeHours50:  n(ot50), overtimeHours100: n(ot100),
        manualBonuses:    [...primesP, ...indemP],
        congesDroits:     n(congesDroits)     || undefined,
        congesPris:       n(congesPris)       || undefined,
        congesSolde:      n(congesSolde)      || undefined,
        // ✅ Jours consommés ce mois — pour déduire du LeaveBalance
        joursCongesPris:  n(joursCongesPris)  || undefined,
        manualDeductions: manualDedP.length > 0 ? manualDedP : undefined,
      });
      setCreatedId(result?.id || null);
      setSuccess(true);
    } catch (e: any) {
      alert(`Erreur : ${e?.response?.data?.message || e?.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  // ── Charger les données du bulletin M-1 ──────────────────────────────────
  const loadPrevData = async () => {
    if (!selectedEmp) return;
    setLoadingPrev(true);
    try {
      // Calculer le mois précédent
      const currentMonthIdx = MONTHS.findIndex(m => m === month);
      const prevMonthIdx    = currentMonthIdx === 0 ? 11 : currentMonthIdx - 1;
      const prevYear        = currentMonthIdx === 0 ? year - 1 : year;
      const prevMonthNum    = prevMonthIdx + 1;

      // ✅ Étape 1 — trouver l'ID du bulletin du mois précédent
      // findAll retourne un tableau SANS items (infos de base seulement)
      const list: any = await api.get(
        `/payrolls?employeeId=${selectedEmp.id}&month=${prevMonthNum}&year=${prevYear}`
      ).catch(() => null);

      const listArr   = Array.isArray(list) ? list : (list?.data ?? []);
      const prevMeta  = listArr[0] ?? null;

      if (!prevMeta?.id) {
        alert(`Aucun bulletin trouvé pour ${MONTHS[prevMonthIdx]} ${prevYear}`);
        setUsePrevData(false);
        return;
      }

      // ✅ Étape 2 — charger le bulletin complet avec tous ses items
      const prev: any = await api.get(`/payrolls/${prevMeta.id}`).catch(() => null);

      if (!prev || !prev.items) {
        alert(`Impossible de charger les données de ${MONTHS[prevMonthIdx]} ${prevYear}`);
        setUsePrevData(false);
        return;
      }

      // ── Extraire les données du bulletin précédent ──────────────────────

      // Jours travaillés
      // Valeur reprise d'un bulletin précédent = un choix explicite, pas la valeur auto
      if (prev.workedDays) { setWorkedDays(prev.workedDays); setWorkedDaysEdited(true); }

      // Heures sup
      setOt10(Number(prev.overtimeHours10  ?? 0));
      setOt25(Number(prev.overtimeHours25  ?? 0));
      setOt50(Number(prev.overtimeHours50  ?? 0));
      setOt100(Number(prev.overtimeHours100 ?? 0));

      // Primes (GAIN isTaxable) depuis les items du bulletin
      const prevPrimes: Row[] = (prev.items ?? [])
        .filter((i: any) => i.type === 'GAIN' && i.isTaxable && !['SAL_BASE','INDEM_CONGE'].includes(i.code))
        .map((i: any) => ({
          localId: uid(),
          label:   i.label ?? '',
          base:    i.base  ? Number(i.base)  : '',
          rate:    i.quantity ? Number(i.quantity) : (i.rate ? Number(i.rate) : 1),
          amount:  Number(i.amount ?? 0),
        }));
      if (prevPrimes.length > 0) setPrimes(sortPrimes(prevPrimes));

      // Indemnités (GAIN !isTaxable && !isCnss) depuis les items
      const prevIndem: Row[] = (prev.items ?? [])
        .filter((i: any) => i.type === 'GAIN' && !i.isTaxable && !i.isCnss)
        .map((i: any) => ({
          localId: uid(),
          label:   i.label ?? '',
          base:    i.base  ? Number(i.base)  : '',
          rate:    i.quantity ? Number(i.quantity) : (i.rate ? Number(i.rate) : 1),
          amount:  Number(i.amount ?? 0),
        }));
      if (prevIndem.length > 0) setIndemnites(prevIndem);

      // Retenues libres (MANUAL_DEDUCTION)
      const prevRetenues: ManualDeduction[] = (prev.items ?? [])
        .filter((i: any) => i.code === 'MANUAL_DEDUCTION')
        .map((i: any) => ({
          localId: uid(),
          label:   i.label ?? '',
          amount:  Number(i.amount ?? 0),
        }));
      if (prevRetenues.length > 0) setRetenues(prevRetenues);

      // Congés — snapshot du bulletin précédent
      const congeItem = (prev.items ?? []).find((i: any) => i.code === 'CONGES_SNAPSHOT' || i.code === 'ABS_CONGE');
      if (prev.congesDroits != null)   setCongesDroits(Number(prev.congesDroits));
      if (prev.congesPris   != null)   setCongesPris(Number(prev.congesPris));
      if (prev.congesSolde  != null)   setCongesSolde(Number(prev.congesSolde));

      setPrevDataLoaded(true);
    } catch (e: any) {
      alert(`Erreur chargement données précédentes : ${e?.message}`);
      setUsePrevData(false);
    } finally {
      setLoadingPrev(false);
    }
  };

  // ── Réinitialiser les données quand toggle désactivé ─────────────────────
  const clearPrevData = () => {
    setPrimes([]); setIndemnites([]); setRetenues([]);
    setOt10(0); setOt25(0); setOt50(0); setOt100(0);
    // ✅ Retour aux vrais jours de présence (pas un 26 en dur) — voir le
    // correctif sur workedDays plus haut dans ce fichier.
    setWorkedDays(''); setWorkedDaysEdited(false);
    setCongesDroits(''); setCongesPris(''); setCongesSolde('');
    setPrevDataLoaded(false);
    // ✅ Le formulaire redevient vide → laisser le préremplissage depuis les
    // primes déjà configurées reprendre la main au prochain calcul.
    setBonusesPrefilled(false);
  };

  const resetPage = () => {
    setSuccess(false); setSim(null); setSelectedEmp(null); setEmpSearch('');
    setEmpDetail(null); setEmpLoans([]); setEmpAdvances([]);
    setWorkedDays(''); setWorkedDaysEdited(false); setOt10(0); setOt25(0); setOt50(0); setOt100(0);
    setPrimes([]); setIndemnites([]); setTaxes([]); setLoans([]); setAdvances([]); setRetenues([]);
    setCarryOverBrut(''); setCarryOverTauxPat(Number(companyInfo?.cnssEmployerRate) || 20.28);
    setCongesDroits(''); setCongesPris(''); setCongesSolde(''); setJoursCongesPris(''); setCarryOverSaved(false);
    setUsePrevData(false); setPrevDataLoaded(false);
  };

  const hasOt = [ot10,ot25,ot50,ot100].some(v => n(v) > 0);
  const totalPrimes     = primes.reduce((s,r) => s + r.amount, 0);
  const totalIndemnites = indemnites.reduce((s,r) => s + r.amount, 0);
  const totalTaxes      = taxes.reduce((s,r) => s+n(r.amount), 0);
  const totalLoans      = loans.reduce((s,r) => s+n(r.amount), 0);
  const totalAdvances   = advances.reduce((s,r) => s+n(r.amount), 0);
  const totalRetenues   = retenues.reduce((s,r) => s+n(r.amount), 0);

  const dbPrimeSugg = bonusTemplates.filter(t => t.isTaxable);
  const dbIndemSugg = bonusTemplates.filter(t => !t.isTaxable);

  return (
    <div className="max-w-[1380px] mx-auto pb-28 px-4 pt-1">

      {/* ── Header ── */}
      <div className="flex items-center gap-4 mb-7">
        <button onClick={() => router.back()}
          className="p-2 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors shrink-0">
          <ArrowLeft size={18} className="text-gray-500" />
        </button>
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Saisie manuelle de paie</h1>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 uppercase tracking-wide">Manuel</span>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">CNSS, ITS et TUS calculés automatiquement selon la nature de chaque élément</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-5 gap-6 items-start">

        {/* ════ COL GAUCHE ════ */}
        <div className="lg:col-span-3 space-y-4">

          {/* ── Période ── */}
          <Card className="p-5">
            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-4">Période</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <SLabel>Mois</SLabel>
                <select value={month} onChange={e => setMonth(e.target.value)}
                  className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-medium text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                  {MONTHS.map(m => <option key={m}>{m}</option>)}
                </select>
              </div>
              <div>
                <SLabel>Année</SLabel>
                <select value={year} onChange={e => setYear(Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-medium text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                  {[2023,2024,2025,2026,2027].map(y => <option key={y}>{y}</option>)}
                </select>
              </div>
            </div>
          </Card>

          {/* ── Employé ── */}
          <Card className="overflow-visible">
            <div className="px-5 pt-5 pb-4">
              <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-3">Employé</p>

              {selectedEmp ? (
                <div>
                  <div className="flex items-start justify-between p-3 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-2xl mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-emerald-200 dark:bg-emerald-800 flex items-center justify-center text-emerald-700 dark:text-emerald-300 font-black text-sm shrink-0">
                        {selectedEmp.firstName[0]}{selectedEmp.lastName[0]}
                      </div>
                      <div>
                        <p className="font-bold text-gray-900 dark:text-white">{selectedEmp.firstName} {selectedEmp.lastName}</p>
                        <p className="text-xs text-gray-500">{selectedEmp.position}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {loadingDetail && <Loader2 size={14} className="animate-spin text-emerald-500" />}
                      <button onClick={() => { setSelectedEmp(null); setEmpSearch(''); setSim(null); }}
                        className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors">
                        <X size={14} />
                      </button>
                    </div>
                  </div>

                  {empDetail && (
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { icon: <BadgeCheck size={13} />, label: 'Matricule',   value: empDetail.employeeNumber || '—' },
                        { icon: <Briefcase  size={13} />, label: 'Contrat',     value: empDetail.contractType   || '—' },
                        { icon: <Calendar   size={13} />, label: 'Ancienneté',  value: seniority(empDetail.hireDate) ?? '—' },
                        { icon: <Users      size={13} />, label: 'Situation',
                          value: `${MARITAL_LABELS[empDetail.maritalStatus ?? ''] ?? '—'}${empDetail.numberOfChildren ? ` · ${empDetail.numberOfChildren} enf.` : ''}` },
                      ].map(({ icon, label, value }) => (
                        <div key={label} className="flex items-center gap-2 px-3 py-2 bg-gray-50 dark:bg-gray-900/40 rounded-xl">
                          <span className="text-gray-400 dark:text-gray-500 shrink-0">{icon}</span>
                          <div className="min-w-0">
                            <p className="text-[10px] text-gray-400 dark:text-gray-500">{label}</p>
                            <p className="text-xs font-bold text-gray-700 dark:text-gray-300 truncate">{value}</p>
                          </div>
                        </div>
                      ))}
                      <div className="col-span-2 flex items-center justify-between px-3 py-2.5 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800/50 rounded-xl">
                        <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">Salaire de base</span>
                        <span className="text-sm font-black font-mono text-emerald-700 dark:text-emerald-300">
                          {empDetail.baseSalary ? `${fmt(Number(empDetail.baseSalary))} FCFA` : '—'}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="relative">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input type="text" value={empSearch}
                    onChange={e => { setEmpSearch(e.target.value); setShowDrop(true); }}
                    onFocus={() => setShowDrop(true)}
                    placeholder="Rechercher par nom, prénom ou matricule…"
                    className="w-full pl-9 pr-3 py-2.5 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-gray-800 dark:text-gray-200 placeholder:text-gray-400" />
                  <AnimatePresence>
                    {showDrop && filtered.length > 0 && (
                      <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                        className="absolute z-30 left-0 right-0 top-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-2xl overflow-hidden">
                        {filtered.map((e, i) => (
                          <button key={e.id}
                            onClick={() => { setSelectedEmp(e); setEmpSearch(''); setShowDrop(false); }}
                            className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 text-left transition-colors ${i > 0 ? 'border-t border-gray-50 dark:border-gray-700/50' : ''}`}>
                            <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-[11px] font-black text-gray-600 dark:text-gray-300 shrink-0">
                              {e.firstName[0]}{e.lastName[0]}
                            </div>
                            <div className="min-w-0">
                              <p className="text-sm font-bold text-gray-900 dark:text-white">{e.firstName} {e.lastName}</p>
                              <p className="text-[11px] text-gray-400 truncate">
                                {[e.employeeNumber, e.position, e.department?.name].filter(Boolean).join(' · ')}
                              </p>
                            </div>
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}
            </div>

            {/* ✅ Bannière congé — solde >= 26j */}
            {showCongeBanner && (
              <div className="mx-5 mb-0 mt-3 flex items-center justify-between px-4 py-2.5 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🏖️</span>
                  <div>
                    <p className="text-xs font-bold text-amber-700 dark:text-amber-300">
                      {soldeConge}j de congés disponibles
                    </p>
                    <p className="text-[10px] text-amber-600 dark:text-amber-400">
                      Indemnité congé : <strong>{baseCongeCalc.toLocaleString('fr-FR')} F/an</strong> (ytd ÷ 12)
                    </p>
                  </div>
                </div>
                <button
                  onClick={addCongesPaies}
                  disabled={primes.some(p => /cong[eé]/i.test(p.label))}
                  className="px-3 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0">
                  {primes.some(p => /cong[eé]/i.test(p.label)) ? '✓ Ajouté' : 'Ajouter congé'}
                </button>
              </div>
            )}

            {/* ✅ Toggle "Utiliser données précédentes" */}
            {selectedEmp && empDetail && (
              <div className="mx-5 mb-4 mt-3">
                <div className="flex items-center justify-between px-4 py-3 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl">
                  <div className="flex items-center gap-2.5">
                    <History size={15} className="text-emerald-500 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-emerald-700 dark:text-emerald-300">Utiliser les données du mois précédent</p>
                      <p className="text-[10px] text-emerald-500 dark:text-emerald-400">
                        {(() => {
                          const idx = MONTHS.findIndex(m => m === month);
                          const prevIdx = idx === 0 ? 11 : idx - 1;
                          const prevYr  = idx === 0 ? year - 1 : year;
                          return `Primes, indemnités, HS de ${MONTHS[prevIdx]} ${prevYr}`;
                        })()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {prevDataLoaded && (
                      <button onClick={clearPrevData}
                        className="flex items-center gap-1 px-2 py-1 text-[10px] font-bold text-gray-500 hover:text-red-500 border border-gray-200 dark:border-gray-600 rounded-lg transition-colors">
                        <RotateCcw size={9} /> Vider
                      </button>
                    )}
                    {loadingPrev
                      ? <Loader2 size={16} className="animate-spin text-emerald-500" />
                      : (
                        <button
                          onClick={() => {
                            const next = !usePrevData;
                            setUsePrevData(next);
                            if (next) loadPrevData();
                            else clearPrevData();
                          }}
                          className={`relative w-11 h-6 rounded-full transition-colors duration-200 focus:outline-none ${usePrevData ? 'bg-emerald-500' : 'bg-gray-200 dark:bg-gray-700'}`}>
                          <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform duration-200 ${usePrevData ? 'translate-x-5' : ''}`} />
                        </button>
                      )
                    }
                  </div>
                </div>
                {prevDataLoaded && (
                  <p className="text-[10px] text-emerald-600 dark:text-emerald-400 mt-1.5 px-1 flex items-center gap-1">
                    <CheckCircle2 size={9} /> Données chargées — modifiez librement avant de confirmer
                  </p>
                )}
              </div>
            )}

            {selectedEmp && (
              <div className="px-5 pb-5 border-t border-gray-100 dark:border-gray-700/50 pt-4">
                <SLabel>
                  Jours travaillés{' '}
                  <span className="font-normal text-gray-400">/ {sim?.workDays ?? 26} jours théoriques</span>
                  {!workedDaysEdited && sim && (
                    <span className="ml-1.5 text-[10px] font-bold text-emerald-500">(présences)</span>
                  )}
                </SLabel>
                <div className="flex items-center gap-3">
                  <input type="number" min={0} max={sim?.workDays ?? 26} value={workedDays}
                    onChange={e => {
                      setWorkedDaysEdited(true);
                      const max = sim?.workDays ?? 26;
                      setWorkedDays(e.target.value === '' ? '' : Math.min(max, Math.max(0, Number(e.target.value))));
                    }}
                    className={`w-20 px-3 py-2 bg-gray-50 dark:bg-gray-900/50 border rounded-xl text-sm font-bold text-center text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 ${
                      workedDaysEdited ? 'border-amber-400' : 'border-gray-200 dark:border-gray-700'
                    }`} />
                  <div className="flex-1 h-1.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-400 rounded-full transition-all"
                      style={{ width: `${Math.min(100,(n(workedDays)/(sim?.workDays ?? 26))*100)}%` }} />
                  </div>
                  <span className="text-xs text-gray-400 tabular-nums w-8 text-right">{Math.round((n(workedDays)/(sim?.workDays ?? 26))*100)}%</span>
                </div>
                {!workedDaysEdited && sim?.daysToPay === 0 && (
                  <p className="text-[10px] text-amber-500 mt-1.5 flex items-center gap-1">
                    <AlertCircle size={9} /> Aucune présence trouvée en BDD pour ce mois — vérifiez le pointage ou ajustez ce champ.
                  </p>
                )}
              </div>
            )}
          </Card>

          {/* ── Heures supplémentaires ── */}
          <Card className="p-5">
            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-3">Heures supplémentaires</p>
            <div className="grid grid-cols-4 gap-3">
              {([
                { label:'+10%',  v:ot10,  set:setOt10,  col:'text-amber-500',  ring:'focus:ring-amber-400/30' },
                { label:'+25%',  v:ot25,  set:setOt25,  col:'text-amber-500', ring:'focus:ring-amber-400/30' },
                { label:'+50%',  v:ot50,  set:setOt50,  col:'text-amber-500',   ring:'focus:ring-amber-400/30' },
                { label:'+100%', v:ot100, set:setOt100, col:'text-amber-500',    ring:'focus:ring-amber-400/30' },
              ] as const).map(({ label, v, set, col, ring }) => (
                <div key={label} className="text-center">
                  <label className={`block text-xs font-bold mb-1.5 ${col}`}>{label}</label>
                  <div className="relative">
                    <input type="number" min={0} value={v}
                      onChange={e => set(e.target.value === '' ? 0 : Number(e.target.value) as any)}
                      className={`w-full pl-2 pr-5 py-2.5 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-bold text-center text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 ${ring}`} />
                    <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-gray-400">h</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* ── Primes ── */}
          <Card className="overflow-visible">
            <SectionHeader
              icon={<span className="text-amber-600 dark:text-amber-400 text-xs font-black">%</span>}
              title="Primes"
              subtitle="Soumises à CNSS et ITS — viennent avant le brut"
              total={totalPrimes}
              color="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 text-amber-600"
            />
            <div className="px-5 py-4 space-y-2">
              <div className="grid grid-cols-[1fr_100px_70px_90px_28px] gap-2 px-1 mb-1">
                {['Libellé','Base (F)','Taux','Gain (F)',''].map((h,i) => (
                  <span key={i} className={`text-[10px] font-bold text-gray-400 uppercase tracking-wide ${i===3?'text-right':''}`}>{h}</span>
                ))}
              </div>
              <AnimatePresence initial={false}>
                {primes.map(row => (
                  <InputRow key={row.localId} row={row}
                    placeholder="Ex : Prime d'ancienneté, de rendement…"
                    suggestions={ALL_PRIME_LABELS}
                    onChangeLabel={v => {
                      updateRow(setPrimes, row.localId, { label: v });
                      applyAutoIfNeeded(row.localId, v);
                    }}
                    onChangeBase={v => updateRow(setPrimes, row.localId, { base: v })}
                    onChangeRate={v => updateRow(setPrimes, row.localId, { rate: v })}
                    onRemove={() => removeRow(setPrimes, row.localId)} />
                ))}
              </AnimatePresence>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button onClick={() => setPrimes(p => [...p, newRow()])}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20 hover:bg-amber-100 dark:hover:bg-amber-900/30 rounded-lg transition-colors">
                  <Plus size={11} /> Ajouter une prime
                </button>
                <div className="relative">
                  <button onClick={() => setShowPrimeSugg(v => !v)}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    Suggestions <ChevronDown size={9} className={`transition-transform ${showPrimeSugg ? 'rotate-180':''}`} />
                  </button>
                  <AnimatePresence>
                    {showPrimeSugg && (
                      <motion.div initial={{ opacity:0, y:-4 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0 }}
                        className="absolute z-[999] left-0 top-full mt-1.5 w-72 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-2xl p-3 space-y-1.5">
                        <input type="text" value={primeSuggSearch} onChange={e => setPrimeSuggSearch(e.target.value)}
                          placeholder="Rechercher une prime…"
                          className="w-full px-3 py-1.5 mb-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-400/30 text-gray-700 dark:text-gray-300" />
                        <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto">
                          {(dbPrimeSugg.length > 0
                            ? dbPrimeSugg.map(t => ({ name: t.name, amount: t.defaultAmount ? String(Number(t.defaultAmount)) : '' }))
                            : PRIME_SUGGESTIONS.map(s => ({ name: s, amount: '' }))
                          ).filter(({ name }) => !primeSuggSearch || name.toLowerCase().includes(primeSuggSearch.toLowerCase()))
                          .map(({ name, amount }) => {
                            const added = primes.some(r => r.label === name);
                            return (
                              <button key={name}
                                onClick={() => { addSuggestion(setPrimes, primes, name, amount as any); }}
                                disabled={added}
                                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${added ? 'opacity-40 cursor-not-allowed bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600 text-gray-400' : 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800 hover:bg-amber-100'}`}>
                                {added ? <Check size={9}/> : <Plus size={9}/>} {name}
                              </button>
                            );
                          })}
                        </div>
                        <button onClick={() => setShowPrimeSugg(false)} className="w-full pt-1 text-xs text-gray-400 hover:text-gray-600 transition-colors">Fermer</button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </Card>

          {/* ── Indemnités ── */}
          <Card className="overflow-visible">
            <SectionHeader
              icon={<span className="text-emerald-600 dark:text-emerald-400 text-xs font-black">≠</span>}
              title="Indemnités"
              subtitle="Non soumises à CNSS ni ITS — transport, logement, panier…"
              total={totalIndemnites}
              color="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 text-emerald-600"
            />
            <div className="px-5 py-4 space-y-2">
              <div className="grid grid-cols-[1fr_100px_70px_90px_28px] gap-2 px-1 mb-1">
                {['Libellé','Base (F)','Taux','Gain (F)',''].map((h,i) => (
                  <span key={i} className={`text-[10px] font-bold text-gray-400 uppercase tracking-wide ${i===3?'text-right':''}`}>{h}</span>
                ))}
              </div>
              <AnimatePresence initial={false}>
                {indemnites.map(row => (
                  <InputRow key={row.localId} row={row}
                    placeholder="Ex : Indemnité de transport, de logement…"
                    suggestions={ALL_INDEM_LABELS}
                    onChangeLabel={v => updateRow(setIndemnites, row.localId, { label: v })}
                    onChangeBase={v => updateRow(setIndemnites, row.localId, { base: v })}
                    onChangeRate={v => updateRow(setIndemnites, row.localId, { rate: v })}
                    onRemove={() => removeRow(setIndemnites, row.localId)} />
                ))}
              </AnimatePresence>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button onClick={() => setIndemnites(p => [...p, newRow()])}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-900/20 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 rounded-lg transition-colors">
                  <Plus size={11} /> Ajouter une indemnité
                </button>
                <div className="relative">
                  <button onClick={() => setShowIndemSugg(v => !v)}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    Suggestions <ChevronDown size={9} className={`transition-transform ${showIndemSugg?'rotate-180':''}`} />
                  </button>
                  <AnimatePresence>
                    {showIndemSugg && (
                      <motion.div initial={{ opacity:0, y:-4 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0 }}
                        className="absolute z-[999] left-0 top-full mt-1.5 w-64 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-2xl p-3">
                        <input type="text" value={indemSuggSearch} onChange={e => setIndemSuggSearch(e.target.value)}
                          placeholder="Rechercher une indemnité…"
                          className="w-full px-3 py-1.5 mb-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-400/30 text-gray-700 dark:text-gray-300" />
                        <div className="flex flex-wrap gap-1.5">
                          {(dbIndemSugg.length > 0
                            ? dbIndemSugg.map(t => ({ name: t.name, amount: t.defaultAmount ? String(Number(t.defaultAmount)) : '' }))
                            : INDEMNITE_SUGGESTIONS.map(s => ({ name: s, amount: '' }))
                          ).filter(({ name }) => !indemSuggSearch || name.toLowerCase().includes(indemSuggSearch.toLowerCase()))
                          .map(({ name, amount }) => {
                            const added = indemnites.some(r => r.label === name);
                            return (
                              <button key={name}
                                onClick={() => addSuggestion(setIndemnites, indemnites, name, amount as any)}
                                disabled={added}
                                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${added ? 'opacity-40 cursor-not-allowed bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600 text-gray-400' : 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'}`}>
                                {added ? <Check size={9}/> : <Plus size={9}/>} {name}
                              </button>
                            );
                          })}
                        </div>
                        <button onClick={() => setShowIndemSugg(false)} className="w-full pt-2 text-xs text-gray-400 hover:text-gray-600 transition-colors">Fermer</button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </Card>

          {/* ── Taxes ── */}
          <Card className="overflow-visible">
            <SectionHeader
              icon={<Building2 size={14} className="text-amber-600 dark:text-amber-400" />}
              title="Taxes & Retenues spécifiques"
              subtitle="CNSS et ITS automatiques — ajoutez ici les taxes supplémentaires"
              total={totalTaxes}
              color="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800"
            />
            <div className="px-5 py-4 space-y-2">
              <AnimatePresence initial={false}>
                {taxes.map(row => (
                  <SimpleRow key={row.localId} row={row}
                    placeholder="Ex : CAMU, TOL, Taxe d'apprentissage…"
                    onChangeLabel={v => updateRow(setTaxes, row.localId, { label: v })}
                    onChangeAmount={v => updateRow(setTaxes, row.localId, { amount: Number(v)||0 })}
                    onRemove={() => removeRow(setTaxes, row.localId)} />
                ))}
              </AnimatePresence>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button onClick={() => setTaxes(p => [...p, newRow()])}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20 hover:bg-amber-100 dark:hover:bg-amber-900/30 rounded-lg transition-colors">
                  <Plus size={11} /> Ajouter une taxe
                </button>
                {companyTaxes.length > 0 && (
                  <div className="relative">
                    <button onClick={() => setShowTaxSugg(v => !v)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                      Taxes configurées <ChevronDown size={9} className={`transition-transform ${showTaxSugg?'rotate-180':''}`} />
                    </button>
                    <AnimatePresence>
                      {showTaxSugg && (
                        <motion.div initial={{ opacity:0, y:-4 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0 }}
                          className="absolute z-[999] left-0 top-full mt-1.5 w-64 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-2xl p-3">
                          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide mb-2">Taxes de l'entreprise</p>
                          <div className="space-y-1">
                            {companyTaxes.map(tax => {
                              const added = taxes.some(t => t.refId === tax.id);
                              return (
                                <button key={tax.id} onClick={() => { addTaxFromTemplate(tax); setShowTaxSugg(false); }} disabled={added}
                                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm transition-colors ${added ? 'opacity-40 cursor-not-allowed' : 'hover:bg-amber-50 dark:hover:bg-amber-900/20'}`}>
                                  <div className="text-left">
                                    <p className="font-semibold text-gray-800 dark:text-gray-200">{tax.name}</p>
                                    <p className="text-[10px] text-gray-400 font-mono">{tax.code} · {Number(tax.fixedEmployee)>0?`${fmt(Number(tax.fixedEmployee))} F fixe`:`${(Number(tax.employeeRate)*100).toFixed(2)}%`}</p>
                                  </div>
                                  {added ? <Check size={12} className="text-emerald-500"/> : <Plus size={12} className="text-gray-400"/>}
                                </button>
                              );
                            })}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </div>
          </Card>

          {/* ── Prêts ── */}
          <Card className="overflow-hidden">
            <SectionHeader
              icon={<CreditCard size={14} className="text-amber-600 dark:text-amber-400" />}
              title="Prêts"
              subtitle="Remboursements mensuels à déduire du net"
              total={[...empLoans.map(l => Number(l.monthlyRepayment)), ...loans.map(r => n(r.amount))].reduce((s,v)=>s+v,0)}
              color="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800"
            />
            <div className="px-5 py-4 space-y-2">
              {empLoans.map(loan => (
                <div key={loan.id} className="flex items-center justify-between px-3 py-2.5 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800/40 rounded-xl">
                  <div>
                    <p className="text-sm font-bold text-gray-800 dark:text-gray-200">Prêt{loan.reason ? ` — ${loan.reason}` : ''}</p>
                    <p className="text-[11px] text-gray-400">Solde restant : {fmt(Number(loan.remainingBalance))} F</p>
                  </div>
                  <span className="text-sm font-mono font-black text-amber-600 dark:text-amber-400">−{fmt(Number(loan.monthlyRepayment))} F</span>
                </div>
              ))}
              <AnimatePresence initial={false}>
                {loans.map(row => (
                  <SimpleRow key={row.localId} row={row}
                    placeholder="Ex : Remboursement prêt logement…"
                    amountPlaceholder="Mensualité"
                    onChangeLabel={v => updateRow(setLoans, row.localId, { label: v })}
                    onChangeAmount={v => updateRow(setLoans, row.localId, { amount: Number(v)||0 })}
                    onRemove={() => removeRow(setLoans, row.localId)} />
                ))}
              </AnimatePresence>
              <button onClick={() => setLoans(p => [...p, newRow()])}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20 hover:bg-amber-100 dark:hover:bg-amber-900/30 rounded-lg transition-colors mt-1">
                <Plus size={11} /> Ajouter un prêt manuellement
              </button>
            </div>
          </Card>

          {/* ── Avances ── */}
          <Card className="overflow-hidden">
            <SectionHeader
              icon={<Wallet size={14} className="text-red-600 dark:text-red-400" />}
              title="Avances sur salaire"
              subtitle="Montants à déduire du net ce mois-ci"
              total={[...empAdvances.map(a => Number(a.amount)), ...advances.map(r => n(r.amount))].reduce((s,v)=>s+v,0)}
              color="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800"
            />
            <div className="px-5 py-4 space-y-2">
              {empAdvances.map(adv => (
                <div key={adv.id} className="flex items-center justify-between px-3 py-2.5 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800/40 rounded-xl">
                  <div>
                    <p className="text-sm font-bold text-gray-800 dark:text-gray-200">Avance sur salaire</p>
                    {adv.reason && <p className="text-[11px] text-gray-400">{adv.reason}</p>}
                  </div>
                  <span className="text-sm font-mono font-black text-red-600 dark:text-red-400">−{fmt(Number(adv.amount))} F</span>
                </div>
              ))}
              <AnimatePresence initial={false}>
                {advances.map(row => (
                  <SimpleRow key={row.localId} row={row}
                    placeholder="Ex : Avance du 15 janvier…"
                    amountPlaceholder="Montant"
                    onChangeLabel={v => updateRow(setAdvances, row.localId, { label: v })}
                    onChangeAmount={v => updateRow(setAdvances, row.localId, { amount: Number(v)||0 })}
                    onRemove={() => removeRow(setAdvances, row.localId)} />
                ))}
              </AnimatePresence>
              <button onClick={() => setAdvances(p => [...p, newRow()])}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-lg transition-colors mt-1">
                <Plus size={11} /> Ajouter une avance manuellement
              </button>
            </div>
          </Card>

          {/* ════ SECTION RETENUES LIBRES ════ */}
          <Card className="overflow-hidden">
            <SectionHeader
              icon={<span className="text-red-600 dark:text-red-400 text-xs font-black">−</span>}
              title="Autres retenues"
              subtitle="Retenues sans pré-enregistrement — déduites du net"
              total={totalRetenues}
              color="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800"
            />
            <div className="px-5 py-4 space-y-2">
              <AnimatePresence initial={false}>
                {retenues.map(r => (
                  <motion.div key={r.localId} initial={{ opacity:0, y:-4 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-4 }}
                    className="group flex items-center gap-2">
                    <input type="text" value={r.label}
                      onChange={e => setRetenues(prev => prev.map(x => x.localId === r.localId ? { ...x, label: e.target.value } : x))}
                      placeholder="Ex : Remboursement, Trop-perçu, Cotisation…"
                      className="flex-1 min-w-0 px-3 py-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-red-400/30 placeholder:text-gray-300 dark:placeholder:text-gray-600" />
                    <div className="relative w-32 shrink-0">
                      <input type="number" value={r.amount || ''}
                        onChange={e => setRetenues(prev => prev.map(x => x.localId === r.localId ? { ...x, amount: e.target.value === '' ? '' : Number(e.target.value) } : x))}
                        placeholder="Montant"
                        className="w-full pl-3 pr-5 py-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-bold text-right text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-red-400/30" />
                      <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-gray-400 pointer-events-none">F</span>
                    </div>
                    <button onClick={() => setRetenues(prev => prev.filter(x => x.localId !== r.localId))}
                      className="p-1.5 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all shrink-0">
                      <Trash2 size={13} />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
              <button onClick={() => setRetenues(prev => [...prev, { localId: uid(), label: '', amount: '' }])}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-lg transition-colors mt-1">
                <Plus size={11} /> Ajouter une retenue
              </button>
            </div>
          </Card>

          {/* ════ SUGGESTIONS PARAFIFI ════ */}
          {isParafifi && empDetail && (
            <Card className="overflow-visible border-2 border-dashed border-amber-200 dark:border-amber-800">
              <div className="px-5 py-4">
                <p className="text-[11px] font-bold text-amber-500 dark:text-amber-400 uppercase tracking-wider mb-3">
                  🏢 Éléments spéciaux — Parafifi
                </p>
                <div className="flex flex-wrap gap-2">
                  {/* Prime ancienneté */}
                  <button onClick={addAnciennete}
                    disabled={!empDetail.hireDate || getSeniorityYears(empDetail.hireDate) === 0 || primes.some(p => p.label === "Prime d'ancienneté")}
                    className="flex flex-col items-start px-4 py-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl hover:bg-amber-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                    <span className="text-xs font-bold text-amber-700 dark:text-amber-300">Prime d'ancienneté</span>
                    <span className="text-[10px] text-amber-500 mt-0.5">
                      {empDetail.hireDate
                        ? `${getSeniorityYears(empDetail.hireDate)} ans → taux ${(getSeniorityRate(empDetail.hireDate) * 100).toFixed(0)}% → ${Math.round(Number(empDetail.baseSalary) * getSeniorityRate(empDetail.hireDate)).toLocaleString('fr-FR')} F`
                        : 'Date embauche manquante'}
                    </span>
                  </button>
                  {/* Gratification */}
                  <button onClick={addGratification}
                    disabled={primes.some(p => p.label === 'Gratification')}
                    className="flex flex-col items-start px-4 py-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl hover:bg-amber-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                    <span className="text-xs font-bold text-amber-700 dark:text-amber-300">Gratification</span>
                    <span className="text-[10px] text-amber-500 mt-0.5">
                      Salaire base ÷ 2 = {Math.round(Number(empDetail.baseSalary) / 2).toLocaleString('fr-FR')} F
                    </span>
                  </button>
                  {/* Congés payés */}
                  <button onClick={addCongesPaies}
                    disabled={primes.some(p => p.label === 'Indemnité de congés payés')}
                    className="flex flex-col items-start px-4 py-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl hover:bg-amber-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                    <span className="text-xs font-bold text-amber-700 dark:text-amber-300">Congés payés</span>
                    <span className="text-[10px] text-amber-500 mt-0.5">
                      Salaire base ÷ 2 = {Math.round(Number(empDetail.baseSalary) / 2).toLocaleString('fr-FR')} F
                    </span>
                  </button>
                </div>
                <p className="text-[10px] text-amber-400 mt-3">Ces éléments sont soumis à CNSS et ITS — ajoutés dans la section Primes.</p>
              </div>
            </Card>
          )}

          {/* ════ POINT DE DÉPART HISTORIQUE ════ */}
          {/* Visible uniquement en janvier OU après retour congé (cycle = 0) */}
          {selectedEmp && isCarryOverMonth && (
            <Card className="p-5 border-2 border-dashed border-amber-200 dark:border-amber-800">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                  <span className="text-amber-600 text-xs font-black">📅</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-800 dark:text-gray-200">
                    Point de départ — Brut &amp; Charges historiques
                  </p>
                  <p className="text-[10px] text-amber-600 dark:text-amber-400">
                    {month === 'Janvier' ? `Janvier ${year} — début de cycle` : 'Retour de congé — nouveau cycle'}
                  </p>
                </div>
              </div>
              <p className="text-[10px] text-gray-400 mb-3">
                Saisissez le <strong>brut annuel</strong> cumulé <strong>avant</strong> ce mois (bulletins papier ou anciens systèmes).
                Le reste (CNSS, net imposable, charges patronales) est calculé automatiquement.
              </p>
              <div className="grid grid-cols-2 gap-2 mb-3">
                <div>
                  <p className="text-[10px] text-gray-400 mb-1">Brut annuel historique</p>
                  <div className="relative">
                    <input type="number" value={carryOverBrut}
                      onChange={e => setCarryOverBrut(e.target.value===''?'':Number(e.target.value))}
                      placeholder="0"
                      className="w-full pl-2 pr-6 py-2 bg-gray-50 dark:bg-gray-900/50 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-mono text-right focus:outline-none focus:ring-2 focus:ring-emerald-400/30 text-gray-800 dark:text-gray-200" />
                    <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] text-gray-400">F</span>
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 mb-1">Taux patronal CNSS</p>
                  <div className="relative">
                    <input type="number" step="0.01" value={carryOverTauxPat}
                      onChange={e => setCarryOverTauxPat(e.target.value===''?'':Number(e.target.value))}
                      placeholder="20.28"
                      className="w-full pl-2 pr-6 py-2 bg-gray-50 dark:bg-gray-900/50 border border-amber-200 dark:border-amber-800 rounded-xl text-xs font-mono text-right focus:outline-none focus:ring-2 focus:ring-amber-400/30 text-gray-800 dark:text-gray-200" />
                    <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] text-gray-400">%</span>
                  </div>
                </div>
              </div>
              {n(carryOverBrut) > 0 && (
                <div className="grid grid-cols-3 gap-2 mb-3 text-center">
                  <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-lg py-1.5 px-1">
                    <p className="text-[8px] text-emerald-500">Net imposable</p>
                    <p className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300">{carryOverNetImp.toLocaleString('fr-FR')}</p>
                  </div>
                  <div className="bg-red-50 dark:bg-red-900/20 rounded-lg py-1.5 px-1">
                    <p className="text-[8px] text-red-500">CNSS sal. (4%)</p>
                    <p className="text-[10px] font-bold text-red-700 dark:text-red-300">{carryOverChargesSal.toLocaleString('fr-FR')}</p>
                  </div>
                  <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg py-1.5 px-1">
                    <p className="text-[8px] text-amber-500">Charges pat.</p>
                    <p className="text-[10px] font-bold text-amber-700 dark:text-amber-300">{carryOverChargesPat.toLocaleString('fr-FR')}</p>
                  </div>
                </div>
              )}
              <button onClick={saveCarryOver} disabled={savingCarryOver}
                className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                {savingCarryOver ? <><Loader2 size={12} className="animate-spin"/>Sauvegarde…</> :
                 carryOverSaved  ? <><CheckCircle2 size={12}/>Sauvegardé ✓</> :
                                   'Enregistrer le point de départ'}
              </button>
              {(n(carryOverBrut) > 0) && (
                <p className="text-[10px] text-center text-gray-400 mt-2">
                  Indemnité congé estimée : <strong className="text-emerald-600">{Math.round(n(carryOverBrut) / 12).toLocaleString('fr-FR')} F/an</strong>
                </p>
              )}
            </Card>
          )}

          {/* ════ CONGÉS ANNUELS ════ */}
          {selectedEmp && (
            <Card className="p-5">
              <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-3">Congés annuels</p>
              <div className="grid grid-cols-3 gap-2">
                {([
                  { label:'Droits', val:congesDroits, set:setCongesDroits },
                  { label:'Pris',   val:congesPris,   set:setCongesPris },
                  { label:'Solde',  val:congesSolde,  set:setCongesSolde },
                ] as const).map(({ label, val, set }) => (
                  <div key={label}>
                    <p className="text-[10px] text-gray-400 mb-1">{label} (jours)</p>
                    <input type="number" value={val}
                      onChange={e => (set as any)(e.target.value===''?'':Number(e.target.value))}
                      placeholder="0"
                      className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-mono text-center text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-400/30" />
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-gray-400 mt-2 text-center">
                Ces valeurs s'affichent dans la section congés annuels du bulletin.
              </p>

              {/* ✅ Jours pris ce mois — visible si congés payés dans les primes */}
              {primes.some(p => /cong[eé]/i.test(p.label)) && (
                <div className="mt-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl">
                  <p className="text-xs font-bold text-amber-700 dark:text-amber-300 mb-2">
                    🏖️ Congés payés détectés — combien de jours part-il ?
                  </p>
                  <div className="flex items-center gap-2">
                    <input type="number" value={joursCongesPris} min={1} max={78}
                      onChange={e => setJoursCongesPris(e.target.value===''?'':Number(e.target.value))}
                      placeholder="ex: 26"
                      className="w-24 px-3 py-2 bg-white dark:bg-gray-900/50 border border-amber-300 dark:border-amber-700 rounded-xl text-sm font-bold text-center text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-amber-400/30" />
                    <span className="text-xs text-amber-600">jours — le cycle brut/charges repart à 0 après ce bulletin</span>
                  </div>
                </div>
              )}
            </Card>
          )}

          {!selectedEmp && (
            <div className="flex items-center gap-3 px-4 py-3 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl">
              <AlertCircle size={14} className="text-emerald-500 shrink-0" />
              <p className="text-sm text-emerald-700 dark:text-emerald-300">Sélectionnez un employé pour commencer la saisie.</p>
            </div>
          )}
        </div>

        {/* ════ COL DROITE — Aperçu bulletin ════ */}
        <div className="lg:col-span-2 sticky top-6">
          <AnimatePresence mode="wait">
            {sim ? (
              <motion.div key="sim" initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }}
                className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">

                <div className="bg-gray-900 dark:bg-black text-white px-5 py-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase tracking-widest font-semibold">Aperçu bulletin</p>
                      <p className="font-black text-lg mt-0.5">{sim.employee.firstName} {sim.employee.lastName}</p>
                    </div>
                    {simLoading && (
                      <div className="flex items-center gap-1.5 bg-white/10 px-2.5 py-1 rounded-full">
                        <Loader2 size={10} className="animate-spin text-emerald-400" />
                        <span className="text-[10px] text-emerald-300 font-semibold">Recalcul…</span>
                      </div>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1.5 text-[11px] text-gray-400">
                    <span className="capitalize">{month} {year}</span>
                    <span>·</span>
                    <span>{sim.daysToPay}/{sim.workDays} jours</span>
                    {sim.absenceDeduction > 0 && <><span>·</span><span className="text-amber-400">−{fmt(sim.absenceDeduction)} F abs.</span></>}
                    {hasOt && <><span>·</span><span className="text-amber-400">HS</span></>}
                  </div>
                </div>

                <div className="px-5 py-4 space-y-0.5">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Gains</p>
                  <BLine label="Salaire de base ajusté" value={`+${fmt(sim.adjustedBaseSalary)} F`} cls="text-gray-800 dark:text-gray-100" />
                  {sim.overtime.amount10  > 0 && <BLine label={`HS +${sim.settings.overtimeRate10}% (${sim.overtime.hours10}h)`}   value={`+${fmt(sim.overtime.amount10)} F`}  cls="text-amber-500" sm />}
                  {sim.overtime.amount25  > 0 && <BLine label={`HS +${sim.settings.overtimeRate25}% (${sim.overtime.hours25}h)`}   value={`+${fmt(sim.overtime.amount25)} F`}  cls="text-amber-500" sm />}
                  {sim.overtime.amount50  > 0 && <BLine label={`HS +${sim.settings.overtimeRate50}% (${sim.overtime.hours50}h)`}   value={`+${fmt(sim.overtime.amount50)} F`}  cls="text-amber-500"  sm />}
                  {sim.overtime.amount100 > 0 && <BLine label={`HS +${sim.settings.overtimeRate100}% (${sim.overtime.hours100}h)`} value={`+${fmt(sim.overtime.amount100)} F`} cls="text-red-500"   sm />}
                  {sim.bonuses?.map((b, i) => <BLine key={i} label={b.bonusType} value={`+${fmt(b.amount)} F`} cls="text-emerald-600 dark:text-emerald-400" sm />)}

                  <div className="flex justify-between items-center py-2 bg-emerald-50 dark:bg-emerald-900/20 px-3 rounded-xl mt-2">
                    <span className="text-sm font-bold text-emerald-800 dark:text-emerald-200">Salaire brut</span>
                    <span className="font-mono font-black text-emerald-700 dark:text-emerald-300">{fmt(sim.grossSalary)} F</span>
                  </div>

                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider pt-3 mb-2">Retenues légales</p>
                  <BLine label={`CNSS (${sim.settings.cnssSalarialRate}%)`}
                    value={sim.employee.isSubjectToCnss ? `−${fmt(sim.cnssSalarial)} F` : '0 F (exempté)'}
                    cls={sim.employee.isSubjectToCnss ? 'text-red-500' : 'text-gray-400'} />
                  <BLine label="ITS / IRPP"
                    value={sim.employee.isSubjectToIrpp ? `−${fmt(sim.its)} F` : '0 F (exempté)'}
                    cls={sim.employee.isSubjectToIrpp ? 'text-red-500' : 'text-gray-400'} />
                  {sim.totalLoanDeduction    > 0 && <BLine label="Prêts"   value={`−${fmt(sim.totalLoanDeduction)} F`}    cls="text-red-500" sm />}
                  {sim.totalAdvanceDeduction > 0 && <BLine label="Avances" value={`−${fmt(sim.totalAdvanceDeduction)} F`} cls="text-red-500" sm />}
                  {(sim as any).manualDeductionTotal > 0 && <BLine label="Autres retenues" value={`−${fmt((sim as any).manualDeductionTotal)} F`} cls="text-red-500" sm />}

                  <div className="mt-4 pt-4 border-t-2 border-dashed border-gray-200 dark:border-gray-700">
                    <div className="flex justify-between items-end">
                      <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Net à payer</span>
                      <div className="text-right leading-none">
                        <span className="text-[26px] font-black text-gray-900 dark:text-white font-mono tracking-tight">{fmt(sim.netSalary)}</span>
                        <span className="text-sm text-gray-400 ml-1">FCFA</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 border border-amber-200 dark:border-amber-800/40 rounded-xl overflow-hidden">
                    <button onClick={() => setShowEmpCost(v => !v)}
                      className="w-full flex items-center justify-between px-4 py-2.5 bg-amber-50 dark:bg-amber-900/20 hover:bg-amber-100/50 transition-colors">
                      <span className="flex items-center gap-1.5 text-xs font-bold text-amber-700 dark:text-amber-400">
                        <Building2 size={12} /> Coût employeur
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-sm text-amber-600 dark:text-amber-400">+{fmt(sim.totalEmployerCost)} F</span>
                        {showEmpCost ? <ChevronUp size={12} className="text-amber-400"/> : <ChevronDown size={12} className="text-amber-400"/>}
                      </div>
                    </button>
                    <AnimatePresence>
                      {showEmpCost && (
                        <motion.div initial={{ height:0 }} animate={{ height:'auto' }} exit={{ height:0 }} className="overflow-hidden">
                          <div className="px-4 py-3 bg-[var(--surface)] space-y-0.5">
                            <BLine label="CNSS Pensions (8%)"    value={`+${fmt(sim.cnssEmployerPension)} F`}  cls="text-amber-500" sm />
                            <BLine label="CNSS Famille (10,03%)" value={`+${fmt(sim.cnssEmployerFamily)} F`}   cls="text-amber-500" sm />
                            <BLine label="CNSS Accident (2,25%)" value={`+${fmt(sim.cnssEmployerAccident)} F`} cls="text-amber-500" sm />
                            <BLine label="TUS DGI (2,025%)"      value={`+${fmt(sim.tusDgiAmount)} F`}         cls="text-amber-500"  sm />
                            <BLine label="TUS CNSS (5,475%)"     value={`+${fmt(sim.tusCnssAmount)} F`}        cls="text-amber-500"  sm />
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                <div className="px-5 pb-5">
                  <button onClick={submit} disabled={submitting || simLoading}
                    className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100 text-sm">
                    {submitting ? <><Loader2 size={15} className="animate-spin"/>Enregistrement…</> : <><CheckCircle2 size={15}/>Confirmer & créer le bulletin</>}
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div key="empty" initial={{ opacity:0 }} animate={{ opacity:1 }}
                className="bg-gray-50 dark:bg-gray-800/50 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-2xl min-h-[260px] flex flex-col items-center justify-center text-center p-8">
                {simLoading
                  ? <><Loader2 size={32} className="animate-spin mb-3 text-emerald-500"/><p className="text-sm font-medium text-gray-600 dark:text-gray-300">Calcul en cours…</p></>
                  : simError
                  ? <><AlertCircle size={32} className="mb-3 text-red-400"/><p className="text-sm font-medium text-red-500 max-w-[200px]">{simError}</p></>
                  : <><Calculator size={36} className="mb-3 text-gray-300 dark:text-gray-600"/><p className="text-sm font-semibold text-gray-500 dark:text-gray-400">{!selectedEmp?'Sélectionnez un employé':!empDetail?'Chargement…':'Le bulletin se calcule automatiquement'}</p><p className="text-xs text-gray-400 mt-1">Mis à jour en temps réel</p></>
                }
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Modal succès */}
      <AnimatePresence>
        {success && (
          <motion.div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" initial={{ opacity:0 }} animate={{ opacity:1 }}>
            <motion.div initial={{ opacity:0, scale:0.9, y:20 }} animate={{ opacity:1, scale:1, y:0 }} transition={{ type:'spring', stiffness:300, damping:26 }}
              className="bg-white dark:bg-gray-800 rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto mb-5">
                <CheckCircle2 size={34} className="text-emerald-500" />
              </div>
              <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-2">Bulletin créé !</h2>
              <p className="text-gray-400 text-sm mb-7">La fiche de paie a été enregistrée avec succès.</p>
              <div className="flex gap-3">
                <button onClick={resetPage} className="flex-1 py-3 border border-gray-200 dark:border-gray-700 rounded-xl font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm">Nouveau</button>
                {createdId && <button onClick={() => router.push(`/paie/${createdId}`)} className="flex-1 py-3 bg-emerald-500 text-white font-bold rounded-xl hover:bg-emerald-600 transition-colors text-sm">Voir bulletin</button>}
                <button onClick={() => router.push('/paie')} className="flex-1 py-3 bg-emerald-500 text-white font-bold rounded-xl hover:bg-emerald-600 transition-colors text-sm">Liste paie</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}