'use client';

import { localDateKey, attendanceCutoff } from '@/lib/attendance-calendar';

// ============================================================================
// 📁 app/(dashboard)/presences/DailyView.tsx
// ✅ v2 : fichier nettoyé (l'ancien bloc commenté a été retiré), clic sur une
//    ligne = sidebar de détail employé, emojis remplacés par des icônes
//    lucide, bouton "Rapport imprimable" (impression + PDF, en-tête entreprise).
// ============================================================================

import React, { useState, useEffect } from 'react';
import {
  Users, UserCheck, UserX, Timer, MapPin, Calendar, ChevronLeft,
  ChevronRight, Search, CalendarOff, Inbox, Printer, Download, Loader2,
  Trash2, Coffee, Pencil,
} from 'lucide-react';
import { api } from '@/services/api';
import { attendanceApi } from '@/services/attendance-api';
import EmployeeDayDetailSidebar, { EmployeeDayDetail } from '@/components/EmployeeDayDetailSidebar';
import { PUNCH_METHOD_LABEL, summaryPunchMethod } from '@/lib/punch-method';
import BreakCorrectionModal from '@/components/BreakCorrectionModal';
import DailyAttendanceReportPrintable from '@/components/DailyAttendanceReportPrintable';
import { printReport, downloadReportPDF } from '@/lib/report-print';
import { isWorkDay } from '@/lib/work-days';
import { KonzaLoader } from '@/components/ui/KonzaLoader';

interface DailyViewProps {
  selectedDate: Date;
  setSelectedDate: (date: Date) => void;
  userRole: string;
  userDepartment: string;
  canRecordAttendanceForAll?: boolean; // 🆕 permission "secrétaire" : pointage manuel pour tout le monde
}

// 🆕 Badge « méthode de pointage » (traçabilité admin). SECRET_CODE en orange :
// c'est la seule méthode qui n'identifie pas la personne physiquement.
// Une seule méthode est affichée (entrée d'abord, QR prioritaire — voir lib/punch-method.ts) ;
// le détail entrée / sortie est dans le panneau qui s'ouvre au clic sur la ligne.
function PunchMethodBadge({ att }: { att: any }) {
  const method = summaryPunchMethod(att.checkInMethod, att.checkOutMethod);
  if (!method) return <span className="text-[var(--text-muted)]">-</span>;
  const warn = method === 'SECRET_CODE';
  return (
    <span
      title={`Entrée : ${PUNCH_METHOD_LABEL[att.checkInMethod] || '—'} · Sortie : ${PUNCH_METHOD_LABEL[att.checkOutMethod] || '—'}`}
      className={`inline-block px-2 py-0.5 rounded-full font-semibold ${
        warn ? 'bg-amber-500/15 text-amber-600' : 'bg-[var(--surface-2)] text-[var(--text-muted)]'
      }`}
    >
      {PUNCH_METHOD_LABEL[method] || method}
    </span>
  );
}

export default function DailyView({
  selectedDate,
  setSelectedDate,
  userRole,
  userDepartment,
  canRecordAttendanceForAll = false,
}: DailyViewProps) {
  const [data, setData] = useState<any>(null);
  const [company, setCompany] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [departmentFilter, setDepartmentFilter] = useState('ALL');
  // ✅ Suppression réservée aux admins + RH manager — le backend applique la
  // même règle (RolesGuard), ceci n'est qu'un affichage conditionnel côté UI.
  const isAdmin = ['ADMIN', 'HR_MANAGER', 'SUPER_ADMIN'].includes(userRole);
  const [breakEditId, setBreakEditId] = useState<string | null>(null); // 🆕 correction de pause
  const [deletingId, setDeletingId] = useState<string | null>(null);
  // ✅ Modifier les heures d'entrée / sortie d'un pointage (mêmes rôles que la suppression)
  const [timesRow, setTimesRow] = useState<any | null>(null);
  const [timesForm, setTimesForm] = useState({ checkIn: '', checkOut: '', breakStart: '', breakEnd: '', removeBreak: false, reason: '' });
  const [timesSaving, setTimesSaving] = useState(false);
  const [timesError, setTimesError] = useState('');
  const [selectedRow, setSelectedRow] = useState<EmployeeDayDetail | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const [companySettings, setCompanySettings] = useState({
    officialStartHour: 8,
    officialStartMinute: 0,
    lateToleranceMinutes: 0,
    workDays: [1, 2, 3, 4, 5],
  });

  useEffect(() => {
    (async () => {
      try {
        const res: any = await api.get('/payroll-settings');
        setCompanySettings({
          officialStartHour: res.officialStartHour ?? 8,
          officialStartMinute: res.officialStartMinute ?? 0,
          lateToleranceMinutes: res.lateToleranceMinutes || 0,
          workDays: res.workDays || [1, 2, 3, 4, 5],
        });
      } catch (e) {
        console.error('Erreur settings:', e);
      }
      try {
        const me: any = await api.get('/auth/me');
        setCompany(me?.company ?? null);
      } catch {}
    })();
  }, []);

  useEffect(() => {
    fetchDailyData();
  }, [selectedDate]);

  const fetchDailyData = async () => {
    setIsLoading(true);
    try {
      // Le backend filtre déjà par département si MANAGER — pas besoin de filtre ici
      const res: any = await api.get(`/attendance?month=${selectedDate.getMonth() + 1}&year=${selectedDate.getFullYear()}`);
      setData(res);
    } catch (e) {
      console.error(e);
      setData(null);
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (date: Date) =>
    date.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  const formatTime = (dateString?: string) =>
    dateString ? new Date(dateString).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '-';

  // ✅ Suppression d'un pointage — définitive, un motif est obligatoire
  // (le backend le revérifie de toute façon). On demande confirmation +
  // motif via deux petites invites plutôt qu'une modale dédiée, pour rester
  // simple ; à remplacer par une vraie modale si besoin plus tard.
  const handleDeleteAttendance = async (attendanceId: string, employeeName: string) => {
    const reason = window.prompt(
      `Suppression définitive du pointage de ${employeeName}.\n\nMotif de la suppression (obligatoire) :`
    );
    if (reason === null) return; // annulé
    if (reason.trim().length < 3) {
      alert('Motif trop court (3 caractères minimum).');
      return;
    }
    if (!window.confirm(`Confirmer la suppression définitive ? Cette action est irréversible.`)) return;

    setDeletingId(attendanceId);
    try {
      await attendanceApi.deleteAttendance(attendanceId, reason.trim());
      await fetchDailyData();
    } catch (e: any) {
      alert(e.message || 'Erreur lors de la suppression.');
    } finally {
      setDeletingId(null);
    }
  };

  const toHHMM = (iso?: string | null) =>
    iso ? new Date(iso).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '';

  const openTimesModal = (att: any) => {
    setTimesError('');
    setTimesRow(att);
    setTimesForm({
      checkIn: toHHMM(att.checkIn),
      checkOut: toHHMM(att.checkOut),
      breakStart: toHHMM(att.pause?.startedAt),
      breakEnd: toHHMM(att.pause?.endedAt),
      removeBreak: false,
      reason: '',
    });
  };

  // Garde le jour d'origine du pointage, ne remplace que l'heure.
  const withTime = (baseIso: string, hhmm: string) => {
    const [h, m] = hhmm.split(':').map(Number);
    const d = new Date(baseIso);
    d.setHours(h, m, 0, 0);
    return d.toISOString();
  };

  // Place une heure « HH:MM » après `refIso` : même jour, ou le lendemain si l'heure est
  // plus petite (service qui passe minuit).
  const timeAfter = (refIso: string, hhmm: string) => {
    const ref = new Date(refIso);
    const d = new Date(withTime(refIso, hhmm));
    if (d.getTime() < ref.getTime()) d.setDate(d.getDate() + 1);
    return d;
  };

  // Valeurs effectives du formulaire (entrée / sortie / pause) — utilisées par l'aperçu ET l'enregistrement
  const computeTimes = () => {
    if (!timesRow) return null;
    const base = timesRow.checkIn || timesRow.checkOut;
    if (!base) return null;
    const inChanged = !!timesForm.checkIn && timesForm.checkIn !== toHHMM(timesRow.checkIn);
    const outChanged = !!timesForm.checkOut && timesForm.checkOut !== toHHMM(timesRow.checkOut);
    const effIn: string | null = inChanged
      ? withTime(timesRow.checkIn || base, timesForm.checkIn)
      : (timesRow.checkIn ?? null);
    const effOut: string | null = outChanged
      ? (timesRow.checkOut
          ? withTime(timesRow.checkOut, timesForm.checkOut)
          : timeAfter(effIn || base, timesForm.checkOut).toISOString())
      : (timesRow.checkOut ?? null);

    const pz = timesRow.pause;
    const pauseTouched =
      timesForm.breakStart !== toHHMM(pz?.startedAt) || timesForm.breakEnd !== toHHMM(pz?.endedAt);
    let bs: Date | null = null;
    let be: Date | null = null;
    if (!timesForm.removeBreak && timesForm.breakStart && timesForm.breakEnd) {
      bs = timeAfter(effIn || base, timesForm.breakStart);
      be = timeAfter(bs.toISOString(), timesForm.breakEnd);
    }
    // Minutes de pause retenues pour l'aperçu
    let pauseMinutes = 0;
    if (timesForm.removeBreak) pauseMinutes = 0;
    else if (bs && be) pauseMinutes = Math.round((be.getTime() - bs.getTime()) / 60_000);
    else pauseMinutes = Number(pz?.minutes ?? timesRow.breakMinutes ?? 0);

    return { inChanged, outChanged, effIn, effOut, bs, be, pauseTouched, pauseMinutes };
  };

  const fmtDur = (min: number) => `${Math.floor(min / 60)}h${String(Math.round(min % 60)).padStart(2, '0')}`;

  const saveTimes = async () => {
    if (!timesRow) return;
    if (!timesForm.checkIn && !timesForm.checkOut) { setTimesError('Renseignez au moins une heure.'); return; }
    if (timesForm.reason.trim().length < 3) { setTimesError('Motif obligatoire (3 caractères min.).'); return; }
    const t = computeTimes();
    if (!t) { setTimesError('Pointage sans date de référence.'); return; }
    const payload: any = { reason: timesForm.reason.trim() };
    if (t.inChanged && t.effIn) payload.checkIn = t.effIn;
    if (t.outChanged && t.effOut) payload.checkOut = t.effOut;

    // 🆕 Pause : insertion / modification / suppression
    if (timesForm.removeBreak) {
      if (timesRow.pause) payload.removeBreak = true;
    } else if (t.pauseTouched) {
      if (!timesForm.breakStart || !timesForm.breakEnd) {
        setTimesError('Renseignez le début ET la fin de la pause.');
        return;
      }
      if (t.bs && t.be) {
        payload.breakStart = t.bs.toISOString();
        payload.breakEnd = t.be.toISOString();
      }
    }

    if (!payload.checkIn && !payload.checkOut && !payload.breakStart && !payload.removeBreak) {
      setTimesError('Aucune modification.');
      return;
    }
    setTimesSaving(true);
    setTimesError('');
    try {
      await api.put(`/attendance/correct/${timesRow.id}`, payload);
      setTimesRow(null);
      await fetchDailyData();
    } catch (e: any) {
      setTimesError(e?.response?.data?.message || e?.message || 'Erreur lors de la modification.');
    } finally {
      setTimesSaving(false);
    }
  };

  const getStatusColor = (status: string) => {
    const colors: any = {
      PRESENT: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
      LATE: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
      ABSENT_UNPAID: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
      ABSENT_PAID: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
      REMOTE: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
      ON_LEAVE: 'bg-[var(--surface-2)] text-[var(--text-muted)]',
      LEAVE: 'bg-[var(--surface-2)] text-[var(--text-muted)]',
      HOLIDAY: 'bg-[var(--surface-2)] text-[var(--text-muted)]',
    };
    return colors[status] || 'bg-[var(--surface-2)] text-[var(--text-muted)]';
  };

  const getStatusLabel = (status: string) => {
    const labels: any = {
      PRESENT: 'Présent', LATE: 'Retard', ABSENT_UNPAID: 'Absent',
      ABSENT_PAID: 'Abs. Justifiée', REMOTE: 'Télétravail', ON_LEAVE: 'Congé',
      LEAVE: 'Congé', HOLIDAY: 'Férié', OFF_DAY: 'Repos',
    };
    return labels[status] || status;
  };

  const getDailyAttendances = () => {
    if (!data?.employees || !data?.dayStatuses) return [];

    const dateStr = localDateKey(selectedDate);
    const dailyData: any[] = [];

    // 🕐 Selon la CONFIGURATION de l'entreprise (0 = dimanche). Un jour non travaillé n'efface plus
    // les pointages : un employé qui a pointé ce jour-là doit apparaître.
    const isWorkingDay = isWorkDay(companySettings.workDays, selectedDate.getDay());

    const now = new Date();
    const absenceThreshold = attendanceCutoff(selectedDate, companySettings);

    const isToday = dateStr === localDateKey(now);
    const isBeforeWorkTime = isToday && now < absenceThreshold;

    // Le backend renvoie déjà uniquement les employés accessibles (filtré par département si MANAGER)
    data.employees.forEach((emp: any, empIndex: number) => {
      const empDayStatuses = data.dayStatuses[empIndex] || [];
      const dayStatus = empDayStatuses.find((ds: any) => ds.date === dateStr);

      if (!dayStatus || dayStatus.status === 'FUTURE') return;
      const worked = !!dayStatus.checkIn; // vrai pointage ce jour-là
      if (!worked) {
        // pas de pointage : on n'affiche que les jours travaillés normaux
        if (!isWorkingDay) return;
        if (dayStatus.status === 'HOLIDAY' || dayStatus.status === 'OFF_DAY') return;
        if (isBeforeWorkTime && dayStatus.status === 'ABSENT_UNPAID') return;
      }
      // Pointé un jour de repos / férié / pendant un congé : présent, avec une mention
      const restTag: string | null = !worked ? null
        : dayStatus.status === 'HOLIDAY' ? 'Jour férié travaillé'
        : dayStatus.status === 'OFF_DAY' ? 'Jour de repos travaillé'
        : dayStatus.leaveType ? 'Pointé pendant son congé'
        : null;

      // ✅ FIX : dayStatus ne porte pas l'id réel du pointage (le backend ne
      // l'expose pas dans dayStatuses). On va donc chercher le vrai
      // enregistrement — et son vrai UUID Prisma — dans data.attendances
      // (même source que CorrectionsView.tsx). Sans ça, "id" était fabriqué
      // en concaténant l'id employé + la date, une chaîne qui RESSEMBLE à un
      // UUID mais n'en est pas un → Prisma refusait la suppression
      // ("Error creating UUID, invalid group count: expected 5, found 8").
      const realAtt = data.attendances?.find(
        (a: any) => a.employeeId === emp.id && a.date?.split('T')[0] === dateStr
      );

      dailyData.push({
        // "id" = vrai UUID à supprimer, null si aucun pointage réel n'existe
        // (ex : statut calculé "ABSENT_UNPAID" sans ligne en base — rien à
        // supprimer dans ce cas, le bouton sera désactivé).
        id: realAtt?.id ?? null,
        // clé React stable, indépendante de l'existence d'un pointage réel
        rowKey: `${emp.id}-${dateStr}`,
        employee: emp,
        date: dateStr,
        status: worked && (dayStatus.status === 'HOLIDAY' || dayStatus.status === 'OFF_DAY') ? 'PRESENT' : dayStatus.status,
        restTag,
        checkIn: dayStatus.checkIn,
        checkOut: dayStatus.checkOut,
        totalHours: dayStatus.totalHours,
        overtime50: dayStatus.overtime50,
        // 🆕 Champs du VRAI pointage (dayStatus ne les porte pas) : sans eux, Méthode, Site, Pause
        // et « heures en plus » restaient toujours vides dans la liste et le panneau de détail.
        checkInMethod: realAtt?.checkInMethod ?? null,
        checkOutMethod: realAtt?.checkOutMethod ?? null,
        checkInSource: realAtt?.checkInSource ?? null,
        checkOutSource: realAtt?.checkOutSource ?? null,
        checkInSiteName: realAtt?.checkInSiteName ?? null,
        checkOutSiteName: realAtt?.checkOutSiteName ?? null,
        checkInDistance: realAtt?.checkInDistance ?? null,
        // 🆕 Sur quoi la zone a été validée (distance / marge GPS / wifi) — affiché dans le panneau de détail
        checkInGeo: realAtt?.checkInGeo ?? null,
        checkOutGeo: realAtt?.checkOutGeo ?? null,
        pause: realAtt?.pause ?? null,
        breakMinutes: realAtt?.breakMinutes ?? 0,
        extraHoursInfo: realAtt?.extraHoursInfo ?? null,
      });
    });

    return dailyData;
  };

  const calculateDailyStats = () => {
    const dailyAttendances = getDailyAttendances();
    const stats = { total: dailyAttendances.length, present: 0, late: 0, absent: 0, remote: 0, onLeave: 0 };

    dailyAttendances.forEach(att => {
      if (att.status === 'PRESENT') stats.present++;
      else if (att.status === 'LATE') stats.late++;
      else if (att.status === 'ABSENT_UNPAID') stats.absent++;
      else if (att.status === 'REMOTE') stats.remote++;
      else if (att.status === 'ON_LEAVE' || att.status === 'LEAVE') stats.onLeave++;
    });

    return stats;
  };

  const getFilteredAttendances = () => {
    let filtered = getDailyAttendances();

    if (searchTerm) {
      filtered = filtered.filter(att =>
        `${att.employee.firstName} ${att.employee.lastName}`.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    if (statusFilter !== 'ALL') filtered = filtered.filter(att => att.status === statusFilter);
    if (departmentFilter !== 'ALL' && (userRole !== 'MANAGER' || canRecordAttendanceForAll)) {
      filtered = filtered.filter(att => att.employee.department?.name === departmentFilter);
    }

    return filtered;
  };

  const uniqueDepartments = Array.from(
    new Set(getDailyAttendances().map(att => att.employee.department?.name).filter(Boolean))
  );

  const dailyStats = calculateDailyStats();
  const filteredAttendances = getFilteredAttendances();

  const isWorkingDay = isWorkDay(companySettings.workDays, selectedDate.getDay());

  const now = new Date();
  const dateStr = localDateKey(selectedDate);
  const isToday = dateStr === localDateKey(now);
  const absenceThreshold = attendanceCutoff(selectedDate, companySettings);
  const isBeforeWorkTime = isToday && now < absenceThreshold;

  const REPORT_ID = 'daily-attendance-report';

  const handleDownloadPdf = async () => {
    setIsExportingPdf(true);
    try {
      await downloadReportPDF(REPORT_ID, `rapport-journalier-${dateStr}.pdf`, 'landscape');
    } finally {
      setIsExportingPdf(false);
    }
  };

  if (isLoading) {
    return (
      <KonzaLoader variant="page" />
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-[var(--surface)] rounded-2xl p-6 border border-[var(--border)]">
        <div className="flex items-center justify-between gap-4">
          <button
            onClick={() => setSelectedDate(new Date(selectedDate.getTime() - 86400000))}
            className="p-3 hover:bg-[var(--surface-2)] rounded-xl transition-colors"
          >
            <ChevronLeft size={24} />
          </button>

          <div className="text-center flex-1">
            <h2 className="text-2xl font-bold text-[var(--text)] capitalize">
              {formatDate(selectedDate)}
            </h2>
            {userRole === 'MANAGER' && !canRecordAttendanceForAll && (
              <span className="text-xs text-emerald-500 font-bold mt-1 block">Votre département</span>
            )}
            <button
              onClick={() => setSelectedDate(new Date())}
              className="text-sm text-emerald-500 hover:text-emerald-600 font-medium mt-1"
            >
              Aujourd&apos;hui
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setTimeout(() => printReport(REPORT_ID), 50)}
              title="Imprimer le rapport"
              className="p-3 border border-[var(--border)] hover:bg-[var(--surface-2)] rounded-xl transition-colors text-[var(--text-muted)]"
            >
              <Printer size={20} />
            </button>
            <button
              onClick={handleDownloadPdf}
              disabled={isExportingPdf}
              title="Télécharger en PDF"
              className="p-3 border border-[var(--border)] hover:bg-[var(--surface-2)] rounded-xl transition-colors text-[var(--text-muted)] disabled:opacity-40"
            >
              {isExportingPdf ? <Loader2 size={20} className="animate-spin" /> : <Download size={20} />}
            </button>
            <button
              onClick={() => setSelectedDate(new Date(selectedDate.getTime() + 86400000))}
              className="p-3 hover:bg-[var(--surface-2)] rounded-xl transition-colors"
              disabled={selectedDate >= new Date()}
            >
              <ChevronRight size={24} />
            </button>
          </div>
        </div>
      </div>

      {!isWorkingDay && filteredAttendances.length === 0 && (
        <div className="bg-[var(--surface-2)] border border-[var(--border)] rounded-xl p-4 flex items-center gap-3">
          <Calendar size={24} className="text-emerald-500" />
          <p className="text-sm text-[var(--text-muted)]">
            <strong>Jour non ouvrable</strong> selon la configuration de l&apos;entreprise (jours configurés : {companySettings.workDays.map(d => ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'][d === 7 ? 0 : d]).join(', ')})
          </p>
        </div>
      )}

      {isBeforeWorkTime && isWorkingDay && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-4 flex items-center gap-3">
          <Timer size={24} className="text-amber-600 dark:text-amber-400" />
          <div className="flex-1">
            <p className="text-sm text-amber-700 dark:text-amber-300">
              <strong>Avant l&apos;heure de travail</strong>
            </p>
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
              Les absences seront comptabilisées à partir de {String(absenceThreshold.getHours()).padStart(2, '0')}h{String(absenceThreshold.getMinutes()).padStart(2, '0')}
            </p>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { label: 'Total', value: dailyStats.total, color: 'gray', Icon: Users },
          { label: 'Présents', value: dailyStats.present, color: 'emerald', Icon: UserCheck },
          { label: 'Retards', value: dailyStats.late, color: 'orange', Icon: Timer },
          { label: 'Absents', value: dailyStats.absent, color: 'red', Icon: UserX },
          { label: 'Remote', value: dailyStats.remote, color: 'purple', Icon: MapPin },
          { label: 'Congés', value: dailyStats.onLeave, color: 'sky', Icon: Calendar },
        ].map(({ label, value, color, Icon }) => (
          <div key={label} className="bg-[var(--surface)] rounded-xl p-4 border border-[var(--border)]">
            <div className="flex items-center gap-3">
              <div className={`p-2 bg-${color}-100 dark:bg-${color}-900/30 rounded-lg`}>
                <Icon size={20} className={`text-${color}-600 dark:text-${color}-400`} />
              </div>
              <div>
                <p className={`text-2xl font-bold text-${color}-600 dark:text-${color}-400`}>{value}</p>
                <p className="text-xs text-[var(--text-muted)]">{label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filtres */}
      <div className="bg-[var(--surface)] rounded-2xl p-4 border border-[var(--border)]">
        <div className="flex flex-wrap gap-3">
          <div className="flex-1 min-w-[200px]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-muted)]" size={20} />
              <input
                type="text"
                placeholder="Rechercher..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-[var(--border)] rounded-xl bg-[var(--surface)] text-[var(--text)] focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-[var(--border)] rounded-xl bg-[var(--surface)] text-[var(--text)]"
          >
            <option value="ALL">Tous statuts</option>
            <option value="PRESENT">Présents</option>
            <option value="LATE">Retards</option>
            <option value="ABSENT_UNPAID">Absents</option>
            <option value="REMOTE">Remote</option>
          </select>

          {(userRole !== 'MANAGER' || canRecordAttendanceForAll) && (
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="px-4 py-2 border border-[var(--border)] rounded-xl bg-[var(--surface)] text-[var(--text)]"
            >
              <option value="ALL">Tous dép.</option>
              {uniqueDepartments.map(dept => <option key={dept} value={dept}>{dept}</option>)}
            </select>
          )}
        </div>
      </div>

      {/* Tableau */}
      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[var(--surface-2)] border-b border-[var(--border)]">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-bold text-[var(--text-muted)] uppercase">Employé</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-[var(--text-muted)] uppercase">Département</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-[var(--text-muted)] uppercase">Statut</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-[var(--text-muted)] uppercase">Entrée</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-[var(--text-muted)] uppercase">Site</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-[var(--text-muted)] uppercase">Méthode</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-[var(--text-muted)] uppercase">Sortie</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-[var(--text-muted)] uppercase">Durée</th>
                {isAdmin && (
                  <th className="px-6 py-4 text-right text-xs font-bold text-[var(--text-muted)] uppercase">Actions</th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {filteredAttendances.length === 0 ? (
                <tr>
                  <td colSpan={isAdmin ? 9 : 8} className="px-6 py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      {!isWorkingDay ? (
                        <>
                          <CalendarOff size={36} className="text-[var(--text-muted)]" />
                          <p className="text-lg font-bold text-[var(--text-muted)]">Jour non ouvrable</p>
                          <p className="text-sm text-[var(--text-muted)]">Ce jour n&apos;est pas configuré comme jour de travail</p>
                        </>
                      ) : isBeforeWorkTime ? (
                        <>
                          <Timer size={36} className="text-[var(--text-muted)]" />
                          <p className="text-lg font-bold text-[var(--text-muted)]">Avant l&apos;heure de travail</p>
                          <p className="text-sm text-[var(--text-muted)]">Les absences seront comptabilisées à partir de {String(absenceThreshold.getHours()).padStart(2, '0')}h{String(absenceThreshold.getMinutes()).padStart(2, '0')}</p>
                        </>
                      ) : (
                        <>
                          <Inbox size={36} className="text-[var(--text-muted)]" />
                          <p className="text-lg font-bold text-[var(--text-muted)]">Aucun pointage</p>
                          <p className="text-sm text-[var(--text-muted)]">Aucune activité enregistrée ce jour-là</p>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredAttendances.map(att => (
                  <tr
                    key={att.rowKey}
                    onClick={() => setSelectedRow(att)}
                    className="hover:bg-[var(--surface-2)] transition-colors cursor-pointer"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center text-sm font-bold text-emerald-600 overflow-hidden shrink-0">
                          {att.employee.photoUrl
                            ? <img src={att.employee.photoUrl} className="w-full h-full object-cover" alt="" />
                            : `${att.employee.firstName[0]}${att.employee.lastName[0]}`}
                        </div>
                        <div>
                          <p className="font-bold text-[var(--text)]">{att.employee.firstName} {att.employee.lastName}</p>
                          <p className="text-xs text-[var(--text-muted)]">{att.employee.employeeNumber || '-'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-[var(--text-muted)]">{att.employee.department?.name || '-'}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(att.status)}`}>
                        {getStatusLabel(att.status)}
                      </span>
                      {(att as any).restTag && (
                        <span className="block mt-1 text-[10px] font-semibold text-amber-600">{(att as any).restTag}</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm font-mono text-[var(--text)]">{formatTime(att.checkIn)}</td>
                    <td className="px-6 py-4 text-sm text-[var(--text-muted)]">
                      {(att as any).checkInSiteName
                        ? <span className="inline-flex items-center gap-1">
                            <MapPin size={12} className="text-emerald-500" />
                            {(att as any).checkInSiteName}
                            {(att as any).checkInDistance != null && (
                              <span className="text-[var(--text-muted)]">({(att as any).checkInDistance}m)</span>
                            )}
                          </span>
                        : '-'}
                    </td>
                    <td className="px-6 py-4 text-xs">
                      <PunchMethodBadge att={att} />
                      {(att as any).pause && (() => {
                        const pz = (att as any).pause;
                        const hm = (x: string) => new Date(x).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
                        return (
                          <div className="mt-1 flex flex-wrap items-center gap-1 text-[11px] text-[var(--text-muted)]">
                            <Coffee size={11} />
                            <span>{hm(pz.startedAt)} → {pz.endedAt ? hm(pz.endedAt) : 'en cours'}{pz.minutes != null ? ` (${pz.minutes} min)` : ''}</span>
                            {pz.resumedAuto && <span className="text-amber-600 font-semibold" title="L'employé n'a pas pointé sa reprise : pause clôturée à la durée prévue">· reprise non pointée</span>}
                            {!pz.resumedAuto && pz.lateNotifiedAt && <span className="text-red-500 font-semibold">· retard {pz.lateMinutes} min</span>}
                            {pz.editedAt && <span title={pz.editReason || ''} className="text-sky-600">· corrigée</span>}
                            {isAdmin && (
                              <button type="button" title="Corriger la reprise" aria-label="Corriger la reprise de pause"
                                onClick={(e) => { e.stopPropagation(); setBreakEditId(att.id); }}
                                className="p-1 rounded hover:bg-[var(--surface-2)]"><Pencil size={11} /></button>
                            )}
                          </div>
                        );
                      })()}
                      {breakEditId === att.id && (att as any).pause && (
                        <BreakCorrectionModal
                          attendanceId={att.id}
                          pause={(att as any).pause}
                          onClose={() => setBreakEditId(null)}
                          onSaved={() => { setBreakEditId(null); fetchDailyData(); }}
                        />
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm font-mono text-[var(--text)]">
                      {formatTime(att.checkOut)}
                      {Number((att as any).extraHoursInfo) > 0 && (
                        <span
                          title="Heures au-delà de l'horaire — à titre informatif, non comptées dans la paie"
                          className="block text-[10px] font-sans font-semibold text-sky-600"
                        >
                          +{parseFloat(Number((att as any).extraHoursInfo).toFixed(2))} h (info)
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-[var(--text)]">{att.totalHours ? `${parseFloat(Number(att.totalHours).toFixed(2))}h` : '-'}</td>
                    {isAdmin && (
                      <td className="px-6 py-4 text-right">
                        {att.id ? (
                          <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); openTimesModal(att); }}
                            title="Modifier les heures d'entrée / sortie"
                            className="p-2 rounded-lg text-[var(--text-muted)] hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors"
                          >
                            <Pencil size={16} />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation(); // ne pas ouvrir la sidebar de détail
                              handleDeleteAttendance(att.id, `${att.employee.firstName} ${att.employee.lastName}`);
                            }}
                            disabled={deletingId === att.id}
                            title="Supprimer ce pointage (définitif)"
                            className="p-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors disabled:opacity-40"
                          >
                            {deletingId === att.id ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                          </button>
                          </div>
                        ) : (
                          // ✅ Pas de pointage réel en base pour ce statut calculé
                          // (ex : absence déduite, sans ligne "attendance") —
                          // rien à supprimer, donc pas de bouton actionnable.
                          <span className="text-xs text-[var(--text-muted)]" title="Aucun pointage réel enregistré pour ce jour">—</span>
                        )}
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {timesRow && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-[var(--surface)] rounded-2xl shadow-xl w-full max-w-md p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-lg font-bold text-[var(--text)]">Modifier les heures</h2>
            <p className="text-sm text-[var(--text-muted)]">{timesRow.employee.firstName} {timesRow.employee.lastName}</p>
            <div className="grid grid-cols-2 gap-3">
              <label className="text-xs font-semibold text-[var(--text-muted)] space-y-1">
                Entrée
                <input type="time" value={timesForm.checkIn}
                  onChange={e => setTimesForm(f => ({ ...f, checkIn: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-sm text-[var(--text)]" />
              </label>
              <label className="text-xs font-semibold text-[var(--text-muted)] space-y-1">
                Sortie
                <input type="time" value={timesForm.checkOut}
                  onChange={e => setTimesForm(f => ({ ...f, checkOut: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-sm text-[var(--text)]" />
              </label>
            </div>
            {/* 🆕 Pause : ajouter / corriger / supprimer */}
            <div className="rounded-xl border border-[var(--border)] p-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[var(--text)] flex items-center gap-1"><Coffee size={12} /> Pause</span>
                {timesRow.pause && (
                  <button type="button"
                    onClick={() => setTimesForm(f => ({ ...f, removeBreak: !f.removeBreak }))}
                    className="text-[11px] font-semibold text-red-500 hover:underline">
                    {timesForm.removeBreak ? 'Annuler la suppression' : 'Supprimer la pause'}
                  </button>
                )}
              </div>
              <div className={`grid grid-cols-2 gap-3 ${timesForm.removeBreak ? 'opacity-40' : ''}`}>
                <label className="text-xs font-semibold text-[var(--text-muted)] space-y-1">
                  Début pause
                  <input type="time" value={timesForm.breakStart} disabled={timesForm.removeBreak}
                    onChange={e => setTimesForm(f => ({ ...f, breakStart: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-sm text-[var(--text)]" />
                </label>
                <label className="text-xs font-semibold text-[var(--text-muted)] space-y-1">
                  Fin pause
                  <input type="time" value={timesForm.breakEnd} disabled={timesForm.removeBreak}
                    onChange={e => setTimesForm(f => ({ ...f, breakEnd: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-sm text-[var(--text)]" />
                </label>
              </div>
              {!timesRow.pause && !timesForm.breakStart && !timesForm.breakEnd && (
                <p className="text-[11px] text-[var(--text-muted)]">Aucune pause pointée. Renseignez début et fin pour l'ajouter.</p>
              )}
            </div>

            {(() => {
              const t = computeTimes();
              if (!t?.effIn || !t?.effOut) return null;
              const gross = (new Date(t.effOut).getTime() - new Date(t.effIn).getTime()) / 60_000;
              if (gross <= 0) return null;
              const net = Math.max(0, gross - t.pauseMinutes);
              return (
                <div className="rounded-xl bg-[var(--surface-2)] p-3 text-xs space-y-1">
                  <div className="flex justify-between text-[var(--text-muted)]"><span>Présence (entrée → sortie)</span><span className="font-mono">{fmtDur(gross)}</span></div>
                  <div className="flex justify-between text-[var(--text-muted)]"><span>Pause</span><span className="font-mono">− {fmtDur(t.pauseMinutes)}</span></div>
                  <div className="flex justify-between font-bold text-[var(--text)] border-t border-[var(--border)] pt-1"><span>Temps réellement travaillé</span><span className="font-mono">{fmtDur(net)}</span></div>
                </div>
              );
            })()}

            <label className="block text-xs font-semibold text-[var(--text-muted)] space-y-1">
              Motif (obligatoire)
              <input type="text" value={timesForm.reason}
                onChange={e => setTimesForm(f => ({ ...f, reason: e.target.value }))}
                placeholder="Ex : oubli de pointer la sortie"
                className="w-full px-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-sm text-[var(--text)]" />
            </label>
            {timesError && <p className="text-sm text-red-500">{timesError}</p>}
            <div className="flex justify-end gap-2">
              <button onClick={() => setTimesRow(null)} className="px-4 py-2 text-sm font-semibold rounded-lg text-[var(--text-muted)] hover:bg-[var(--surface-2)]">Annuler</button>
              <button onClick={saveTimes} disabled={timesSaving}
                className="px-4 py-2 text-sm font-bold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-2 disabled:opacity-40">
                {timesSaving && <Loader2 size={14} className="animate-spin" />} Enregistrer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar de détail employé */}
      <EmployeeDayDetailSidebar
        open={!!selectedRow}
        onClose={() => setSelectedRow(null)}
        detail={selectedRow}
      />

      {/* Rapport imprimable — hors écran, généré depuis les données déjà chargées */}
      <div style={{ position: 'fixed', top: -99999, left: -99999 }}>
        <DailyAttendanceReportPrintable
          id={REPORT_ID}
          company={company || {}}
          dateLabel={formatDate(selectedDate)}
          rows={filteredAttendances}
          stats={dailyStats}
        />
      </div>
    </div>
  );
}
