'use client';

// ============================================================================
// 📁 app/(dashboard)/presences/absences/nouveau/page.tsx
// ✅ Espace employé — création d'une demande d'autorisation d'absence
// ✅ Aperçu imprimable en direct (AbsenceRequestPrintable) — "effet waou"
//    demandé : l'employé voit exactement le document qui partira au dossier.
// ============================================================================

import { usesStandardData } from '@/lib/document-template';
import React, { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Stethoscope, Sparkles, Calendar, Send, Loader2,
  Paperclip, CheckCircle2, ArrowLeft, Wallet, Info, Search, Eye, EyeOff,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { api } from '@/services/api';
import { useBasePath } from '@/hooks/useBasePath';
import { useImageUpload } from '@/hooks/useImageUpload';
import AbsenceRequestPrintable from '@/components/AbsenceRequestPrintable';
import { AbsenceRequestDocument } from '@/components/documents/RequestDocuments';
import PresenceModuleSwitcher from '@/components/PresenceModuleSwitcher';
import AbsenceSubNav from '@/components/AbsenceSubNav';
import AbsenceCeilingBalance, { type CeilingBalance } from '@/components/absences/AbsenceCeilingBalance';

const APPROVER_ROLES = ['ADMIN', 'SUPER_ADMIN', 'HR_MANAGER'];

type AbsenceType = 'CONVENTIONNELLE' | 'EXCEPTIONNELLE';
type AbsenceSubType = 'MALADIE' | 'MATERNITE' | 'PATERNITE' | 'MARIAGE' | 'DECES' | 'NAISSANCE' | 'AUTRE';

const TYPE_OPTIONS: Array<{ value: AbsenceType; label: string; icon: any; hint: string }> = [
  { value: 'CONVENTIONNELLE', label: 'Conventionnelle', icon: Stethoscope, hint: 'Maladie, maternité, paternité' },
  { value: 'EXCEPTIONNELLE',  label: 'Exceptionnelle',  icon: Sparkles,    hint: 'Mariage, décès, naissance, autre' },
];

const SUBTYPE_OPTIONS: Record<AbsenceType, Array<{ value: AbsenceSubType; label: string }>> = {
  CONVENTIONNELLE: [
    { value: 'MALADIE',   label: 'Maladie' },
    { value: 'MATERNITE', label: 'Maternité' },
    { value: 'PATERNITE', label: 'Paternité' },
    { value: 'AUTRE',     label: 'Autre' },
  ],
  EXCEPTIONNELLE: [
    { value: 'MARIAGE',   label: 'Mariage' },
    { value: 'DECES',     label: 'Décès' },
    { value: 'NAISSANCE', label: 'Naissance' },
    { value: 'AUTRE',     label: 'Autre' },
  ],
};

export default function NouvelleAbsencePage() {
  const router = useRouter();
  const { bp } = useBasePath();

  const [employee, setEmployee] = useState<any>(null);
  const [company, setCompany]   = useState<any>(null);
  const [userRole, setUserRole] = useState('');

  const [employeesList, setEmployeesList] = useState<any[]>([]);
  const [employeeSearch, setEmployeeSearch] = useState('');
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [onBehalf, setOnBehalf] = useState(false);
  const isApprover = APPROVER_ROLES.includes(userRole);

  const [type, setType]           = useState<AbsenceType>('CONVENTIONNELLE');
  const [subType, setSubType]     = useState<AbsenceSubType>('MALADIE');
  const [startDate, setStartDate] = useState('');
  const [returnDate, setReturnDate] = useState(''); // jour de REPRISE (l'absence court jusqu'à la veille)
  const [startShiftNote, setStartShiftNote] = useState(''); // départ décalé (jour non travaillé / férié)
  const shiftStart = (from: string, to: string) => {
    const f = (d: string) => new Date(d).toLocaleDateString('fr-FR', { timeZone: 'UTC' });
    setStartShiftNote(`Le ${f(from)} n'est pas travaillé : départ au ${f(to)}.`);
    setStartDate(to);
  };
  const [reason, setReason]       = useState('');
  const [isPaid, setIsPaid]       = useState(true); // payée par défaut — la RH tranche à la validation

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDone, setIsDone]             = useState(false);
  const [error, setError]               = useState<string | null>(null);
  const [showPreview, setShowPreview]   = useState(false);
  const [returnCalc, setReturnCalc] = useState<any>(null);
  const [desiredDays, setDesiredDays] = useState('');
  const [isCalculatingReturn, setIsCalculatingReturn] = useState(false);
  const [coverage, setCoverage] = useState<any>(null); // jours justifiés / au-delà du droit

  // ✅ Modèle STANDARD : catalogue de motifs conventionnels propre à
  // l'entreprise, avec un nombre de jours fixe (remplace le choix
  // type/sous-type/raison libre + double date de la version DEFAULT).
  const isStandard = usesStandardData(company?.documentTemplate);
  const [motifCatalog, setMotifCatalog] = useState<any[]>([]);
  const [selectedMotifKey, setSelectedMotifKey] = useState('');
  // 🆕 Motif « Autre » : hors catalogue, motif saisi librement ; la RH tranche payé / non payé.
  const OTHER_KEY = '__AUTRE__';
  const isOther = isStandard && selectedMotifKey === OTHER_KEY;
  // Choix payé / non payé — réservé au RH qui crée la demande pour un employé (null = pas encore choisi)
  const [paidChoice, setPaidChoice] = useState<boolean | null>(null);

  useEffect(() => {
    if (!isStandard) return;
    (async () => {
      try {
        const list: any = await api.get('/absence-requests/motifs');
        setMotifCatalog(list || []);
      } catch (e) { console.error('Erreur chargement catalogue de motifs', e); }
    })();
  }, [isStandard]);

  const selectedMotif = motifCatalog.find(m => m.key === selectedMotifKey);

  // 🆕 Solde du plafond annuel de permissions exceptionnelles (par année civile,
  // année de la date de départ). Un RH/Admin n'est jamais bloqué.
  const [ceilingBalance, setCeilingBalance] = useState<CeilingBalance | null>(null);
  const ceilingYear = startDate ? Number(startDate.slice(0, 4)) : new Date().getFullYear();
  const ceilingRemaining = ceilingBalance?.remaining ?? null;
  const motifExceeds = (days: number) => !isApprover && ceilingRemaining != null && days > ceilingRemaining;
  const ceilingBlocks = !isOther && !!selectedMotif && motifExceeds(selectedMotif.days);
  useEffect(() => {
    if (!onBehalf) return;
    (async () => {
      try {
        const list: any = await api.get('/employees/simple');
        setEmployeesList(list || []);
      } catch (e) { console.error('Erreur chargement employés', e); }
    })();
  }, [onBehalf]);

  const filteredEmployees = useMemo(() => {
    if (!employeeSearch.trim()) return employeesList.slice(0, 30);
    const q = employeeSearch.toLowerCase();
    return employeesList.filter(e => `${e.firstName} ${e.lastName}`.toLowerCase().includes(q)).slice(0, 30);
  }, [employeesList, employeeSearch]);

  const selectedTargetEmployee = onBehalf ? employeesList.find(e => e.id === selectedEmployeeId) : employee;

  const handleCalculateReturn = async (daysOverride?: number) => {
    const days = daysOverride ?? parseFloat(desiredDays);
    if (!selectedTargetEmployee?.id || !startDate || !days) return;
    setIsCalculatingReturn(true);
    try {
      const result: any = await api.get(
        `/absence-requests/calculate-return-date?employeeId=${selectedTargetEmployee.id}&startDate=${startDate}&days=${days}`,
      );
      if (result?.startAdjusted && typeof result.startDate === 'string') shiftStart(startDate, result.startDate.slice(0, 10));
      // returnDate = prochain jour OUVRABLE après le dernier jour d'absence
      const rd = typeof result?.returnDate === 'string' ? result.returnDate.slice(0, 10) : '';
      setReturnDate(/^\d{4}-\d{2}-\d{2}$/.test(rd) ? rd : '');
      setReturnCalc(result);
    } catch (e: any) {
      alert(e?.message || "Erreur lors du calcul de la date de retour");
    } finally {
      setIsCalculatingReturn(false);
    }
  };

  // Standard : le motif choisi fixe la valeur PAR DÉFAUT (droit conventionnel).
  // On pré-remplit le nombre de jours et la date de reprise ; l'employé peut
  // ensuite changer le nombre de jours ou saisir sa date de reprise à la main.
  useEffect(() => {
    if (!isStandard || !selectedMotif) {
      if (isOther) { setDesiredDays(''); setReturnCalc(null); }
      return;
    }
    setDesiredDays(String(selectedMotif.days));
    setReturnCalc(null);
    if (startDate && selectedTargetEmployee?.id) handleCalculateReturn(selectedMotif.days);
    else setReturnDate('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMotifKey, startDate, selectedTargetEmployee?.id, isStandard]);

  // Aperçu de couverture (jours justifiés vs au-delà du droit) — recalculé à chaque changement
  useEffect(() => {
    if (!startDate || !returnDate || returnDate <= startDate) { setCoverage(null); return; }
    let cancelled = false;
    (async () => {
      try {
        const q = new URLSearchParams({ startDate, returnDate });
        if (isStandard && selectedMotifKey) q.set('motifKey', selectedMotifKey);
        const r: any = await api.get(`/absence-requests/coverage-preview?${q.toString()}`);
        if (!cancelled) {
          if (r?.startAdjusted && typeof r.startDate === 'string') shiftStart(startDate, r.startDate.slice(0, 10));
          setCoverage(r);
        }
      } catch { if (!cancelled) setCoverage(null); }
    })();
    return () => { cancelled = true; };
  }, [startDate, returnDate, selectedMotifKey, isStandard]);

  // Dernier jour d'absence = veille de la reprise (sert à l'aperçu imprimable)
  const lastAbsenceDate = useMemo(() => {
    if (!returnDate) return '';
    const d = new Date(returnDate);
    if (isNaN(d.getTime())) return '';
    d.setUTCDate(d.getUTCDate() - 1);
    return d.toISOString().slice(0, 10);
  }, [returnDate]);

  const { uploadedUrl, uploading, preview, handleFileSelect } = useImageUpload({ folder: 'absences' });

  useEffect(() => {
    try {
      const stored = localStorage.getItem('user');
      if (stored) setUserRole(JSON.parse(stored).role || '');
    } catch {}
    (async () => {
      try {
        const emp: any = await api.get('/employees/me');
        setEmployee(emp);
      } catch (e) {
        console.error('Erreur chargement profil employé', e);
      }
      try {
        const me: any = await api.get('/auth/me');
        setCompany(me?.company ?? null);
      } catch {}
    })();
  }, []);

  const handleTypeChange = (t: AbsenceType) => {
    setType(t);
    setSubType(SUBTYPE_OPTIONS[t][0].value);
  };

  const workingDays = coverage?.workingDays ?? 0;

  const canSubmit = isOther
    ? reason.trim().length >= 3 && !!startDate && !!returnDate && workingDays > 0
      && (!onBehalf || (!!selectedEmployeeId && paidChoice !== null)) && !isSubmitting
    : isStandard
    ? !!selectedMotifKey && !!startDate && !!returnDate && workingDays > 0 && (!onBehalf || !!selectedEmployeeId) && !ceilingBlocks && !isSubmitting
    : type && subType && startDate && returnDate && reason.trim().length >= 3 && workingDays > 0
      && (!onBehalf || !!selectedEmployeeId) && !isSubmitting;

  const handleSubmit = async () => {
    if (!canSubmit) return;
    setIsSubmitting(true);
    setError(null);
    try {
      await api.post('/absence-requests', isOther ? {
        // Motif « Autre » : hors catalogue — la RH décidera si la période est payée
        // (isPaid n'est envoyé que par un RH qui crée la demande pour un employé).
        employeeId: onBehalf ? selectedEmployeeId : undefined,
        type: 'EXCEPTIONNELLE',
        subType: 'AUTRE',
        startDate,
        returnDate,
        reason: reason.trim(),
        isPaid: onBehalf ? paidChoice! : undefined,
        attachmentUrl: uploadedUrl || undefined,
      } : isStandard ? {
        employeeId: onBehalf ? selectedEmployeeId : undefined,
        motifKey: selectedMotifKey,
        startDate,
        returnDate,
        isPaid,
        attachmentUrl: uploadedUrl || undefined,
      } : {
        employeeId: onBehalf ? selectedEmployeeId : undefined,
        type,
        subType,
        startDate,
        returnDate,
        reason: reason.trim(),
        isPaid,
        attachmentUrl: uploadedUrl || undefined,
      });
      setIsDone(true);
    } catch (e: any) {
      setError(e?.message || "Erreur lors de l'envoi de la demande");
    } finally {
      setIsSubmitting(false);
    }
  };

  const standardPreviewData = {
    company: {
      legalName: company?.legalName,
      tradeName: company?.tradeName,
      logo: company?.logo,
      address: company?.address,
      city: company?.city,
      country: company?.country,
      phone: company?.phone,
      email: company?.email,
      cachetUrl: company?.cachetUrl,
      documentFooterText: company?.documentFooterText,
    },
    employee: {
      firstName: selectedTargetEmployee?.firstName || '',
      lastName: selectedTargetEmployee?.lastName || '',
      employeeNumber: selectedTargetEmployee?.employeeNumber,
      position: selectedTargetEmployee?.position,
    },
    catalog: motifCatalog,
    motifKey: isOther ? undefined : (selectedMotifKey || undefined),
    otherReason: isOther ? (reason.trim() || '…') : undefined,
    startDate: startDate || new Date(),
    endDate: lastAbsenceDate || startDate || new Date(),
    returnDate: returnDate || undefined,
    workingDays: workingDays || undefined,
    status: 'PENDING',
    requestedAt: new Date(),
  };

  const previewData = {
    company: {
      legalName:  company?.legalName,
      tradeName:  company?.tradeName,
      logo:       company?.logo,
      rccmNumber: company?.rccmNumber,
      taxNumber:  company?.taxNumber,
      address:    company?.address,
      phone:      company?.phone,
      cachetUrl:  company?.cachetUrl,
    },
    employee: {
      firstName:       selectedTargetEmployee?.firstName || '',
      lastName:        selectedTargetEmployee?.lastName || '',
      position:        selectedTargetEmployee?.position,
      departmentName:  selectedTargetEmployee?.department?.name,
      responsableName: undefined,
    },
    type,
    subType,
    reason: reason || 'Motif de l\u2019absence…',
    isPaid,
    startDate: startDate || new Date(),
    endDate: lastAbsenceDate || new Date(),
    returnDate: returnDate || undefined,
    workingDays: workingDays || '—',
    hasAttachment: !!uploadedUrl,
    status: 'PENDING' as const,
    requestedAt: new Date(),
  };

  const fmt = (d?: string | null) => (d ? new Date(d).toLocaleDateString('fr-FR') : '');

  // Bloc "nombre de jours → date de reprise" (valeur par défaut = droit conventionnel en Standard)
  const calcBox = (
    <div className="bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-800 rounded-2xl p-4 space-y-3">
      <div>
        <label className="text-xs font-bold text-emerald-700 dark:text-emerald-300 uppercase tracking-wider block">
          {isStandard ? 'Nombre de jours & date de reprise' : 'Vous ne connaissez pas votre date de reprise ?'}
        </label>
        <p className="text-xs text-emerald-600/80 dark:text-emerald-400/80 mt-1">
          {isStandard
            ? "Par défaut, on prend les jours prévus par la convention pour ce motif. Vous pouvez changer le nombre de jours puis recalculer, ou saisir directement votre date de reprise plus bas. Les jours de repos de votre entreprise et les jours fériés ne sont pas comptés."
            : "Optionnel — indiquez le nombre de jours voulu, on calcule la date de reprise (jours de repos et jours fériés exclus). Sinon, saisissez directement la date de reprise plus bas."}
        </p>
      </div>
      <div className="flex gap-2">
        <input
          type="number" min="1" step="0.5"
          placeholder="Ex : 4 jours"
          value={desiredDays}
          onChange={e => setDesiredDays(e.target.value)}
          className="flex-1 px-3 py-2.5 rounded-xl border border-emerald-200 dark:border-emerald-700 bg-[var(--surface)] text-sm"
        />
        <button
          type="button"
          onClick={() => handleCalculateReturn()}
          disabled={isCalculatingReturn || !selectedTargetEmployee?.id || !startDate || !desiredDays}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold disabled:opacity-40 flex items-center gap-2 shrink-0"
        >
          {isCalculatingReturn ? <Loader2 size={16} className="animate-spin" /> : null}
          Calculer ma date de reprise
        </button>
      </div>
      {!startDate && <p className="text-xs text-emerald-600 dark:text-emerald-400">Renseignez d&apos;abord la date de départ.</p>}
      {returnCalc && (returnCalc.excludedHolidays?.length > 0 || returnCalc.sundaysSkipped > 0) && (
        <details className="text-xs text-emerald-600 dark:text-emerald-400">
          <summary className="cursor-pointer font-semibold">Détail du calcul (transparence)</summary>
          <div className="mt-2 space-y-1 pl-2">
            <p>{returnCalc.sundaysSkipped} jour(s) de repos exclu(s) de la période</p>
            {returnCalc.excludedHolidays?.length > 0 && (
              <>
                <p className="font-semibold mt-1">Jours fériés exclus :</p>
                {returnCalc.excludedHolidays.map((h: any) => (
                  <p key={h.date}>— {fmt(h.date)} : {h.name}</p>
                ))}
              </>
            )}
          </div>
        </details>
      )}
    </div>
  );

  // Saisie manuelle de la date de reprise (le jour où l'employé est attendu)
  const returnInput = (
    <div>
      <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5 block">Date de reprise</label>
      <div className="relative">
        <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
        <input type="date" min="2000-01-01" max="2100-12-31" value={returnDate} onChange={e => { setReturnDate(e.target.value); setReturnCalc(null); }} className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-sm" />
      </div>
    </div>
  );

  // Ce que le système va faire : jours justifiés vs jours au-delà du droit
  const coverageBox = coverage && returnDate && isOther ? (
    <div className="flex items-start gap-2 text-sm bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 px-3 py-2 rounded-lg">
      <Info size={14} className="mt-0.5 shrink-0" />
      <span>
        Reprise le <strong>{fmt(returnDate)}</strong> — <strong>{coverage.workingDays} jour{coverage.workingDays > 1 ? 's' : ''} ouvrable{coverage.workingDays > 1 ? 's' : ''}</strong> demandé{coverage.workingDays > 1 ? 's' : ''}.
        Ce motif n&apos;est pas prévu par la convention : les RH décideront si cette période est payée ou non.
      </span>
    </div>
  ) : coverage && returnDate ? (
    <div className="space-y-2">
      <div className="flex items-start gap-2 text-sm bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 px-3 py-2 rounded-lg">
        <Info size={14} className="mt-0.5 shrink-0" />
        <span>
          Reprise le <strong>{fmt(returnDate)}</strong> — <strong>{coverage.coveredDays} jour{coverage.coveredDays > 1 ? 's' : ''} justifié{coverage.coveredDays > 1 ? 's' : ''}</strong>
          {coverage.entitledDays != null ? ` (droit conventionnel : ${coverage.entitledDays} j.)` : ''}, sans déduction sur la paie
          {coverage.lastCoveredDate ? ` jusqu'au ${fmt(coverage.lastCoveredDate)}` : ''}.
        </span>
      </div>
      {coverage.uncoveredDays > 0 && (
        <div className="flex items-start gap-2 text-sm bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300 px-3 py-2 rounded-lg">
          <Info size={14} className="mt-0.5 shrink-0" />
          <span>
            {coverage.uncoveredDays} jour{coverage.uncoveredDays > 1 ? 's' : ''} au-delà du droit : non payé{coverage.uncoveredDays > 1 ? 's' : ''}.
            {' '}Ils ne comptent comme absence que si vous ne pointez pas ces jours-là. En cas de besoin, voyez avec les RH.
          </span>
        </div>
      )}
    </div>
  ) : null;

  if (isDone) {
    return (
      <div className="max-w-lg mx-auto py-24 text-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-20 h-20 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={40} />
        </motion.div>
        <h1 className="text-2xl font-bold text-[var(--text)] mb-2">Demande envoyée</h1>
        <p className="text-[var(--text-muted)] text-sm mb-8">
          {onBehalf
            ? "La demande d'autorisation d'absence a été enregistrée pour l'employé sélectionné."
            : "Votre demande d'autorisation d'absence a été transmise. Vous serez notifié dès qu'elle sera traitée."}
        </p>
        <div className="flex gap-3 justify-center">
          <button onClick={() => router.push(bp(onBehalf ? '/presences/absences' : '/presences/absences/mon-espace'))} className="px-5 py-2.5 bg-[var(--text)] text-[var(--bg)] rounded-xl font-semibold text-sm">
            {onBehalf ? 'Voir les demandes' : 'Voir mes demandes'}
          </button>
          <button onClick={() => { setIsDone(false); setStartDate(''); setReturnDate(''); setCoverage(null); setReturnCalc(null); setReason(''); setPaidChoice(null); }} className="px-5 py-2.5 border border-[var(--border)] rounded-xl font-semibold text-sm text-[var(--text-muted)]">
            Nouvelle demande
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[1400px] mx-auto pb-24 space-y-6">
      <PresenceModuleSwitcher />
      <AbsenceSubNav userRole={userRole} />

      <div className="flex items-center gap-3">
        <button onClick={() => router.push(bp('/presences/absences'))} className="p-2 rounded-xl border border-[var(--border)] hover:bg-[var(--surface-2)]">
          <ArrowLeft size={18} />
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-[var(--text)]">Nouvelle demande d&apos;absence</h1>
          <p className="text-[var(--text-muted)] text-sm">Remplissez le formulaire{showPreview ? ' — l\u2019aperçu à droite se met à jour en direct' : ''}</p>
        </div>
        <button
          onClick={() => setShowPreview(s => !s)}
          className={`px-4 py-2.5 rounded-xl font-semibold text-sm flex items-center gap-2 shrink-0 border transition-colors ${
            showPreview
              ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
              : 'border-[var(--border)] text-[var(--text-muted)] hover:bg-[var(--surface-2)]'
          }`}
        >
          {showPreview ? <EyeOff size={16} /> : <Eye size={16} />}
          {showPreview ? "Masquer l'aperçu" : "Voir l'aperçu"}
        </button>
      </div>

      <div className={`grid grid-cols-1 ${showPreview ? 'xl:grid-cols-5' : ''} gap-6`}>
        {/* ── FORMULAIRE ── */}
        <div className={`${showPreview ? 'xl:col-span-2' : 'max-w-2xl mx-auto w-full'} space-y-5`}>

          {isApprover && (
            <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
              <div className="flex items-center justify-between mb-3">
                <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider">Pour qui ?</label>
                <button
                  onClick={() => { setOnBehalf(!onBehalf); setSelectedEmployeeId(''); }}
                  className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${onBehalf ? 'bg-emerald-500' : 'bg-[var(--border)]'}`}
                >
                  <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-all ${onBehalf ? 'left-5' : 'left-0.5'}`} />
                </button>
              </div>
              {!onBehalf ? (
                <p className="text-sm text-[var(--text-muted)]">Pour moi-même</p>
              ) : (
                <div className="space-y-2">
                  <div className="relative">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                    <input value={employeeSearch} onChange={e => setEmployeeSearch(e.target.value)} placeholder="Rechercher un employé…" className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-sm" />
                  </div>
                  <div className="max-h-40 overflow-y-auto space-y-1">
                    {filteredEmployees.map(e => (
                      <button
                        key={e.id}
                        onClick={() => setSelectedEmployeeId(e.id)}
                        className={`w-full text-left px-3 py-2 rounded-lg text-sm flex items-center justify-between ${selectedEmployeeId === e.id ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 font-semibold' : 'hover:bg-[var(--surface-2)]'}`}
                      >
                        {e.firstName} {e.lastName}
                        {e.department?.name && <span className="text-xs text-[var(--text-muted)]">{e.department.name}</span>}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {isStandard ? (
            <>
              <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
                <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-3 block">Motif de l&apos;absence</label>
                <p className="text-xs text-[var(--text-muted)] mb-3">Le nombre de jours conventionnels est pris par défaut ; vous pouvez ensuite ajuster votre date de reprise.</p>
                {(!onBehalf || selectedEmployeeId) && (
                  <AbsenceCeilingBalance
                    employeeId={onBehalf ? selectedEmployeeId : undefined}
                    year={ceilingYear}
                    onLoaded={setCeilingBalance}
                    className="mb-3"
                  />
                )}
                {ceilingBlocks && selectedMotif && ceilingRemaining != null && (
                  <div className="flex items-start gap-2 text-sm bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 px-3 py-2 rounded-lg mb-3">
                    <Info size={14} className="mt-0.5 shrink-0" />
                    <span>
                      Ce motif ({selectedMotif.days} j.) dépasse votre solde de <strong>{Math.max(0, ceilingRemaining)} j.</strong> pour {ceilingYear} :
                      la demande serait refusée. Choisissez un autre motif ou une date de départ dans une autre année.
                    </span>
                  </div>
                )}
                {isApprover && selectedMotif && !isOther && ceilingRemaining != null && selectedMotif.days > ceilingRemaining && (
                  <div className="flex items-start gap-2 text-sm bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300 px-3 py-2 rounded-lg mb-3">
                    <Info size={14} className="mt-0.5 shrink-0" />
                    <span>
                      Ce motif ({selectedMotif.days} j.) dépasse le solde de {Math.max(0, ceilingRemaining)} j. pour {ceilingYear}.
                      Vous pouvez l&apos;enregistrer quand même : le plafond ne s&apos;applique pas aux RH/Admin.
                    </span>
                  </div>
                )}
                <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                  {motifCatalog.length === 0 && (
                    <p className="text-sm text-[var(--text-muted)] italic">Aucun motif configuré pour votre entreprise — contactez les RH.</p>
                  )}
                  {motifCatalog.map(m => (
                    <button
                      key={m.key}
                      onClick={() => setSelectedMotifKey(m.key)}
                      className={`w-full text-left px-3.5 py-2.5 rounded-xl border-2 flex items-center justify-between transition-all ${
                        selectedMotifKey === m.key ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20' : 'border-[var(--border)] hover:border-[var(--text-muted)]'
                      }`}
                    >
                      <span className="text-sm font-medium text-[var(--text)]">{m.label}</span>
                      <span className={`text-xs shrink-0 ml-2 ${motifExceeds(m.days) ? 'text-red-500 font-semibold' : 'text-[var(--text-muted)]'}`}>
                        {m.days} j.{motifExceeds(m.days) ? ' · dépasse le solde' : ''}
                      </span>
                    </button>
                  ))}
                  {/* 🆕 Autre — motif non prévu par la convention */}
                  <button
                    onClick={() => setSelectedMotifKey(OTHER_KEY)}
                    className={`w-full text-left px-3.5 py-2.5 rounded-xl border-2 border-dashed flex items-center justify-between transition-all ${
                      isOther ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20' : 'border-[var(--border)] hover:border-[var(--text-muted)]'
                    }`}
                  >
                    <span className="text-sm font-medium text-[var(--text)]">Autre (motif non listé)</span>
                    <span className="text-xs text-[var(--text-muted)] shrink-0 ml-2">à préciser</span>
                  </button>
                </div>
              </div>

              <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5 space-y-4">
                {isOther && (
                  <div>
                    <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5 block">Votre motif</label>
                    <textarea
                      value={reason}
                      onChange={e => setReason(e.target.value)}
                      rows={3}
                      placeholder="Précisez le motif de votre absence…"
                      className="w-full px-3 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-sm resize-none"
                    />
                  </div>
                )}
                <div>
                  <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5 block">Date de départ</label>
                  <div className="relative">
                    <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                    <input type="date" min="2000-01-01" max="2100-12-31" value={startDate} onChange={e => { setStartShiftNote(''); setStartDate(e.target.value); }} className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-sm" />
                  </div>
                  {startShiftNote && <p className="mt-1 text-xs text-amber-600">{startShiftNote}</p>}
                </div>
                {(selectedMotif || isOther) && startDate && (
                  <>
                    {calcBox}
                    {returnInput}
                    {coverageBox}
                  </>
                )}
                {isOther ? (
                  onBehalf ? (
                    <div className="p-3.5 rounded-xl border border-[var(--border)] space-y-2">
                      <div className="flex items-center gap-2">
                        <Wallet size={16} className="text-[var(--text-muted)]" />
                        <span className="text-sm font-medium text-[var(--text)]">Cette période est-elle payée ?</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {([[true, 'Payée'], [false, 'Non payée']] as const).map(([v, l]) => (
                          <button
                            key={String(v)}
                            type="button"
                            onClick={() => setPaidChoice(v)}
                            className={`py-2 rounded-lg text-sm font-semibold border-2 ${paidChoice === v ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300' : 'border-[var(--border)] text-[var(--text-muted)]'}`}
                          >
                            {l}
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-start gap-2 text-sm bg-[var(--surface-2)] text-[var(--text-muted)] px-3.5 py-3 rounded-xl">
                      <Wallet size={16} className="mt-0.5 shrink-0" />
                      <span>Les RH décideront si cette absence est payée ou non à la validation de votre demande.</span>
                    </div>
                  )
                ) : (
                  <>
                    <div className="flex items-center justify-between p-3.5 rounded-xl border border-[var(--border)]">
                      <div className="flex items-center gap-2">
                        <Wallet size={16} className="text-[var(--text-muted)]" />
                        <span className="text-sm font-medium text-[var(--text)]">Absence payée souhaitée</span>
                      </div>
                      <button
                        onClick={() => setIsPaid(!isPaid)}
                        className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${isPaid ? 'bg-emerald-500' : 'bg-[var(--border)]'}`}
                      >
                        <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-all ${isPaid ? 'left-5' : 'left-0.5'}`} />
                      </button>
                    </div>
                    <p className="text-[11px] text-[var(--text-muted)] -mt-2">Le statut définitif (payé / non-payé) est tranché par les RH à la validation.</p>
                  </>
                )}
                <div>
                  <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5 block">Justificatif (optionnel)</label>
                  <label className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-dashed border-[var(--border)] text-sm text-[var(--text-muted)] cursor-pointer hover:border-emerald-400 hover:text-emerald-500 transition-colors">
                    <Paperclip size={16} />
                    {uploading ? 'Envoi en cours…' : uploadedUrl ? 'Justificatif joint ✓' : 'Joindre un certificat / document'}
                    <input type="file" accept="image/*,.pdf" hidden onChange={e => e.target.files?.[0] && handleFileSelect(e.target.files[0])} />
                  </label>
                </div>
              </div>
            </>
          ) : (
            <>
          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
            <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-3 block">Type d&apos;absence</label>
            <div className="grid grid-cols-1 gap-2">
              {TYPE_OPTIONS.map(opt => {
                const Icon = opt.icon;
                const active = type === opt.value;
                return (
                  <button
                    key={opt.value}
                    onClick={() => handleTypeChange(opt.value)}
                    className={`flex items-center gap-3 p-3.5 rounded-xl border-2 text-left transition-all ${
                      active ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20' : 'border-[var(--border)] hover:border-[var(--text-muted)]'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${active ? 'bg-emerald-500 text-white' : 'bg-[var(--surface-2)] text-[var(--text-muted)]'}`}>
                      <Icon size={18} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-[var(--text)]">{opt.label}</p>
                      <p className="text-xs text-[var(--text-muted)]">{opt.hint}</p>
                    </div>
                  </button>
                );
              })}
            </div>

            <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mt-4 mb-2 block">Motif précis</label>
            <div className="flex flex-wrap gap-2">
              {SUBTYPE_OPTIONS[type].map(opt => (
                <button
                  key={opt.value}
                  onClick={() => setSubType(opt.value)}
                  className={`px-3.5 py-2 rounded-lg text-sm font-medium border transition-colors ${
                    subType === opt.value
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300'
                      : 'border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--text-muted)]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {calcBox}

          <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5 block">Date de départ</label>
                <div className="relative">
                  <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                  <input type="date" min="2000-01-01" max="2100-12-31" value={startDate} onChange={e => { setStartShiftNote(''); setStartDate(e.target.value); }} className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-sm" />
                </div>
                {startShiftNote && <p className="mt-1 text-xs text-amber-600">{startShiftNote}</p>}
              </div>
              <div>
                <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5 block">Date de reprise</label>
                <div className="relative">
                  <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                  <input type="date" min="2000-01-01" max="2100-12-31" value={returnDate} onChange={e => { setReturnDate(e.target.value); setReturnCalc(null); }} className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-sm" />
                </div>
              </div>
            </div>

            {coverageBox}

            <div>
              <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5 block">Motif de l&apos;absence</label>
              <textarea
                value={reason}
                onChange={e => setReason(e.target.value)}
                rows={3}
                placeholder="Expliquez brièvement le motif de votre absence…"
                className="w-full px-3 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-sm resize-none"
              />
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-xl border border-[var(--border)]">
              <div className="flex items-center gap-2">
                <Wallet size={16} className="text-[var(--text-muted)]" />
                <span className="text-sm font-medium text-[var(--text)]">Absence payée souhaitée</span>
              </div>
              <button
                onClick={() => setIsPaid(!isPaid)}
                className={`w-11 h-6 rounded-full transition-colors relative shrink-0 ${isPaid ? 'bg-emerald-500' : 'bg-[var(--border)]'}`}
              >
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-all ${isPaid ? 'left-5' : 'left-0.5'}`} />
              </button>
            </div>
            <p className="text-[11px] text-[var(--text-muted)] -mt-2">Le statut définitif (payé / non-payé) est tranché par les RH à la validation.</p>

            <div>
              <label className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-1.5 block">Justificatif (optionnel)</label>
              <label className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-dashed border-[var(--border)] text-sm text-[var(--text-muted)] cursor-pointer hover:border-emerald-400 hover:text-emerald-500 transition-colors">
                <Paperclip size={16} />
                {uploading ? 'Envoi en cours…' : uploadedUrl ? 'Justificatif joint ✓' : 'Joindre un certificat / document'}
                <input type="file" accept="image/*,.pdf" hidden onChange={e => e.target.files?.[0] && handleFileSelect(e.target.files[0])} />
              </label>
            </div>
          </div>
            </>
          )}

          {error && <div className="text-sm text-red-600 bg-red-50 dark:bg-red-900/20 px-4 py-3 rounded-xl">{error}</div>}

          <button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/30 transition-all"
          >
            {isSubmitting ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
            {onBehalf ? 'Créer la demande' : 'Envoyer la demande'}
          </button>
        </div>

        {/* ── APERÇU IMPRIMABLE (masqué par défaut) ── */}
        {showPreview && (
        <div className="xl:col-span-3">
          <div className="sticky top-6">
            <p className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-3">Aperçu du document</p>
            <div className="bg-[var(--surface-2)] rounded-2xl p-4 overflow-auto max-h-[85vh] border border-[var(--border)]">
              <div className="scale-[0.62] origin-top -mb-[38%] shadow-2xl">
                {isStandard ? (
                  <AbsenceRequestDocument template={company?.documentTemplate} data={standardPreviewData as any} />
                ) : (
                  <AbsenceRequestPrintable data={previewData as any} />
                )}
              </div>
            </div>
          </div>
        </div>
        )}
      </div>
    </div>
  );
}