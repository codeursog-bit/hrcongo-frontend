'use client';

// ============================================================================
// 📁 components/loans/LoansOverview.tsx
// ✅ Onglet "Vue d'ensemble" de la page Gestion des prêts & avances.
//    KPI du mois + de la période, 10 dernières demandes avec filtres, et
//    graphiques (courbe mensuelle emprunté/remboursé, répartition par type,
//    top départements par montant de dette).
// ✅ Ne fait AUCUN appel réseau : reçoit les listes déjà chargées par la page
//    parente (`loans`, `advances`) et travaille dessus — reste synchronisé
//    automatiquement après chaque décision/paiement.
// ============================================================================

import React, { useMemo, useState } from 'react';
import Link from 'next/link';
import { useBasePath } from '@/hooks/useBasePath';
import {
  TrendingUp, Wallet, Banknote, PiggyBank, Filter, ChevronRight, Users2, Search,
} from 'lucide-react';
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  Legend, PieChart, Pie, Cell, BarChart, Bar,
} from 'recharts';

const MONTHS_FR = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
const TYPE_LABEL: Record<string, string> = { ARGENT: 'Prêt argent', MARCHANDISE: 'Marchandise', AUTRE: 'Autre prêt', AVANCE: 'Avance sur salaire' };
const CHART_COLORS = ['#10B981', '#F59E0B', '#34D399', '#FBBF24', '#059669'];

const fmt = (n: number) => Math.round(n).toLocaleString('fr-FR') + ' FCFA';

type Props = {
  loans: any[];
  advances: any[];
  onSelectEmployee: (emp: any) => void;
  onGoToRequest: (kind: 'loan' | 'advance', id: string) => void;
};

export default function LoansOverview({ loans, advances, onSelectEmployee, onGoToRequest }: Props) {
  const { bp } = useBasePath();
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [typeFilter, setTypeFilter] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [nameFilter, setNameFilter] = useState('');
  const [showAll, setShowAll] = useState(false);

  // ── Unifier prêts + avances en une seule liste de "demandes" ──────────────
  const allRequests = useMemo(() => {
    const l = loans.map(x => ({
      ...x, kind: 'loan' as const,
      requestType: x.type ?? 'ARGENT',
      monthlyAmount: Number(x.monthlyRepayment ?? 0),
    }));
    const a = advances.map(x => ({
      ...x, kind: 'advance' as const,
      requestType: 'AVANCE',
      monthlyAmount: Number(x.amount ?? 0),
    }));
    return [...l, ...a].sort((x, y) => new Date(y.createdAt).getTime() - new Date(x.createdAt).getTime());
  }, [loans, advances]);

  // ✅ Date de référence pour CLASSER une demande dans un mois/une année —
  // jamais createdAt seul (date de création de l'enregistrement, souvent
  // "aujourd'hui" même si le prêt a été programmé pour un mois différent).
  // Un prêt se classe sur sa date de départ voulue (startDate) ; une avance
  // n'a pas de date de départ distincte, createdAt reste la meilleure
  // approximation de son décaissement réel. Utilisé PARTOUT dans ce fichier
  // (KPI du mois, tableau des demandes, graphe mensuel, années disponibles)
  // pour que toutes les vues restent cohérentes entre elles.
  const refDate = (r: any) => new Date(r.kind === 'loan' ? (r.startDate ?? r.createdAt) : r.createdAt);

  const departments = useMemo(() => {
    const set = new Set<string>();
    allRequests.forEach(r => { if (r.employee?.department?.name) set.add(r.employee.department.name); });
    return Array.from(set).sort();
  }, [allRequests]);

  const filtered = useMemo(() => {
    const nameQuery = nameFilter.trim().toLowerCase();
    return allRequests.filter(r =>
      (!typeFilter || r.requestType === typeFilter) &&
      (!deptFilter || r.employee?.department?.name === deptFilter) &&
      (!nameQuery || `${r.employee?.firstName ?? ''} ${r.employee?.lastName ?? ''}`.toLowerCase().includes(nameQuery)),
    );
  }, [allRequests, typeFilter, deptFilter, nameFilter]);

  // ✅ Une demande PENDING/REJECTED/CANCELLED n'a jamais été décaissée — elle
  // ne doit jamais compter dans un total "accordé", "emprunté" ou "dette".
  // Seul un prêt ACTIVE/PAID ou une avance APPROVED/PAID/DEDUCTED représente
  // de l'argent réellement sorti de la caisse.
  const isGranted = (r: any) =>
    r.kind === 'loan'
      ? ['ACTIVE', 'PAID'].includes(r.status)
      : ['APPROVED', 'PAID', 'DEDUCTED'].includes(r.status);

  // ── KPI ─────────────────────────────────────────────────────────────────
  const kpis = useMemo(() => {
    const thisMonth = allRequests.filter(r => {
      const d = refDate(r);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    });
    const countThisMonth = thisMonth.length; // ✅ compte TOUTES les demandes reçues, quel que soit leur statut — c'est le sens de "Demandes ce mois-ci"
    const totalThisMonth = thisMonth.filter(isGranted).reduce((s, r) => s + Number(r.amount ?? 0), 0);
    const totalAllTime = allRequests.filter(isGranted).reduce((s, r) => s + Number(r.amount ?? 0), 0);

    // Reste à recouvrer : solde restant des prêts actifs + avances approuvées non déduites
    const outstandingLoans = loans.filter(l => l.status === 'ACTIVE').reduce((s, l) => s + Number(l.remainingBalance ?? 0), 0);
    const outstandingAdvances = advances.filter(a => a.status === 'APPROVED').reduce((s, a) => s + Number(a.amount ?? 0), 0);
    const outstanding = outstandingLoans + outstandingAdvances;

    return { countThisMonth, totalThisMonth, totalAllTime, outstanding };
  }, [allRequests, loans, advances, now]);

  // ── Courbe mensuelle : montant emprunté/avancé vs remboursé, par mois de l'année sélectionnée ──
  const monthlySeries = useMemo(() => {
    return MONTHS_FR.map((label, idx) => {
      const monthNum = idx + 1;
      // ✅ Un prêt se classe sur sa date de DÉPART voulue (startDate), pas sur
      // createdAt (date de création de l'enregistrement, souvent "aujourd'hui"
      // même si le prêt a été programmé pour un mois différent) — sinon la
      // courbe semblait "figée" : tout nouveau prêt atterrissait toujours
      // dans le mois réel du jour, jamais dans le mois réellement choisi.
      // Une avance n'a pas de date de départ distincte : createdAt reste la
      // meilleure approximation de son décaissement réel.
      const emprunte = allRequests
        .filter(r => {
          const d = refDate(r);
          return isGranted(r) && d.getFullYear() === year && d.getMonth() === idx;
        })
        .reduce((s, r) => s + Number(r.amount ?? 0), 0);

      // Remboursé : déductions/paiements en espèces enregistrés ce mois-là (logs de prêts) + avances déduites/payées créées ce mois-là (proxy simple)
      const rembourseLoans = loans
        .flatMap(l => l.repaymentLogs ?? [])
        .filter((log: any) => log.year === year && log.month === monthNum)
        .reduce((s: number, log: any) => s + Number(log.amount ?? 0), 0);
      const rembourseAdvances = advances
        .filter(a => ['DEDUCTED', 'PAID'].includes(a.status) && a.deductYear === year && a.deductMonth === monthNum)
        .reduce((s, a) => s + Number(a.amount ?? 0), 0);

      return { mois: label, Emprunté: Math.round(emprunte), Remboursé: Math.round(rembourseLoans + rembourseAdvances) };
    });
  }, [allRequests, loans, advances, year]);

  const availableYears = useMemo(() => {
    const set = new Set<number>([now.getFullYear()]);
    allRequests.forEach(r => set.add(refDate(r).getFullYear()));
    return Array.from(set).sort((a, b) => b - a);
  }, [allRequests, now]);

  // ── Répartition par type (montant) ─────────────────────────────────────
  const byType = useMemo(() => {
    const map: Record<string, number> = {};
    allRequests.filter(isGranted).forEach(r => { map[r.requestType] = (map[r.requestType] ?? 0) + Number(r.amount ?? 0); });
    return Object.entries(map).map(([type, value]) => ({ name: TYPE_LABEL[type] ?? type, value }));
  }, [allRequests]);

  // ── Top départements par montant de dette ───────────────────────────────
  const byDept = useMemo(() => {
    const map: Record<string, number> = {};
    allRequests.filter(isGranted).forEach(r => {
      const name = r.employee?.department?.name || 'Sans département';
      map[name] = (map[name] ?? 0) + Number(r.amount ?? 0);
    });
    return Object.entries(map)
      .map(([departement, montant]) => ({ departement, montant: Math.round(montant) }))
      .sort((a, b) => b.montant - a.montant)
      .slice(0, 5);
  }, [allRequests]);

  const displayedRequests = showAll ? filtered : filtered.slice(0, 10);

  const recentlyValidatedLoans = useMemo(() =>
    loans.filter(l => ['ACTIVE', 'PAID'].includes(l.status))
      .sort((a, b) => new Date(b.approvedAt ?? b.createdAt).getTime() - new Date(a.approvedAt ?? a.createdAt).getTime())
      .slice(0, 6),
  [loans]);

  return (
    <div className="space-y-6">
      {/* ══════════════════ KPI ══════════════════ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard icon={Banknote} label="Demandes ce mois-ci" value={String(kpis.countThisMonth)} color="emerald" />
        <KpiCard icon={TrendingUp} label="Total accordé ce mois-ci" value={fmt(kpis.totalThisMonth)} color="emerald" />
        <KpiCard icon={PiggyBank} label="Total accordé (toutes périodes)" value={fmt(kpis.totalAllTime)} color="amber" />
        <KpiCard icon={Wallet} label="Reste à recouvrer" value={fmt(kpis.outstanding)} color="amber" />
      </div>

      {/* ══════════════════ DERNIÈRES DEMANDES ══════════════════ */}
      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
        <div className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[var(--border)]">
          <p className="text-sm font-bold text-[var(--text-muted)]">{showAll ? 'Toutes les demandes' : 'Dernières demandes'}</p>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
              <input
                type="text" value={nameFilter} onChange={e => setNameFilter(e.target.value)}
                placeholder="Rechercher un nom..."
                className="pl-7 pr-3 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-xs"
              />
            </div>
            <FilterSelect icon={Filter} value={typeFilter} onChange={setTypeFilter} placeholder="Tous les types" options={Object.entries(TYPE_LABEL)} />
            {departments.length > 0 && (
              <FilterSelect icon={Users2} value={deptFilter} onChange={setDeptFilter} placeholder="Tous les départements" options={departments.map(d => [d, d] as [string, string])} />
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-[var(--surface-2)]">
              <tr>{['Employé', 'Type', 'Montant', 'Mensualité', 'Date', 'Statut', ''].map(h => <th key={h} className="px-4 py-3 text-left text-xs font-bold text-[var(--text-muted)] uppercase whitespace-nowrap">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {displayedRequests.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-10 text-[var(--text-muted)]">Aucune demande pour ce filtre.</td></tr>
              ) : displayedRequests.map(r => (
                <tr key={`${r.kind}-${r.id}`} className="hover:bg-[var(--surface-2)]">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[var(--surface-2)] flex items-center justify-center text-[10px] font-bold text-[var(--text-muted)] overflow-hidden shrink-0">
                        {r.employee?.photoUrl ? <img src={r.employee.photoUrl} className="w-full h-full object-cover" alt="" /> : `${r.employee?.firstName?.[0] ?? ''}${r.employee?.lastName?.[0] ?? ''}`}
                      </div>
                      <div className="min-w-0">
                        <button onClick={() => onSelectEmployee(r.employee)} className="font-semibold text-[var(--text)] hover:text-emerald-600 hover:underline truncate">
                          {r.employee?.firstName} {r.employee?.lastName}
                        </button>
                        {r.employee?.department?.name && <p className="text-xs text-[var(--text-muted)] truncate">{r.employee.department.name}</p>}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-[var(--text-muted)]">{TYPE_LABEL[r.requestType] ?? r.requestType}</td>
                  <td className="px-4 py-3 font-semibold text-[var(--text)] whitespace-nowrap">{fmt(Number(r.amount ?? 0))}</td>
                  <td className="px-4 py-3 text-[var(--text-muted)] whitespace-nowrap">{r.monthlyAmount ? fmt(r.monthlyAmount) : '—'}</td>
                  <td className="px-4 py-3 text-[var(--text-muted)] whitespace-nowrap">{refDate(r).toLocaleDateString('fr-FR')}</td>
                  <td className="px-4 py-3"><StatusPill status={r.status} /></td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => onGoToRequest(r.kind, r.id)} className="text-emerald-600 hover:underline text-xs font-semibold flex items-center gap-0.5 ml-auto">
                      Détail <ChevronRight size={12} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filtered.length > 10 && (
          <div className="p-3 border-t border-[var(--border)] flex justify-center">
            <button onClick={() => setShowAll(s => !s)} className="text-xs font-semibold text-emerald-600 hover:underline">
              {showAll ? 'Réduire à 10 demandes' : `Voir les ${filtered.length} demandes`}
            </button>
          </div>
        )}
      </div>

      {/* ══════════════════ DERNIERS PRÊTS VALIDÉS ══════════════════ */}
      <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] overflow-hidden">
        <div className="p-4 border-b border-[var(--border)]">
          <p className="text-sm font-bold text-[var(--text-muted)]">Derniers prêts validés</p>
        </div>
        <div className="divide-y divide-[var(--border)]">
          {recentlyValidatedLoans.length === 0 ? (
            <p className="text-center py-10 text-[var(--text-muted)] text-sm">Aucun prêt validé pour le moment.</p>
          ) : recentlyValidatedLoans.map(l => (
            <button key={l.id} onClick={() => onSelectEmployee(l.employee)} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[var(--surface-2)] text-left">
              <div className="w-9 h-9 rounded-xl bg-[var(--surface-2)] flex items-center justify-center text-xs font-bold text-[var(--text-muted)] overflow-hidden shrink-0">
                {l.employee?.photoUrl ? <img src={l.employee.photoUrl} className="w-full h-full object-cover" alt="" /> : `${l.employee?.firstName?.[0] ?? ''}${l.employee?.lastName?.[0] ?? ''}`}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-[var(--text)] truncate">{l.employee?.firstName} {l.employee?.lastName}</p>
                <p className="text-xs text-[var(--text-muted)]">{TYPE_LABEL[l.type] ?? l.type} · validé le {new Date(l.approvedAt ?? l.createdAt).toLocaleDateString('fr-FR')}</p>
              </div>
              <span className="font-semibold text-sm text-emerald-600 whitespace-nowrap">{fmt(Number(l.amount))}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ══════════════════ NAVIGATION ══════════════════ */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Link href={bp('/loans/suivi-dettes')} className="group relative overflow-hidden rounded-2xl p-5 bg-emerald-500 text-white hover:bg-emerald-600 transition-colors">
          <TrendingUp className="absolute -right-3 -bottom-3 opacity-20 group-hover:scale-110 transition-transform" size={110} />
          <p className="text-xs font-bold uppercase tracking-wider opacity-80 mb-1">Suivi</p>
          <p className="text-lg font-bold mb-1">Suivi des dettes →</p>
          <p className="text-xs opacity-80">Qui doit combien, par employé, avec historique et paiement</p>
        </Link>
        <Link href={bp('/loans/validations')} className="group relative overflow-hidden rounded-2xl p-5 bg-amber-500 text-white hover:bg-amber-600 transition-colors">
          <Filter className="absolute -right-3 -bottom-3 opacity-20 group-hover:scale-110 transition-transform" size={110} />
          <p className="text-xs font-bold uppercase tracking-wider opacity-80 mb-1">Décisions</p>
          <p className="text-lg font-bold mb-1">Validations →</p>
          <p className="text-xs opacity-80">Toutes les demandes, valider ou refuser en un clic</p>
        </Link>
      </div>

      {/* ══════════════════ GRAPHIQUES ══════════════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm font-bold text-[var(--text-muted)]">Montants empruntés vs remboursés par mois</p>
            <select value={year} onChange={e => setYear(Number(e.target.value))} className="text-xs px-2 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)]">
              {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={monthlySeries}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="mois" fontSize={12} />
              <YAxis fontSize={12} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
              <Tooltip formatter={(v: number) => fmt(v)} />
              <Legend />
              <Line type="monotone" dataKey="Emprunté" stroke="#F59E0B" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="Remboursé" stroke="#10B981" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
          <p className="text-sm font-bold text-[var(--text-muted)] mb-4">Répartition par type de dette</p>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={byType} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>
                {byType.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
              </Pie>
              <Tooltip formatter={(v: number) => fmt(v)} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-5">
          <p className="text-sm font-bold text-[var(--text-muted)] mb-4">Top 5 départements par montant de dette</p>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={byDept} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} horizontal={false} />
              <XAxis type="number" fontSize={12} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
              <YAxis type="category" dataKey="departement" fontSize={12} width={110} />
              <Tooltip formatter={(v: number) => fmt(v)} />
              <Bar dataKey="montant" fill="#10B981" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function KpiCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string; color: 'emerald' | 'amber' }) {
  const cls: Record<string, string> = {
    emerald: 'bg-emerald-500',
    amber: 'bg-amber-500',
  };
  return (
    <div className="bg-[var(--surface)] rounded-2xl border border-[var(--border)] p-4 hover:shadow-md transition-shadow">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 text-white ${cls[color]}`}><Icon size={18} /></div>
      <p className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-1">{label}</p>
      <p className="text-lg font-bold text-[var(--text)] truncate">{value}</p>
    </div>
  );
}

function FilterSelect({ icon: Icon, value, onChange, placeholder, options }: { icon: any; value: string; onChange: (v: string) => void; placeholder: string; options: [string, string][] }) {
  return (
    <div className="relative">
      <Icon size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
      <select value={value} onChange={e => onChange(e.target.value)} className="pl-7 pr-3 py-1.5 rounded-lg border border-[var(--border)] bg-[var(--surface)] text-xs">
        <option value="">{placeholder}</option>
        {options.map(([val, label]) => <option key={val} value={val}>{label}</option>)}
      </select>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const cfg: Record<string, { label: string; cls: string; dot: string }> = {
    PENDING: { label: 'En attente', cls: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300', dot: 'bg-amber-500' },
    PENDING_DG: { label: 'En attente', cls: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300', dot: 'bg-amber-500' },
    ACTIVE: { label: 'Actif', cls: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', dot: 'bg-emerald-500' },
    APPROVED: { label: 'Approuvée', cls: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', dot: 'bg-emerald-500' },
    PAID: { label: 'Remboursé(e)', cls: 'bg-[var(--surface-2)] text-[var(--text-muted)]', dot: 'bg-[var(--text-muted)]' },
    DEDUCTED: { label: 'Déduite', cls: 'bg-[var(--surface-2)] text-[var(--text-muted)]', dot: 'bg-[var(--text-muted)]' },
    REJECTED: { label: 'Refusé(e)', cls: 'bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300', dot: 'bg-red-500' },
    CANCELLED: { label: 'Annulé(e)', cls: 'bg-[var(--surface-2)] text-[var(--text-muted)]', dot: 'bg-[var(--text-muted)]' },
  };
  const c = cfg[status] ?? { label: status, cls: 'bg-[var(--surface-2)] text-[var(--text-muted)]', dot: 'bg-[var(--text-muted)]' };
  return <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${c.cls}`}><span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />{c.label}</span>;
}