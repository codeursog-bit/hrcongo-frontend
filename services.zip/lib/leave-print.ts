// ============================================================================
// 📁 lib/leave-print.ts
// ✅ Même technique éprouvée que absence-print.ts, paramétrée par élément —
//    sert à la fois pour le formulaire de demande et la lettre d'autorisation.
// ============================================================================

function findElement(elementId: string): HTMLElement | null {
  return document.getElementById(elementId);
}

export function printLeaveDocument(elementId: string, orientation: 'portrait' | 'landscape' = 'portrait') {
  const el = findElement(elementId);
  if (!el) { window.print(); return; }

  const pageWidth = orientation === 'landscape' ? '297mm' : '210mm';
  const pageHeight = orientation === 'landscape' ? '210mm' : '297mm';

  const iframe = document.createElement('iframe');
  iframe.style.cssText = `position:fixed;top:-9999px;left:-9999px;width:${pageWidth};height:${pageHeight};border:none;visibility:hidden;`;
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument || iframe.contentWindow?.document;
  if (!doc) { document.body.removeChild(iframe); window.print(); return; }

  const styleLinks   = Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(l => l.outerHTML).join('\n');
  const styleInlines = Array.from(document.querySelectorAll('style')).map(s => `<style>${s.innerHTML}</style>`).join('\n');

  doc.open();
  doc.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
${styleLinks}
${styleInlines}
<style>
  @page { size: A4 ${orientation}; margin: 0; }
  html, body { margin: 0; padding: 0; background: #fff; font-family: Arial, Helvetica, sans-serif; }
  * { color-scheme: light !important; }
  body > *:not(#leave-print-target) { display: none !important; }
  #leave-print-target {
    width: ${pageWidth} !important; margin: 0 auto !important; background: #fff !important;
    ${orientation === 'portrait' ? `
    /* ✅ CORRECTIF : garantit UNE seule page à l'impression navigateur pour
       les documents portrait (formulaire de demande, lettre d'autorisation)
       — le téléchargement PDF avait déjà ce garde-fou (mise à l'échelle),
       l'impression native window.print() n'en avait aucun. Non appliqué en
       paysage : le planning des départs peut légitimement compter plusieurs
       pages selon le nombre d'employés. */
    height: 297mm !important; overflow: hidden !important;
    ` : ''}
  }
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; color-adjust: exact !important; }
  /* ✅ CORRECTIF : le site est en dark mode par défaut (voir globals.css).
     Si un élément du document utilise une classe Tailwind "dark:text-*"
     (texte clair pensé pour un fond sombre) plutôt qu'une couleur figée,
     il devient quasi invisible une fois forcé sur fond blanc ici — d'où le
     texte "délavé" à l'impression/export (même bug identifié sur les prêts,
     cf. loan-print.ts). On impose une couleur de texte sûre à tout le
     contenu imprimé, quelle que soit la classe/le thème d'origine — SAUF
     aux éléments du formulaire lui-même (classes "std-*" : std-abs-*,
     std-adv-*, std-loan-*, std-leave-*), qui verrouillent déjà leurs
     propres couleurs de marque (filets, titres colorés…) via leur <style>
     scopé en !important. Sans cette exception, ce garde-fou les écrasait
     en noir uniforme.
  */
  #leave-print-target, #leave-print-target *:not([class*="std-"]) {
    color: #111 !important;
    background-color: transparent !important;
  }
  #leave-print-target { background-color: #fff !important; }
  #leave-print-target img { background-color: initial !important; }
</style>
</head><body>
<div id="leave-print-target">${el.outerHTML}</div>
</body></html>`);
  doc.close();

  const win = iframe.contentWindow;
  if (!win) { document.body.removeChild(iframe); window.print(); return; }

  const doPrint = () => {
    try { win.focus(); win.print(); } catch { window.print(); }
    setTimeout(() => { if (document.body.contains(iframe)) document.body.removeChild(iframe); }, 1500);
  };

  if (doc.readyState === 'complete') setTimeout(doPrint, 300);
  else {
    win.addEventListener('load', () => setTimeout(doPrint, 300), { once: true });
    setTimeout(doPrint, 1500);
  }
}

export async function downloadLeaveDocumentPDF(elementId: string, filename: string, orientation: 'portrait' | 'landscape' = 'portrait'): Promise<void> {
  const el = findElement(elementId);
  if (!el) { alert('Impossible de générer le PDF : document introuvable.'); return; }

  const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([
    import('html2canvas'),
    import('jspdf'),
  ]);

  const isLandscape = orientation === 'landscape';
  const pageWidthMm = isLandscape ? 297 : 210;
  const pageHeightMm = isLandscape ? 210 : 297;
  // Correspondance mm → px à 96dpi (utilisée par html2canvas/windowWidth)
  const pagePxWidth = Math.round(pageWidthMm * 3.7795);
  const pagePxHeight = Math.round(pageHeightMm * 3.7795);

  const container = document.createElement('div');
  container.style.cssText = `position:fixed;left:-9999px;top:0;width:${pageWidthMm}mm;background:#fff;z-index:-1;overflow:visible;`;

  const clone = el.cloneNode(true) as HTMLElement;
  // ⚠️ On NE remplace PAS tout le style (cssText) : ça effacerait la couleur
  // de texte d'origine et d'autres styles inline du composant source, qui
  // retomberaient alors sur les styles hérités du thème (souvent clair sur
  // fond clair / invisible). On ajoute seulement ce qui est nécessaire pour
  // l'export, par-dessus le style existant du clone. Sur les formulaires
  // "std-leave-*", ces propriétés (width/height/padding…) sont déjà posées
  // en !important par le <style> scopé du composant — ces setProperty()
  // sans !important n'ont alors aucun effet, ce qui est voulu : on n'écrase
  // pas la mise en page calée du formulaire.
  clone.style.setProperty('width', `${pageWidthMm}mm`);
  clone.style.setProperty('min-height', `${pageHeightMm}mm`);
  clone.style.setProperty('padding', isLandscape ? '10mm 12mm' : '14mm 16mm');
  clone.style.setProperty('margin', '0');
  clone.style.setProperty('box-shadow', 'none');
  clone.style.setProperty('border', 'none');
  clone.style.setProperty('background', '#fff');
  clone.style.setProperty('box-sizing', 'border-box');
  clone.id = 'pdf-export-target';

  // ✅ CORRECTIF : le `if (!clone.style.color) …` ne suffisait pas — il ne
  // couvre que la racine du clone, pas les enfants qui porteraient leur
  // propre classe Tailwind "dark:text-*" (texte clair pensé pour un fond
  // sombre, le site étant en dark mode par défaut). Ces enfants gardaient
  // leur couleur claire, invisible une fois forcés sur fond blanc — d'où le
  // texte "délavé" (même bug identifié sur les prêts, cf. loan-print.ts).
  // On impose donc une couleur sûre à TOUT le clone, pas seulement sa racine
  // — SAUF aux éléments "std-*" du formulaire, qui verrouillent déjà leurs
  // propres couleurs de marque (voir le commentaire équivalent dans
  // printLeaveDocument ci-dessus).
  const styleOverride = document.createElement('style');
  styleOverride.textContent = `
    #pdf-export-target, #pdf-export-target *:not([class*="std-"]) { color: #1f2937 !important; background-color: transparent !important; }
    #pdf-export-target { background-color: #fff !important; }
    #pdf-export-target img { background-color: initial !important; }
  `;
  container.appendChild(styleOverride);
  if (!clone.style.fontFamily) clone.style.setProperty('font-family', 'Arial, Helvetica, sans-serif');

  container.appendChild(clone);
  document.body.appendChild(container);

  try {
    await new Promise(r => setTimeout(r, 200));

    const W = clone.scrollWidth  || clone.offsetWidth  || pagePxWidth;
    const H = clone.scrollHeight || clone.offsetHeight || pagePxHeight;

    // scale 2.5 : plus net qu'avant (2), important sur un tableau large avec
    // beaucoup de texte serré — évite le flou à l'impression/zoom.
    const canvas = await html2canvas(clone, { scale: 2.5, useCORS: true, allowTaint: true, backgroundColor: '#ffffff', logging: false, width: W, height: H, windowWidth: pagePxWidth, windowHeight: pagePxHeight });
    const imgData = canvas.toDataURL('image/jpeg', 0.97);
    const pdf     = new jsPDF({ orientation, unit: 'mm', format: 'a4' });
    const pdfW    = pdf.internal.pageSize.getWidth();
    const pdfH    = pdf.internal.pageSize.getHeight();

    const imgRatio = canvas.width / canvas.height;

    // ✅ CORRECTIF : ce document tient sur UNE page — l'ancienne logique
    // paginait dès que le contenu dépassait 297mm de la moindre fraction de
    // mm, produisant une 2e page quasi vide. On ajuste maintenant l'échelle
    // pour TOUJOURS tenir sur une seule page.
    let finalW = pdfW;
    let finalH = pdfW / imgRatio;
    if (finalH > pdfH) {
      finalH = pdfH;
      finalW = pdfH * imgRatio;
    }
    const offsetX = (pdfW - finalW) / 2;
    pdf.addImage(imgData, 'JPEG', offsetX, 0, finalW, finalH, '', 'FAST');

    pdf.save(filename);
  } catch (err) {
    console.error('[leave-print] Erreur génération PDF:', err);
    alert("Erreur lors de la génération du PDF. Essayez l'impression navigateur.");
  } finally {
    if (document.body.contains(container)) document.body.removeChild(container);
  }
}