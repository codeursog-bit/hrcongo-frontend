import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, DollarSign, Ban, X, Printer, Loader2 } from 'lucide-react';

interface PayrollBatchActionsFooterProps {
  selectedCount: number;
  isLoading: boolean;
  onValidate: () => void;
  onPay: () => void;
  onCancel: () => void;
  onClear: () => void;
  onPrintAll?: () => void;
  isPrinting?: boolean;
}

export function PayrollBatchActionsFooter({
  selectedCount,
  isLoading,
  onValidate,
  onPay,
  onCancel,
  onClear,
  onPrintAll,
  isPrinting = false,
}: PayrollBatchActionsFooterProps) {
  if (selectedCount === 0) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        // ✅ CORRECTION : Positionnement relatif au contenu, pas à tout l'écran
        className="sticky bottom-6 z-50 mt-6"
      >
        {/* ✅ Le conteneur respecte maintenant la largeur du contenu principal */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-6 bg-[var(--surface)] rounded-2xl shadow-lg border border-[var(--border)]">
          
          {/* Gauche : Info sélection */}
          <div className="flex items-center gap-3">
            <div className="text-sm">
              <span className="font-bold text-[var(--text)] text-lg">
                {selectedCount} bulletin{selectedCount > 1 ? 's' : ''} sélectionné{selectedCount > 1 ? 's' : ''}
              </span>
              <p className="text-[var(--text-muted)] text-xs">
                Choisissez une action à appliquer en masse
              </p>
            </div>
          </div>

          {/* Droite : Boutons */}
          <div className="flex items-center gap-4 w-full md:w-auto">
            {isLoading ? (
              <div className="flex-1 md:flex-none px-6 py-3 bg-[var(--surface-2)] text-[var(--text-muted)] font-bold rounded-xl flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-[var(--border)] border-t-transparent rounded-full animate-spin" />
                Traitement...
              </div>
            ) : (
              <>
                {/* ✅ Bouton Imprimer tout (gris/neutre — action de lecture, pas de changement de statut) */}
                {onPrintAll && (
                  <button
                    onClick={onPrintAll}
                    disabled={isPrinting}
                    className="flex-1 md:flex-none px-6 py-3 bg-[var(--surface-2)] hover:opacity-80 text-[var(--text)] font-bold rounded-xl transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isPrinting ? <Loader2 size={18} className="animate-spin" /> : <Printer size={18} />}
                    <span className="hidden sm:inline">{isPrinting ? 'Préparation…' : 'Imprimer'}</span>
                  </button>
                )}

                {/* ✅ Bouton Valider (vert) */}
                <button 
                  onClick={onValidate}
                  className="flex-1 md:flex-none px-6 py-3 bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-900/30 dark:hover:bg-emerald-900/50 text-emerald-700 dark:text-emerald-400 font-bold rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  <CheckCircle2 size={18} />
                  <span className="hidden sm:inline">Valider</span>
                </button>

                {/* ✅ Bouton Payer (ambre) */}
                <button 
                  onClick={onPay}
                  className="flex-1 md:flex-none px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl transition-colors shadow-lg flex items-center justify-center gap-2"
                >
                  <DollarSign size={18} />
                  <span className="hidden sm:inline">Payer</span>
                </button>

                {/* ✅ Bouton Annuler (rouge) */}
                <button 
                  onClick={onCancel}
                  className="flex-1 md:flex-none px-6 py-3 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl transition-colors shadow-lg flex items-center justify-center gap-2"
                >
                  <Ban size={18} />
                  <span className="hidden sm:inline">Annuler</span>
                </button>

                {/* Bouton Fermer */}
                <button 
                  onClick={onClear}
                  className="p-3 bg-[var(--surface-2)] hover:opacity-80 text-[var(--text-muted)] rounded-xl transition-colors"
                  title="Désélectionner tout"
                >
                  <X size={18} />
                </button>
              </>
            )}
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}