'use client';

import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { 
    CreditCard, Calendar, Clock, DollarSign, List, UserCheck, 
    ArrowLeft, ArrowRight, Save, Loader2, CheckCircle, XCircle, 
    Wallet, Search, ChevronDown, Paperclip
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '@/services/api';
import { useImageUpload } from '@/hooks/useImageUpload';

// --- Types ---
interface Employee {
    id: string;
    firstName: string;
    lastName: string;
    employeeNumber: string;
    position: string;
    photoUrl?: string;
    baseSalary?: number;
    departmentId?: string;
    department?: { id: string; name: string };
}

interface LoanData {
    employeeId: string;
    amount: number;
    monthlyRepayment: number;
    startDate: string;
    endDate: string;
    reason: string;
}

interface AdvanceData {
    employeeId: string;
    amount: number;
    deductMonth: number;
    deductYear: number;
    reason: string;
}

type FormType = 'LOAN' | 'ADVANCE';

// --- Input ---
interface InputProps {
    icon?: React.ElementType;
    label: string;
    name: string;
    type?: string;
    value: string | number;
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
    placeholder?: string;
    min?: number;
    max?: number;
    required?: boolean;
    disabled?: boolean;
}

const Input = ({ icon: Icon, label, name, type = 'text', value, onChange, placeholder, min, max, required, disabled }: InputProps) => (
    <div>
        <label className="block text-sm font-bold text-[var(--text-muted)] mb-2">
            {label} {required && <span className="text-red-500">*</span>}
        </label>
        <div className="relative">
            {Icon && (
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)] z-10">
                    <Icon size={18} />
                </div>
            )}
            {type === 'textarea' ? (
                <textarea
                    name={name}
                    value={value}
                    onChange={onChange}
                    placeholder={placeholder}
                    required={required}
                    disabled={disabled}
                    rows={3}
                    className={`w-full ${Icon ? 'pl-10' : 'pl-3'} pr-3 py-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl text-[var(--text)] focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed`}
                />
            ) : (
                <input
                    type={type}
                    name={name}
                    value={value}
                    onChange={onChange}
                    placeholder={placeholder}
                    min={min}
                    max={max}
                    required={required}
                    disabled={disabled}
                    className={`w-full ${Icon ? 'pl-10' : 'pl-3'} pr-3 py-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl text-[var(--text)] focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed`}
                />
            )}
        </div>
    </div>
);

// --- EmployeeSelect avec recherche ---
interface EmployeeSelectProps {
    label: string;
    name: string;
    value: string;
    onChange: (employeeId: string) => void;
    employees: Employee[];
    loading?: boolean;
    required?: boolean;
}

const EmployeeSelect = ({ label, value, onChange, employees, loading, required }: EmployeeSelectProps) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');

    const selectedEmployee = employees.find(e => e.id === value);

    const filteredEmployees = useMemo(() => {
        if (!searchQuery) return employees;
        const query = searchQuery.toLowerCase();
        return employees.filter(e =>
            e.firstName.toLowerCase().includes(query) ||
            e.lastName.toLowerCase().includes(query) ||
            (e.employeeNumber || '').toLowerCase().includes(query) ||
            (e.position || '').toLowerCase().includes(query)
        );
    }, [employees, searchQuery]);

    const handleSelect = (employeeId: string) => {
        onChange(employeeId);
        setIsOpen(false);
        setSearchQuery('');
    };

    return (
        <div className="relative">
            <label className="block text-sm font-bold text-[var(--text-muted)] mb-2">
                {label} {required && <span className="text-red-500">*</span>}
            </label>

            <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                disabled={loading}
                className="w-full flex items-center gap-3 px-4 py-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl text-left hover:border-emerald-500 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
                <UserCheck size={18} className="text-[var(--text-muted)] flex-shrink-0" />
                {loading ? (
                    <span className="text-[var(--text-muted)] flex-1">Chargement...</span>
                ) : selectedEmployee ? (
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                            {selectedEmployee.firstName[0]}{selectedEmployee.lastName[0]}
                        </div>
                        <div className="flex-1 min-w-0">
                            <p className="font-bold text-[var(--text)] truncate">
                                {selectedEmployee.firstName} {selectedEmployee.lastName}
                            </p>
                            <p className="text-xs text-[var(--text-muted)] truncate">
                                {selectedEmployee.employeeNumber && `${selectedEmployee.employeeNumber} · `}{selectedEmployee.position}
                                {selectedEmployee.department?.name && ` · ${selectedEmployee.department.name}`}
                            </p>
                        </div>
                    </div>
                ) : (
                    <span className="text-[var(--text-muted)] flex-1">Sélectionner un employé</span>
                )}
                <ChevronDown size={18} className={`text-[var(--text-muted)] transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute top-full left-0 right-0 mt-2 bg-[var(--surface)] border border-[var(--border)] rounded-xl shadow-2xl z-50 max-h-80 overflow-hidden"
                    >
                        {/* Barre de recherche */}
                        <div className="p-3 border-b border-[var(--border)] sticky top-0 bg-[var(--surface)]">
                            <div className="relative">
                                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                                <input
                                    type="text"
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    placeholder="Rechercher un employé..."
                                    className="w-full pl-9 pr-3 py-2 bg-[var(--surface-2)] border border-[var(--border)] rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all"
                                    autoFocus
                                />
                            </div>
                        </div>

                        {/* Liste */}
                        <div className="overflow-y-auto max-h-64">
                            {filteredEmployees.length === 0 ? (
                                <div className="p-6 text-center text-[var(--text-muted)]">
                                    <UserCheck size={32} className="mx-auto mb-2 opacity-30" />
                                    <p className="text-sm">Aucun employé trouvé</p>
                                </div>
                            ) : (
                                filteredEmployees.map(emp => (
                                    <button
                                        key={emp.id}
                                        type="button"
                                        onClick={() => handleSelect(emp.id)}
                                        className={`w-full flex items-center gap-3 p-3 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors border-b border-[var(--border)] last:border-0 ${
                                            value === emp.id ? 'bg-emerald-50 dark:bg-emerald-900/20' : ''
                                        }`}
                                    >
                                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white font-bold flex-shrink-0 text-sm">
                                            {emp.firstName[0]}{emp.lastName[0]}
                                        </div>
                                        <div className="flex-1 text-left min-w-0">
                                            <p className="font-bold text-[var(--text)] text-sm truncate">
                                                {emp.firstName} {emp.lastName}
                                            </p>
                                            <p className="text-xs text-[var(--text-muted)] truncate">
                                                {emp.employeeNumber && `${emp.employeeNumber} · `}{emp.position}
                                                {emp.department?.name && ` · ${emp.department.name}`}
                                            </p>
                                        </div>
                                        {value === emp.id && (
                                            <CheckCircle size={18} className="text-emerald-500 flex-shrink-0" />
                                        )}
                                    </button>
                                ))
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {isOpen && (
                <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
            )}
        </div>
    );
};

// --- Button ---
interface ButtonProps {
    children: React.ReactNode;
    type?: 'button' | 'submit';
    variant?: 'primary' | 'secondary';
    className?: string;
    disabled?: boolean;
    onClick?: () => void;
}

const Button = ({ children, type = 'button', variant = 'primary', className = '', disabled, onClick }: ButtonProps) => {
    const baseStyles = "px-6 py-3 rounded-xl font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed";
    const variants = {
        primary: "bg-gradient-to-r from-emerald-500 to-emerald-600 text-white hover:from-emerald-600 hover:to-emerald-700 shadow-lg hover:scale-105",
        secondary: "bg-[var(--surface-2)] text-[var(--text)] hover:bg-[var(--border)]"
    };
    return (
        <button type={type} onClick={onClick} disabled={disabled} className={`${baseStyles} ${variants[variant]} ${className}`}>
            {children}
        </button>
    );
};

// --- Notification ---
interface NotificationProps {
    type: 'success' | 'error';
    message: string;
    onClose: () => void;
    className?: string;
}

const Notification = ({ type, message, onClose, className = '' }: NotificationProps) => {
    const styles = {
        success: 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300',
        error: 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-700 dark:text-red-300'
    };
    return (
        <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`flex items-start gap-3 p-4 rounded-xl border-2 ${styles[type]} ${className}`}
        >
            <div className="flex-shrink-0 mt-0.5">
                {type === 'success' ? <CheckCircle size={20} /> : <XCircle size={20} />}
            </div>
            <p className="flex-1 text-sm font-medium">{message}</p>
            <button onClick={onClose} className="flex-shrink-0 hover:opacity-70 transition-opacity">
                <XCircle size={18} />
            </button>
        </motion.div>
    );
};

// --- GlassCard ---
const GlassCard = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
    <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 100 }}
        className={`bg-[var(--surface)] rounded-2xl p-8 border border-[var(--border)] shadow-sm ${className}`}
    >
        {children}
    </motion.div>
);

// ============================================================
// 🏦 COMPOSANT PRINCIPAL
// ============================================================
export const LoansForm = ({ onCreationSuccess }: { onCreationSuccess: () => void }) => {
    const [formType, setFormType] = useState<FormType>('LOAN');
    const [formData, setFormData] = useState<any>({ recoverViaPayroll: true });
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
    const [employees, setEmployees] = useState<Employee[]>([]);
    const [loadingEmployees, setLoadingEmployees] = useState(true);
    const [userRole, setUserRole] = useState('');
    // ✅ Le formulaire s'adapte au modèle de document choisi par l'entreprise
    // (paramètres → Modèle de document) : "Nature du prêt" n'a de sens que
    // pour le modèle STANDARD (Arkia/Petrodys/Infinitium...), pas pour le
    // modèle par défaut qui ne l'affiche jamais sur le document imprimé.
    const [documentTemplate, setDocumentTemplate] = useState<string>('DEFAULT');

    useEffect(() => {
        try { const stored = localStorage.getItem('user'); if (stored) setUserRole(JSON.parse(stored).role || ''); } catch {}
        (async () => {
            try {
                const company: any = await api.get('/companies/mine');
                setDocumentTemplate(company?.documentTemplate || 'DEFAULT');
            } catch {}
        })();
    }, []);

    // Le choix "paie / espèces" n'a d'effet que quand un ADMIN/SUPER_ADMIN/HR_MANAGER
    // crée directement pour un employé (auto-approuvé, pas de circuit de validation
    // où ce choix serait redemandé plus tard).
    const isAdminCreatingForSomeoneElse = ['ADMIN', 'SUPER_ADMIN', 'HR_MANAGER'].includes(userRole) && !!formData.employeeId;

    useEffect(() => {
        const fetchEmployees = async () => {
            setLoadingEmployees(true);
            try {
                // ✅ /employees/simple — liste légère déjà filtrée par entreprise
                // Pas d'objet paginé, pas de filtre baseSalary côté front
                // La validation métier (salaire suffisant) est faite côté backend
                const data = await api.get<Employee[]>('/employees/simple');
                const list = Array.isArray(data) ? data : [];
                console.log(`✅ ${list.length} employés chargés pour le formulaire prêts`);
                setEmployees(list);
            } catch (error) {
                console.error('❌ Erreur chargement employés:', error);
                setEmployees([]);
            } finally {
                setLoadingEmployees(false);
            }
        };
        fetchEmployees();
    }, []);

    const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData((prev: any) => ({
            ...prev,
            [name]: ['amount', 'monthlyRepayment', 'deductMonth', 'deductYear'].includes(name)
                ? parseFloat(value) || 0
                : value,
        }));
    }, []);

    const handleEmployeeChange = useCallback((employeeId: string) => {
        setFormData((prev: any) => ({ ...prev, employeeId }));
    }, []);

    const validateForm = useCallback((data: any) => {
        const errors: string[] = [];

        if (!data.employeeId) {
            errors.push("Veuillez sélectionner un employé.");
            return errors;
        }

        if (formType === 'LOAN') {
            const { amount, monthlyRepayment, startDate, endDate } = data as LoanData;
            if (!amount || amount <= 0 || !monthlyRepayment || monthlyRepayment <= 0) {
                errors.push("Le montant et le remboursement mensuel doivent être positifs.");
            }
            if (!startDate || !endDate || new Date(startDate) >= new Date(endDate)) {
                errors.push("Les dates de début et fin de prêt sont invalides.");
            }
            // ⚠️ Validation métier (30% salaire, SMIC, durée 24 mois) → backend uniquement
        } else {
            const { amount, deductMonth, deductYear } = data as AdvanceData;
            if (!amount || amount <= 0) {
                errors.push("Le montant de l'avance doit être positif.");
            }
            if (!deductMonth || deductMonth < 1 || deductMonth > 12 || !deductYear || deductYear < 2024) {
                errors.push("Mois ou année de déduction invalide.");
            }
            // ⚠️ Validation métier (50% salaire) → backend uniquement
        }

        if (!data.reason || data.reason.trim().length < 5) {
            errors.push("Une raison d'au moins 5 caractères est requise.");
        }

        return errors;
    }, [formType]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage(null);

        const errors = validateForm(formData);
        if (errors.length > 0) {
            setMessage({ type: 'error', text: errors.join(' / ') });
            return;
        }

        setLoading(true);
        const endpoint = formType === 'LOAN' ? '/loans' : '/loans/advances';
        const label    = formType === 'LOAN' ? 'Prêt' : 'Avance';

        try {
            await api.post(endpoint, {
                ...formData,
                amount: Number(formData.amount),
                ...(formType === 'LOAN' && { monthlyRepayment: Number(formData.monthlyRepayment) }),
                ...(formType === 'LOAN' && attachmentUrl && { attachmentUrl }),
                ...(isAdminCreatingForSomeoneElse && { recoverViaPayroll: !!formData.recoverViaPayroll }),
            });
            setMessage({ type: 'success', text: `${label} créé et approuvé avec succès !` });
            setFormData({ recoverViaPayroll: true });
            setTimeout(() => onCreationSuccess(), 1500);
        } catch (error: any) {
            console.error(error);
            // Afficher le message d'erreur métier du backend (30%, SMIC, durée...)
            const msg = error?.response?.data?.message || error?.message || `Erreur lors de la création du ${label}.`;
            setMessage({ type: 'error', text: msg });
        } finally {
            setLoading(false);
        }
    };

    const isLoan = formType === 'LOAN';

    // ✅ Pièce jointe (Pièces jointes / justificatif) — n'a de sens visible
    // sur le papier que pour le Prêt, pas pour l'Avance. Réutilise le même
    // hook d'upload que le module congé/absence (Cloudinary).
    const { uploadedUrl: attachmentUrl, uploading: uploadingAttachment, handleFileSelect: handleAttachmentSelect } = useImageUpload({ folder: 'loans' });

    // 🐛 Bug pré-existant corrigé : le backend rejette toute requête contenant
    // un champ non déclaré dans le DTO (ValidationPipe forbidNonWhitelisted:
    // true). Si on remplissait le formulaire en "Prêt" (monthlyRepayment,
    // startDate, endDate, nature...) puis qu'on basculait sur "Avance" sans
    // réinitialiser, la création échouait avec un 400 silencieux — les champs
    // du prêt restaient dans formData et n'existent pas dans CreateAdvanceDto
    // (et vice-versa pour deductMonth/deductYear côté prêt). On ne garde que
    // les champs communs au changement d'onglet.
    const handleFormTypeChange = (next: FormType) => {
        setFormType(next);
        setFormData((prev: any) => ({
            employeeId: prev.employeeId,
            amount: prev.amount,
            reason: prev.reason,
            recoverViaPayroll: prev.recoverViaPayroll ?? true,
        }));
    };

    return (
        <GlassCard>
            <div className="flex justify-between items-center mb-6 border-b pb-4 border-[var(--border)]">
                <h2 className="text-2xl font-extrabold text-[var(--text)] flex items-center gap-3">
                    <CreditCard size={28} className="text-emerald-500" />
                    Créer Financement
                </h2>
                <div className="flex bg-[var(--surface-2)] rounded-full p-1 shadow-inner">
                    <button
                        onClick={() => handleFormTypeChange('LOAN')}
                        className={`px-4 py-2 text-sm font-semibold rounded-full transition-all flex items-center ${isLoan ? 'bg-emerald-600 text-white shadow-md' : 'text-[var(--text-muted)] hover:bg-white/10'}`}
                    >
                        {isLoan && <ArrowLeft size={16} className="mr-2" />} Prêt
                    </button>
                    <button
                        onClick={() => handleFormTypeChange('ADVANCE')}
                        className={`px-4 py-2 text-sm font-semibold rounded-full transition-all flex items-center ${!isLoan ? 'bg-emerald-600 text-white shadow-md' : 'text-[var(--text-muted)] hover:bg-white/10'}`}
                    >
                        Avance {!isLoan && <ArrowRight size={16} className="ml-2" />}
                    </button>
                </div>
            </div>

            <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <EmployeeSelect
                        label="Employé Concerné"
                        name="employeeId"
                        value={formData.employeeId || ''}
                        onChange={handleEmployeeChange}
                        employees={employees}
                        loading={loadingEmployees}
                        required
                    />
                    <Input
                        icon={DollarSign}
                        label={isLoan ? "Montant Total du Prêt (FCFA)" : "Montant de l'Avance (FCFA)"}
                        name="amount"
                        type="number"
                        value={formData.amount || ''}
                        onChange={handleChange}
                        min={1}
                        placeholder="Ex: 500000"
                        required
                    />
                </div>

                <AnimatePresence mode="wait">
                    {isLoan ? (
                        <motion.div
                            key="loan"
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6 overflow-hidden"
                        >
                            <Input icon={Wallet} label="Remboursement Mensuel (FCFA)" name="monthlyRepayment" type="number" value={formData.monthlyRepayment || ''} onChange={handleChange} placeholder="Ex: 25000" min={1} required />
                            <Input icon={Calendar} label="Date de Début" name="startDate" type="date" value={formData.startDate || ''} onChange={handleChange} required />
                            <Input icon={Clock} label="Date de Fin Estimée" name="endDate" type="date" value={formData.endDate || ''} onChange={handleChange} required />
                            {documentTemplate === 'STANDARD' && (
                                <div className="md:col-span-3">
                                    <label className="block text-sm font-bold text-[var(--text-muted)] mb-2">Nature du prêt</label>
                                    <select
                                        name="nature"
                                        value={formData.nature || ''}
                                        onChange={handleChange}
                                        className="w-full p-3 bg-[var(--surface-2)] border border-[var(--border)] rounded-xl text-sm text-[var(--text)]"
                                    >
                                        <option value="">— Non précisé —</option>
                                        <option value="SOCIAL">Prêt social</option>
                                        <option value="SCOLARITE">Prêt scolarité</option>
                                        <option value="LOGEMENT">Prêt logement</option>
                                        <option value="EXCEPTIONNEL">Prêt exceptionnel</option>
                                        <option value="AUTRE">Autre</option>
                                    </select>
                                </div>
                            )}
                            {documentTemplate === 'STANDARD' && (
                                <div className="md:col-span-3">
                                    <label className="block text-sm font-bold text-[var(--text-muted)] mb-2">Pièce jointe (devis, justificatif de scolarité, certificat médical...)</label>
                                    <label className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-dashed border-[var(--border)] text-sm text-[var(--text-muted)] cursor-pointer hover:border-emerald-400 hover:text-emerald-500 transition-colors">
                                        <Paperclip size={16} />
                                        {uploadingAttachment ? 'Envoi en cours…' : attachmentUrl ? 'Pièce jointe ✓' : 'Joindre un document'}
                                        <input type="file" accept="image/*,.pdf" hidden onChange={e => e.target.files?.[0] && handleAttachmentSelect(e.target.files[0])} />
                                    </label>
                                </div>
                            )}
                        </motion.div>
                    ) : (
                        <motion.div
                            key="advance"
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 overflow-hidden"
                        >
                            <Input icon={Calendar} label="Mois de Déduction (1-12)" name="deductMonth" type="number" value={formData.deductMonth || ''} onChange={handleChange} min={1} max={12} placeholder="Ex: 10 (Octobre)" required />
                            <Input icon={Clock} label="Année de Déduction" name="deductYear" type="number" value={formData.deductYear || ''} onChange={handleChange} min={new Date().getFullYear()} placeholder="Ex: 2026" required />
                        </motion.div>
                    )}
                </AnimatePresence>

                <div className="mb-6">
                    <Input icon={List} label="Raison du Financement / Avance" name="reason" type="textarea" value={formData.reason || ''} onChange={handleChange} placeholder="Détaillez la raison (achat immobilier, dépense imprévue, etc.)" required />

                    {isAdminCreatingForSomeoneElse && (
                        <label className="flex items-center gap-2 text-sm text-[var(--text-muted)] mt-1 cursor-pointer">
                            <input
                                type="checkbox"
                                checked={formData.recoverViaPayroll ?? true}
                                onChange={e => setFormData((prev: any) => ({ ...prev, recoverViaPayroll: e.target.checked }))}
                            />
                            Récupérer automatiquement sur la paie {formData.recoverViaPayroll === false && <span className="text-amber-500">(sinon : remboursement en espèces uniquement, à saisir manuellement)</span>}
                        </label>
                    )}
                </div>

                <AnimatePresence>
                    {message && (
                        <Notification type={message.type} message={message.text} onClose={() => setMessage(null)} className="mb-4" />
                    )}
                </AnimatePresence>

                <Button type="submit" variant="primary" className="w-full flex items-center justify-center" disabled={loading}>
                    {loading ? (
                        <><Loader2 className="mr-2 h-5 w-5 animate-spin" />Traitement...</>
                    ) : (
                        <><Save className="mr-2 h-5 w-5" />{isLoan ? "Approuver et Enregistrer le Prêt" : "Approuver et Enregistrer l'Avance"}</>
                    )}
                </Button>
            </form>
        </GlassCard>
    );
};