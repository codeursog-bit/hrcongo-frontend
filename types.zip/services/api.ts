// ============================================================================
// 📁 services/api.ts — Client HTTP sécurisé avec cookies HttpOnly
// ============================================================================
// Les tokens JWT voyagent désormais dans des cookies HttpOnly gérés par le
// navigateur. Ce fichier n'a plus besoin de lire/écrire localStorage pour
// les tokens — credentials: 'include' suffit à tout envoyer automatiquement.
//
// Ce qui reste en localStorage : { user } (prénom, rôle, companyId)
// → données d'affichage uniquement, pas sensibles
// ============================================================================

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

type RequestMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

// ─── Refresh silencieux — un seul appel en vol à la fois ─────────────────────
let isRefreshing     = false;
let refreshPromise: Promise<boolean> | null = null;

async function tryRefreshToken(): Promise<boolean> {
  // Si un refresh est déjà en cours, attendre le même promise
  if (isRefreshing && refreshPromise) return refreshPromise;

  isRefreshing   = true;
  refreshPromise = fetch(`${API_URL}/auth/refresh`, {
    method:      'POST',
    credentials: 'include',
  })
    .then(r => r.ok)
    .catch(() => false)
    .finally(() => {
      isRefreshing   = false;
      refreshPromise = null;
    });

  return refreshPromise;
}

// ─── Redirection 401 — uniquement si le refresh a aussi échoué ───────────────
// 🐛 FIX (2026-09-16) : certains hooks (ex: useSubscription, via
// SubscriptionReminderProvider monté dans le layout racine) peuvent encore
// partir en 401 sur une page publique dans des cas limites. On ajoute donc
// une deuxième barrière ici, en plus du fix côté hook : un 401 sur une page
// publique ne doit JAMAIS rediriger un visiteur anonyme vers /auth/login.
function handle401() {
  if (typeof window === 'undefined') return;
  const path         = window.location.pathname;
  const isAdminRoute = path.startsWith('/admin');
  const isAuthPage   = path.includes('/login') || path.includes('/register');

  // Pages publiques (accessibles sans connexion) — à ajuster si de nouvelles
  // routes publiques sont ajoutées à l'app.
  const isPublicPage =
    path === '/' ||
    path.startsWith('/blog') ||
    path.startsWith('/tarifs') ||
    path.startsWith('/outils') ||
    path.startsWith('/simulateur') ||
    path.startsWith('/contact') ||
    path.startsWith('/qui-sommes-nous') ||
    path.startsWith('/docs') ||
    path.startsWith('/register') ||
    path.startsWith('/entreprises') ||
    path.startsWith('/jobs') ||
    path.startsWith('/affiliate/login') ||
    path.startsWith('/verify');
    path.startsWith('/kiosk'); // 🆕 tablette de pointage — pas de session

  if (!isAuthPage && !isPublicPage) {
    // Nettoyer uniquement les données d'affichage (pas les tokens — ils sont en cookie)
    localStorage.removeItem('user');
    window.location.href = isAdminRoute ? '/admin/login' : '/auth/login';
  }
}

// ─── Requête JSON principale ──────────────────────────────────────────────────
async function request<T>(
  endpoint: string,
  method:   RequestMethod = 'GET',
  body?:    any,
): Promise<T> {
  const config: RequestInit = {
    method,
    credentials: 'include',          // ← envoie les cookies HttpOnly automatiquement
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  };

  try {
    let response = await fetch(`${API_URL}${endpoint}`, config);

    // ── Si 401 → tenter un refresh silencieux AVANT de rendre la main ────────
    if (response.status === 401) {
      const refreshed = await tryRefreshToken();
      if (refreshed) {
        // Rejouer la requête originale avec le nouveau cookie access_token
        response = await fetch(`${API_URL}${endpoint}`, config);
      }
    }

    // Essai de parse JSON (certaines réponses d'erreur peuvent ne pas être du JSON)
    let data: any;
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      data = await response.json();
    } else {
      data = { message: await response.text() };
    }

    if (response.status === 401) {
      // Refresh aussi échoué → vraiment déconnecté
      handle401();
      const isAuthPage = typeof window !== 'undefined' &&
        (window.location.pathname.includes('/login') ||
         window.location.pathname.includes('/register'));
      throw new Error(
        isAuthPage
          ? (data.message || 'Identifiants incorrects')
          : 'Session expirée',
      );
    }

    if (!response.ok) {
      // 🔔 Abonnement/essai terminé, quota dépassé... — détecté une seule
      // fois ici, peu importe l'action bloquée (ajout employé, formation,
      // congé, pointage, offre d'emploi...). On déclenche un événement
      // global écouté par <SubscriptionBlockedModal> (montée dans le
      // layout) pour afficher une vraie modale au lieu d'un message perdu
      // dans un toast générique — voir SubscriptionGuard.throwSubscriptionBlocked
      // côté backend pour la liste des points qui l'utilisent.
      if (data?.error === 'SUBSCRIPTION_BLOCKED' && typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent('subscription-blocked', {
            detail: {
              message: data.message || 'Accès bloqué — abonnement requis.',
              audience: data.audience === 'EMPLOYEE' ? 'EMPLOYEE' : 'ADMIN',
            },
          }),
        );
      }
      const err = new Error(data.message || `Erreur ${response.status}`);
      (err as any).code = data.error;       // ex: 'OUT_OF_GEOFENCE', 'LOCATION_REQUIRED'
      (err as any).status = response.status;
      (err as any).data = data;
      throw err;
    }

    return data as T;
  } catch (error: any) {
    // Ne pas logger les erreurs 401 (normales lors d'une déconnexion)
    if (!error.message?.includes('Session expirée') &&
        !error.message?.includes('Identifiants')) {
      console.error(`API Error [${method} ${endpoint}]:`, error.message);
    }
    throw error;
  }
}

// ─── FormData (Upload de fichiers) ───────────────────────────────────────────
async function requestFormData<T>(
  endpoint:  string,
  formData:  FormData,
  method:    'POST' | 'PUT' = 'POST',
): Promise<T> {
  try {
    let response = await fetch(`${API_URL}${endpoint}`, {
      method,
      credentials: 'include',  // cookies automatiques
      body: formData,
      // Pas de Content-Type → le navigateur le gère avec le boundary multipart
    });

    // Refresh silencieux si 401
    if (response.status === 401) {
      const refreshed = await tryRefreshToken();
      if (refreshed) {
        response = await fetch(`${API_URL}${endpoint}`, {
          method,
          credentials: 'include',
          body: formData,
        });
      }
    }

    const data = await response.json();

    if (response.status === 401) {
      handle401();
      throw new Error('Session expirée');
    }
    if (!response.ok) throw new Error(data.message || `Erreur ${response.status}`);
    return data as T;
  } catch (error: any) {
    console.error(`API FormData Error [${endpoint}]:`, error.message);
    throw error;
  }
}

// ─── Blob (Téléchargement de fichiers) ───────────────────────────────────────
async function requestBlob(endpoint: string): Promise<Blob> {
  try {
    let response = await fetch(`${API_URL}${endpoint}`, {
      method:      'GET',
      credentials: 'include',
    });

    if (response.status === 401) {
      const refreshed = await tryRefreshToken();
      if (refreshed) {
        response = await fetch(`${API_URL}${endpoint}`, {
          method: 'GET', credentials: 'include',
        });
      }
    }

    if (response.status === 401) {
      handle401();
      throw new Error('Session expirée');
    }
    if (!response.ok) throw new Error('Erreur lors du téléchargement du fichier');
    return await response.blob();
  } catch (error: any) {
    console.error(`API Blob Error [${endpoint}]:`, error.message);
    throw error;
  }
}

// ─── Text ─────────────────────────────────────────────────────────────────────
async function requestText(endpoint: string): Promise<string> {
  try {
    let response = await fetch(`${API_URL}${endpoint}`, {
      method:      'GET',
      credentials: 'include',
    });

    if (response.status === 401) {
      const refreshed = await tryRefreshToken();
      if (refreshed) {
        response = await fetch(`${API_URL}${endpoint}`, {
          method: 'GET', credentials: 'include',
        });
      }
    }

    if (response.status === 401) {
      handle401();
      throw new Error('Session expirée');
    }
    if (!response.ok) throw new Error(`Erreur ${response.status}`);
    return await response.text();
  } catch (error: any) {
    console.error(`API Text Error [${endpoint}]:`, error.message);
    throw error;
  }
}

// ─── NDJSON streamé (progression live) ───────────────────────────────────────
// ✅ Utilisé pour la paie en masse : chaque ligne de la réponse est un objet
// JSON traité dès qu'il arrive (pas d'attente de la fin de toute la requête).
// Contrairement à `request()`, ceci lit `response.body` en flux via
// ReadableStream — donc pas de refresh-token automatique ici (un flux de
// génération dure quelques secondes, un cookie sur le point d'expirer à la
// milliseconde près est un cas limite qu'on accepte de ne pas couvrir).
async function requestStream(
  endpoint: string,
  body: any,
  onLine: (obj: any) => void,
): Promise<void> {
  const response = await fetch(`${API_URL}${endpoint}`, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (response.status === 401) {
    handle401();
    throw new Error('Session expirée');
  }
  if (!response.ok || !response.body) {
    let message = `Erreur ${response.status}`;
    try {
      const data = await response.json();
      message = data.message || message;
    } catch {}
    throw new Error(message);
  }

  const reader  = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let newlineIndex: number;
    while ((newlineIndex = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, newlineIndex).trim();
      buffer = buffer.slice(newlineIndex + 1);
      if (!line) continue;
      try {
        onLine(JSON.parse(line));
      } catch {
        // ligne partielle/corrompue — ignorée, le flux continue
      }
    }
  }
  // dernière ligne sans retour à la ligne final, le cas échéant
  const rest = buffer.trim();
  if (rest) {
    try { onLine(JSON.parse(rest)); } catch {}
  }
}

// ─── Export public ────────────────────────────────────────────────────────────
export const api = {
  get:    <T>(endpoint: string)              => request<T>(endpoint, 'GET'),
  post:   <T>(endpoint: string, body: any)   => request<T>(endpoint, 'POST', body),
  put:    <T>(endpoint: string, body: any)   => request<T>(endpoint, 'PUT', body),
  patch:  <T>(endpoint: string, body: any)   => request<T>(endpoint, 'PATCH', body),
  delete: <T>(endpoint: string, body?: any) => request<T>(endpoint, 'DELETE', body),
  postFormData: <T>(endpoint: string, fd: FormData) => requestFormData<T>(endpoint, fd, 'POST'),
  putFormData:  <T>(endpoint: string, fd: FormData) => requestFormData<T>(endpoint, fd, 'PUT'),
  getBlob: (endpoint: string) => requestBlob(endpoint),
  getText: (endpoint: string) => requestText(endpoint),
  postStream: (endpoint: string, body: any, onLine: (obj: any) => void) =>
    requestStream(endpoint, body, onLine),
};