// ============================================================================
// 📁 components/AbsenceRequestPrintable.tsx
// ✅ Reproduit le formulaire papier "DEMANDE D'AUTORISATION D'ABSENCE"
//    fourni par le client, mais dynamique : logo, nom, RCCM, NIU, adresse
//    et téléphone viennent de l'entreprise connectée (pas de "ORCA" en dur).
// ✅ Utilisé à l'écran (aperçu live pendant la saisie) ET à l'impression
//    via lib/absence-print.ts (id="absence-print-root").
// ============================================================================

'use client';

import React from 'react';
import { SigVisa, OtherOpinions, sigFor, type DocumentSignature } from './documents/docSignatures';

export interface AbsenceRequestPrintableData {
  reference?: string;               // ex: DEA-A1B2C3D4
  company: {
    legalName?: string;
    tradeName?: string;
    logo?: string | null;
    rccmNumber?: string;
    taxNumber?: string;
    address?: string;
    phone?: string;
    cachetUrl?: string | null;
    documentFooterText?: string | null;
  };
  employee: {
    firstName: string;
    lastName: string;
    position?: string;
    departmentName?: string;
    responsableName?: string;
  };
  type: 'MALADIE' | 'CONVENTIONNELLE' | 'EXCEPTIONNELLE' | string;
  subType?: 'MALADIE' | 'MATERNITE' | 'PATERNITE' | 'MARIAGE' | 'DECES' | 'NAISSANCE' | 'AUTRE' | string;
  reason: string;
  isPaid: boolean;
  startDate: string | Date;
  endDate: string | Date;
  workingDays: number | string;
  hasAttachment?: boolean;
  // ✅ LOT D — avis/signatures personnelles (optionnel : sans avis, rendu identique à avant)
  signatures?: DocumentSignature[];
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED' | string;
  requestedAt?: string | Date;
  reviewedByName?: string;
  reviewedAt?: string | Date;
  rejectionReason?: string;
}

const fmt = (d?: string | Date) => (d ? new Date(d).toLocaleDateString('fr-FR') : '.................................');

const Checkbox = ({ checked }: { checked: boolean }) => (
  <span
    style={{
      display: 'inline-flex',
      width: 16,
      height: 16,
      border: '1.5px solid #1f2937',
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 6,
      verticalAlign: 'middle',
      fontSize: 12,
      fontWeight: 700,
      lineHeight: 1,
    }}
  >
    {checked ? '✕' : ''}
  </span>
);

export default function AbsenceRequestPrintable({ data }: { data: AbsenceRequestPrintableData }) {
  const companyName = data.company.tradeName || data.company.legalName || 'Entreprise';

  return (
    <div
      id="absence-print-root"
      data-absence-print-root="true"
      style={{
        width: '210mm',
        minHeight: '297mm',
        margin: '0 auto',
        background: '#fff',
        color: '#1f2937',
        fontFamily: 'Arial, Helvetica, sans-serif',
        padding: '14mm 16mm',
        boxSizing: 'border-box',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* ── EN-TÊTE ── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {data.company.logo && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={data.company.logo} alt={companyName} style={{ height: 52, objectFit: 'contain' }} />
          )}
          <span style={{ fontSize: 20, fontWeight: 800, letterSpacing: 1 }}>{companyName}</span>
        </div>
        <div style={{ fontSize: 12, fontWeight: 700 }}>
          Réf. N° : {data.reference || '.....................'}
        </div>
      </div>

      {/* ── TITRE ── */}
      <div style={{ border: '2px solid #1f2937', padding: '11px 16px', marginBottom: 24, transform: 'rotate(-0.3deg)' }}>
        <h1 style={{ fontSize: 19, fontWeight: 800, letterSpacing: 1, margin: 0, textAlign: 'center' }}>
          DEMANDE D&apos;AUTORISATION D&apos;ABSENCE
        </h1>
      </div>

      {/* ── IDENTITÉ ── */}
      <div style={{ fontSize: 15.5, lineHeight: 2.2 }}>
        <div style={{ display: 'flex', gap: 24 }}>
          <div style={{ flex: 1 }}><strong>Nom :</strong> {data.employee.lastName}</div>
          <div style={{ flex: 1 }}><strong>Prénoms :</strong> {data.employee.firstName}</div>
        </div>
        <div><strong>Département :</strong> {data.employee.departmentName || '—'}</div>
        <div><strong>Fonction :</strong> {data.employee.position || '—'}</div>
        <div><strong>Responsable :</strong> {data.employee.responsableName || '—'}</div>

        <div style={{ marginTop: 9 }}>
          <strong>Type d&apos;absence : </strong>
          {/* ✅ "Maladie" est un sous-motif de Conventionnelle depuis la restructuration
              du schéma (type=CONVENTIONNELLE, subType=MALADIE) — la case doit donc se
              cocher sur le sous-motif, pas sur data.type qui ne vaudra plus jamais
              littéralement "MALADIE" pour une nouvelle demande. */}
          <Checkbox checked={data.subType === 'MALADIE'} /> Maladie &nbsp;&nbsp;
          <Checkbox checked={data.type === 'CONVENTIONNELLE' && data.subType !== 'MALADIE'} /> Conventionnelle &nbsp;&nbsp;
          <Checkbox checked={data.type === 'EXCEPTIONNELLE'} /> Exceptionnelle
        </div>

        <div style={{ marginTop: 7 }}>
          <strong>Motif de l&apos;absence :</strong> {data.reason}
        </div>

        <div style={{ marginTop: 9 }}>
          <strong>Statut de l&apos;absence : </strong>
          <Checkbox checked={data.isPaid} /> Payé &nbsp;&nbsp;&nbsp;
          <Checkbox checked={!data.isPaid} /> Non-payé
        </div>

        <div style={{ marginTop: 7 }}><strong>Date de départ :</strong> {fmt(data.startDate)}</div>
        <div><strong>Date de reprise du travail :</strong> {fmt(data.endDate)}</div>
        <div><strong>Nombre de jours ouvrables d&apos;absence :</strong> {data.workingDays}</div>

        <div style={{ marginTop: 7 }}>
          <strong>Justificatif joint :</strong> <Checkbox checked={!!data.hasAttachment} /> {data.hasAttachment ? 'Oui' : 'Non'}
        </div>
      </div>

      {/* ── AVIS DU SERVICE ── */}
      <div style={{ marginTop: 28, fontSize: 15.5 }}>
        <strong>Avis du service :</strong>
        <div style={{ display: 'flex', gap: 40, marginTop: 10 }}>
          <div><Checkbox checked={data.status === 'APPROVED'} /> Accord</div>
          <div><Checkbox checked={data.status === 'REJECTED'} /> Refus</div>
        </div>
        {data.status === 'REJECTED' && data.rejectionReason && (
          <div style={{ marginTop: 8, fontSize: 13, fontStyle: 'italic' }}>
            Motif du refus : {data.rejectionReason}
          </div>
        )}
      </div>

      {/* ── SIGNATURES ──
          ✅ Poussé vers le bas de la page A4 (marginTop: auto) plutôt que collé à
          l'avis du service — reproduit la position basse du modèle papier. */}
      <div style={{ marginTop: 'auto', border: '2px solid #1f2937', display: 'flex' }}>
        {[
          { label: 'Agent', name: `${data.employee.firstName} ${data.employee.lastName}`, date: data.requestedAt ? fmt(data.requestedAt) : undefined, stamp: false },
          { label: 'Chef de service', name: undefined, date: undefined, stamp: false },
          { label: 'Ressources Humaines', name: undefined, date: data.status === 'APPROVED' ? fmt(data.reviewedAt) : undefined, stamp: data.status === 'APPROVED' },
        ].map((col, i) => (
          <div
            key={col.label}
            style={{
              flex: 1,
              padding: '18px 12px 22px',
              borderLeft: i === 0 ? 'none' : '2px solid #1f2937',
              minHeight: 180,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              alignItems: 'center',
              textAlign: 'center',
            }}
          >
            <div style={{ fontWeight: 700, fontSize: 16, textDecoration: 'underline' }}>{col.label}</div>
            {/* ✅ Le cachet (cachetUrl, entreprise → paramètres/entreprise) remplace tout
                texte d'identité du validateur — jamais son nom ni son email. */}
            {(() => {
              // ✅ LOT D — signature personnelle (Chef de service → supérieur hiérarchique ; RH → RH)
              const code = col.label === 'Chef de service' ? 'HIERARCHY_HEAD' : col.label === 'Ressources Humaines' ? 'HR' : null;
              const sig = code ? sigFor(data.signatures, code) : undefined;
              if (col.stamp && data.company.cachetUrl) {
                return (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={data.company.cachetUrl} alt="Cachet" style={{ height: sig ? 70 : 100, objectFit: 'contain' }} />
                    {sig && <SigVisa sig={sig} height={36} align="center" nameSize={10} />}
                  </div>
                );
              }
              if (sig) return <SigVisa sig={sig} height={60} align="center" nameSize={11} />;
              return (
                <div style={{ fontSize: 15, minHeight: 56 }}>
                  {col.name && <div style={{ fontWeight: 600 }}>{col.name}</div>}
                </div>
              );
            })()}
            <div>
              {col.date && <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 3 }}>{col.date}</div>}
              <div style={{ fontWeight: 700, fontSize: 14 }}>Date et signature</div>
            </div>
          </div>
        ))}
      </div>

      {/* ✅ LOT D — fonctions sans case sur ce modèle (comptable, DG, chef d'équipe) */}
      <OtherOpinions signatures={data.signatures} boxCodes={['HIERARCHY_HEAD', 'HR']} fontSize={11} color="#374151" />

      {/* ── PIED DE PAGE ──
          Texte libre défini par l'entreprise (paramètres → Pied de page des documents)
          s'il existe ; sinon composition automatique à partir de RCCM/NIU/adresse. */}
      <div style={{ marginTop: 26, textAlign: 'center', fontSize: 11, color: '#4b5563', lineHeight: 1.7, borderTop: '1px solid #e5e7eb', paddingTop: 12, whiteSpace: 'pre-line' }}>
        {data.company.documentFooterText ? (
          data.company.documentFooterText
        ) : (
          <>
            <div style={{ fontWeight: 700 }}>{companyName}</div>
            {(data.company.rccmNumber || data.company.taxNumber) && (
              <div>
                {data.company.rccmNumber && <>RCCM : {data.company.rccmNumber}&nbsp;&nbsp;</>}
                {data.company.taxNumber && <>NIU : {data.company.taxNumber}</>}
              </div>
            )}
            {data.company.address && <div>{data.company.address}{data.company.phone ? ` — Tél : ${data.company.phone}` : ''}</div>}
            <div style={{ marginTop: 6, fontStyle: 'italic' }}>Document généré via Konza RH</div>
          </>
        )}
      </div>
    </div>
  );
}