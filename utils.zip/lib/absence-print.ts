// ============================================================================
// 📁 lib/absence-print.ts
// ✅ Même technique que lib/bulletin-print.ts (iframe isolé pour l'impression,
//    html2canvas + jsPDF pour le téléchargement) — appliquée au formulaire
//    "Demande d'autorisation d'absence" (AbsenceRequestPrintable, id fixe
//    "absence-print-root").
// ============================================================================

const ABSENCE_ROOT_ID = 'absence-print-root';

function findAbsenceElement(): HTMLElement | null {
  return (
    document.getElementById(ABSENCE_ROOT_ID) ||
    document.querySelector<HTMLElement>('[data-absence-print-root="true"]')
  );
}

// ============================================================================
// IMPRESSION
// ============================================================================

export function printAbsenceRequest() {
  const el = findAbsenceElement();
  if (!el) { window.print(); return; }

  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:210mm;height:297mm;border:none;visibility:hidden;';
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument || iframe.contentWindow?.document;
  if (!doc) { document.body.removeChild(iframe); window.print(); return; }

  const styleLinks   = Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(l => l.outerHTML).join('\n');
  const styleInlines = Array.from(document.querySelectorAll('style')).map(s => `<style>${s.innerHTML}</style>`).join('\n');

  doc.open();
  doc.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
${styleLinks}
${styleInlines}
<style>
  @page { size: A4 portrait; margin: 0; }
  html, body {
    margin: 0; padding: 0;
    background: #fff;
    font-family: Arial, Helvetica, sans-serif;
  }
  * { color-scheme: light !important; }
  body > *:not(#absence-print-target) { display: none !important; }
  #absence-print-target {
    width: 210mm !important;
    margin: 0 auto !important;
    background: #fff !important;
    /* ✅ CORRECTIF : garantit UNE seule page à l'impression navigateur —
       le téléchargement PDF avait déjà ce garde-fou (mise à l'échelle),
       l'impression native window.print() n'en avait aucun : le moindre
       dépassement de 297mm produisait une 2e page quasi vide. */
    height: 297mm !important;
    overflow: hidden !important;
  }
  * {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
    color-adjust: exact !important;
  }
  /* ✅ CORRECTIF : le site est en dark mode par défaut (voir globals.css).
     Si un élément du document utilise une classe Tailwind "dark:text-*"
     (texte clair pensé pour un fond sombre) plutôt qu'une couleur figée,
     il devient quasi invisible une fois forcé sur fond blanc ici — d'où le
     texte "délavé" à l'impression/export (même bug identifié sur les prêts,
     cf. loan-print.ts). On impose une couleur de texte sûre à tout le
     contenu imprimé, quelle que soit la classe/le thème d'origine — SAUF
     aux éléments du formulaire lui-même (classes "std-*" : std-abs-*,
     std-adv-*, std-loan-*, std-leave-*), qui verrouillent déjà leurs
     propres couleurs de marque (filets dorés, titres colorés…) via leur
     <style> scopé en !important. Sans cette exception, ce garde-fou les
     écrasait en noir uniforme — c'est le même mécanisme que pour les
     prêts, avances et congés, voir loan-print.ts / leave-print.ts.
  */
  #absence-print-target, #absence-print-target *:not([class*="std-"]) {
    color: #111 !important;
    background-color: transparent !important;
  }
  #absence-print-target { background-color: #fff !important; }
  #absence-print-target img { background-color: initial !important; }
</style>
</head><body>
<div id="absence-print-target">${el.outerHTML}</div>
</body></html>`);
  doc.close();

  const win = iframe.contentWindow;
  if (!win) { document.body.removeChild(iframe); window.print(); return; }

  const doPrint = () => {
    try { win.focus(); win.print(); } catch { window.print(); }
    setTimeout(() => {
      if (document.body.contains(iframe)) document.body.removeChild(iframe);
    }, 1500);
  };

  if (doc.readyState === 'complete') setTimeout(doPrint, 300);
  else {
    win.addEventListener('load', () => setTimeout(doPrint, 300), { once: true });
    setTimeout(doPrint, 1500);
  }
}

// ============================================================================
// TÉLÉCHARGEMENT PDF
// ============================================================================

export async function downloadAbsenceRequestPDF(filename: string): Promise<void> {
  const el = findAbsenceElement();
  if (!el) {
    alert("Impossible de générer le PDF : formulaire introuvable.");
    return;
  }

  const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([
    import('html2canvas'),
    import('jspdf'),
  ]);

  const container = document.createElement('div');
  container.style.cssText = [
    'position:fixed',
    'left:-9999px',
    'top:0',
    'width:210mm',
    'background:#fff',
    'z-index:-1',
    'overflow:visible',
  ].join(';');

  const clone = el.cloneNode(true) as HTMLElement;
  // ✅ CORRECTIF : on ne remplace PLUS le style inline du clone (l'ancien
  // `clone.style.cssText = ...` effaçait fontFamily, display:flex, height,
  // overflow et le padding calé du formulaire → police sans-serif et
  // espacements faux dans le PDF). On ne touche qu'aux propriétés
  // strictement nécessaires ; width, height, padding, police et flex
  // restent ceux du composant.
  clone.style.margin = '0';
  clone.style.boxShadow = 'none';
  clone.style.border = 'none';
  clone.style.colorScheme = 'light';
  clone.id = 'pdf-export-target';

  // ✅ CORRECTIF : même filet de sécurité que loan-print.ts / leave-print.ts
  // — le site étant en dark mode par défaut, un élément stylé en
  // "dark:text-*" (texte clair sur fond sombre) copié tel quel par
  // cloneNode() ressort quasi invisible une fois html2canvas forcé sur fond
  // blanc. On impose ici une couleur de texte sûre à tout le clone — SAUF
  // aux éléments "std-*" du formulaire, qui verrouillent déjà leurs propres
  // couleurs de marque (voir le commentaire équivalent dans printAbsenceRequest
  // ci-dessus).
  const styleOverride = document.createElement('style');
  styleOverride.textContent = `
    #pdf-export-target, #pdf-export-target *:not([class*="std-"]) { color: #111 !important; background-color: transparent !important; }
    #pdf-export-target { background-color: #fff !important; }
    #pdf-export-target img { background-color: initial !important; }
  `;
  container.appendChild(styleOverride);
  container.appendChild(clone);
  document.body.appendChild(container);

  try {
    await new Promise(r => setTimeout(r, 200));

    const W = clone.scrollWidth  || clone.offsetWidth  || 794;
    const H = clone.scrollHeight || clone.offsetHeight || 1123;

    const canvas = await html2canvas(clone, {
      scale:           2,
      useCORS:         true,
      allowTaint:      true,
      backgroundColor: '#ffffff',
      logging:         false,
      width:           W,
      height:          H,
      windowWidth:     794,
      windowHeight:    1123,
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.95);
    const pdf     = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const pdfW    = pdf.internal.pageSize.getWidth();
    const pdfH    = pdf.internal.pageSize.getHeight();

    const imgRatio = canvas.width / canvas.height;

    // ✅ CORRECTIF : ce formulaire tient sur UNE page — l'ancienne logique
    // paginait dès que le contenu dépassait 297mm de la moindre fraction de
    // mm, produisant une 2e page quasi vide. On ajuste maintenant l'échelle
    // pour TOUJOURS tenir sur une seule page.
    let finalW = pdfW;
    let finalH = pdfW / imgRatio;
    if (finalH > pdfH) {
      finalH = pdfH;
      finalW = pdfH * imgRatio;
    }
    const offsetX = (pdfW - finalW) / 2;
    pdf.addImage(imgData, 'JPEG', offsetX, 0, finalW, finalH, '', 'FAST');

    pdf.save(filename);
  } catch (err) {
    console.error('[absence-print] Erreur génération PDF:', err);
    alert("Erreur lors de la génération du PDF. Essayez l'impression navigateur.");
  } finally {
    if (document.body.contains(container)) document.body.removeChild(container);
  }
}